import {
  PaymentProvider,
  RequestPaymentParams,
  RequestPaymentResult,
  VerifyPaymentParams,
  VerifyPaymentResult
} from './PaymentProvider';

export class IDPayPaymentProvider implements PaymentProvider {
  name = 'idpay';
  private apiKey: string;

  constructor() {
    this.apiKey = process.env.IDPAY_API_KEY?.trim() || '';
  }

  async requestPayment(params: RequestPaymentParams): Promise<RequestPaymentResult> {
    if (!this.apiKey || this.apiKey.length <= 5) {
      return {
        ok: false,
        errorMessageFa: 'درگاه پرداخت آی‌دی‌پی هنوز متصل نشده است. تا زمان اتصال درگاه و واریز واقعی وجه، امکان پرداخت وجود ندارد.'
      };
    }

    try {
      const res = await fetch('https://api.idpay.ir/v1.1/payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-KEY': this.apiKey
        },
        body: JSON.stringify({
          order_id: params.orderId,
          amount: params.amountToman * 10,
          name: params.mobile || 'مشتری موریکو',
          phone: params.mobile,
          mail: params.email,
          desc: params.description,
          callback: params.callbackUrl
        })
      });

      const data = await res.json();
      if (data?.id && data?.link) {
        return {
          ok: true,
          authority: data.id,
          redirectUrl: data.link
        };
      }

      return {
        ok: false,
        errorMessageFa: data?.error_message || 'خطا در اتصال به درگاه پرداخت آی‌دی‌پی'
      };
    } catch {
      return {
        ok: false,
        errorMessageFa: 'خطا در برقراری ارتباط با سرور درگاه پرداخت آی‌دی‌پی.'
      };
    }
  }

  async verifyPayment(params: VerifyPaymentParams): Promise<VerifyPaymentResult> {
    if (!this.apiKey || this.apiKey.length <= 5) {
      return {
        success: false,
        error: 'درگاه پرداخت متصل نیست و هیچ مبلغی واریز نشده است.'
      };
    }

    try {
      const res = await fetch('https://api.idpay.ir/v1.1/payment/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-KEY': this.apiKey
        },
        body: JSON.stringify({
          id: params.authority,
          order_id: params.authority
        })
      });

      const data = await res.json();
      if (data?.status === 100 || data?.status === 101) {
        return {
          success: true,
          referenceId: data?.track_id || data?.payment?.track_id || `REF_${Date.now()}`
        };
      }

      return {
        success: false,
        error: data?.error_message || 'پرداخت توسط درگاه تایید نشد.'
      };
    } catch {
      return {
        success: false,
        error: 'خطا در اعتبارسنجی پرداخت.'
      };
    }
  }
}
