import { PaymentProvider } from './PaymentProvider';
import { ZarinPalPaymentProvider } from './ZarinPalPaymentProvider';
import { IDPayPaymentProvider } from './IDPayProvider';

export function getActivePaymentProviderName(): string {
  const envProvider = process.env.PAYMENT_PROVIDER?.toLowerCase();
  if (envProvider === 'idpay') return 'idpay';
  return 'zarinpal';
}

export function isPaymentGatewayConfigured(): boolean {
  const name = getActivePaymentProviderName();
  if (name === 'idpay') {
    const key = process.env.IDPAY_API_KEY?.trim();
    return Boolean(key && key.length > 5);
  }
  const merchantId = process.env.ZARINPAL_MERCHANT_ID?.trim();
  return Boolean(merchantId && merchantId.length > 5);
}

export function getActivePaymentProvider(): PaymentProvider {
  const name = getActivePaymentProviderName();
  if (name === 'idpay') {
    return new IDPayPaymentProvider();
  }
  return new ZarinPalPaymentProvider();
}
