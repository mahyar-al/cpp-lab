import {
  PaymentProvider,
  RequestPaymentParams,
  RequestPaymentResult,
  VerifyPaymentParams,
  VerifyPaymentResult
} from './PaymentProvider';

export class ZarinPalPaymentProvider implements PaymentProvider {
  name = 'zarinpal';

  private merchantId: string;
  private isSandbox: boolean;

  constructor() {
    this.merchantId = process.env.ZARINPAL_MERCHANT_ID || '';
    this.isSandbox = process.env.ZARINPAL_SANDBOX === 'true' || !this.merchantId;
  }

  async requestPayment(params: RequestPaymentParams): Promise<RequestPaymentResult> {
    const authority = `ZP_AUTH_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

    if (!this.merchantId || this.merchantId.trim().length <= 5) {
      return {
        ok: false,
        errorMessageFa: 'درگاه پرداخت زرین‌پال هنوز توسط مدیریت متصل نشده است. تا زمان اتصال درگاه و واریز واقعی وجه، امکان پرداخت وجود ندارد.'
      };
    }

    try {
      const res = await fetch('https://api.zarinpal.com/pg/v4/payment/request.json', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchant_id: this.merchantId,
          amount: params.amountToman * 10,
          description: params.description,
          callback_url: params.callbackUrl,
          metadata: {
            mobile: params.mobile || undefined,
            email: params.email || undefined
          }
        })
      });

      const data = await res.json();
      if (data?.data?.code === 100 && data?.data?.authority) {
        return {
          ok: true,
          authority: data.data.authority,
          redirectUrl: `https://www.zarinpal.com/pg/StartPay/${data.data.authority}`
        };
      }

      return {
        ok: false,
        errorMessageFa: data?.errors?.message || 'خطا در ارتباط با درگاه پرداخت زرین‌پال'
      };
    } catch {
      return {
        ok: false,
        errorMessageFa: 'خطا در ارتباط با سرور درگاه پرداخت زرین‌پال.'
      };
    }
  }

  async verifyPayment(params: VerifyPaymentParams): Promise<VerifyPaymentResult> {
    if (!this.merchantId || this.merchantId.trim().length <= 5) {
      return {
        success: false,
        error: 'درگاه پرداخت زرین‌پال متصل نیست و وجهی پرداخت نشده است.'
      };
    }

    try {
      const res = await fetch('https://api.zarinpal.com/pg/v4/payment/verify.json', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchant_id: this.merchantId,
          amount: params.amountToman * 10,
          authority: params.authority
        })
      });

      const data = await res.json();
      if (data?.data?.code === 100 || data?.data?.code === 101) {
        return {
          success: true,
          referenceId: String(data.data.ref_id)
        };
      }

      return {
        success: false,
        error: data?.errors?.message || 'تراکنش تایید نشد.'
      };
    } catch (err: any) {
      return {
        success: false,
        error: err?.message || 'خطا در تایید تراکنش.'
      };
    }
  }
}
