import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { applyDiscount } from '@/lib/currency';
import { ProductCard } from '@/components/ProductCard';
import { AdBanner } from '@/components/AdBanner';
import { FaqSection } from '@/components/FaqSection';
import { getSiteContent } from '@/lib/site-content';
import { HeroInteractiveMockup } from '@/components/HeroInteractiveMockup';

const CATEGORY_META: Record<string, { icon: string; desc: string }> = {
  tshirt: { icon: '👕', desc: '۱۰۰٪ نخ پنبه سوپر' },
  hoodie: { icon: '🧥', desc: 'دورس سه‌نخ تو کرکی' },
  mug: { icon: '☕', desc: 'سرامیک درجه یک حرارتی' },
  cap: { icon: '🧢', desc: 'کتان با گلدوزی و چاپ' },
  canvas: { icon: '🎨', desc: 'بوم پارچه‌ای ضدآب' },
  case: { icon: '📱', desc: 'سیلیکونی ضد ضربه' }
};

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function HomePage() {
  const [categories, featured, siteContent] = await Promise.all([
    prisma.category.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' }, take: 6 }),
    prisma.product.findMany({
      where: { isArchived: false, isAvailable: true },
      orderBy: { createdAt: 'desc' },
      take: 12,
      include: {
        images: { take: 1, orderBy: { sortOrder: 'asc' } },
        views: { take: 1, orderBy: { sortOrder: 'asc' } }
      }
    }),
    getSiteContent()
  ]);

  const featuredProducts = featured.map((p) => {
    const img = p.images?.[0]?.url || (p as any).views?.[0]?.imageUrl || '/brand/morico-logo.jpg';
    return {
      id: p.id,
      name: p.name,
      slug: p.slug,
      image: img,
      basePrice: p.basePrice,
      discountPercent: p.discountPercent,
      finalPrice: applyDiscount(p.basePrice, p.discountPercent),
      isAvailable: p.isAvailable,
      customizationEnabled: p.customizationEnabled
    };
  });

  const { hero, howItWorks, faqs } = siteContent;

  return (
    <div className="space-y-16 sm:space-y-24">
      {/* 1. Chic Editorial Hero Section */}
      <section className="relative overflow-hidden border-b border-ink-100/70 bg-gradient-to-b from-powder-100/60 via-powder-50/40 to-[#FAF8F5] pt-12 pb-16 sm:pt-20 sm:pb-24">
        {/* Soft atmospheric ambient glow */}
        <div
          aria-hidden
          className="pointer-events-none absolute -top-32 -right-32 h-[30rem] w-[30rem] rounded-full bg-powder-300/35 blur-3xl"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-32 -left-32 h-[30rem] w-[30rem] rounded-full bg-powder-200/40 blur-3xl"
        />

        <div className="container-morico relative grid items-center gap-10 lg:grid-cols-12 lg:gap-12 xl:gap-16">
          {/* Hero Content Right */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8">
            <h1 className="text-3xl font-black leading-[1.25] text-ink-900 sm:text-5xl lg:text-5xl xl:text-6xl tracking-tight text-balance">
              <span className="block">{hero.headline.replace(/خودت رو/g, 'خودت\u00A0رو')}</span>
              <span className="mt-1.5 sm:mt-2 block bg-gradient-to-l from-ink-900 via-powder-900 to-powder-700 bg-clip-text text-transparent">
                {hero.subheadline}
              </span>
            </h1>

            <p className="max-w-2xl text-base leading-8 text-ink-600 sm:text-lg font-normal">
              {hero.description}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-1">
              <Link
                href={hero.primaryCtaLink || '/shop?customizable=1'}
                className="btn-primary !px-8 !py-4 text-sm font-bold shadow-lg shadow-ink-900/10 flex items-center gap-2 group"
              >
                <span>{hero.primaryCtaText}</span>
                <span className="transition-transform group-hover:-translate-x-1">←</span>
              </Link>
              <Link
                href={hero.secondaryCtaLink || '/shop'}
                className="btn-outline !px-7 !py-4 text-sm font-semibold hover:border-ink-900"
              >
                {hero.secondaryCtaText}
              </Link>
            </div>

            {/* Quick Trust Highlights / Stats */}
            <div className="grid grid-cols-3 gap-4 border-t border-ink-200/60 pt-6 sm:pt-8 max-w-xl">
              <div>
                <p className="text-xl sm:text-2xl font-black text-ink-900">{hero.stats?.stat1Value || '+۵۰,۰۰۰'}</p>
                <p className="text-xs text-ink-500 mt-0.5">{hero.stats?.stat1Label || 'طرح چاپ‌شده'}</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-ink-900">{hero.stats?.stat2Value || '۱۰۰٪'}</p>
                <p className="text-xs text-ink-500 mt-0.5">{hero.stats?.stat2Label || 'پنبه ارگانیک'}</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-ink-900">{hero.stats?.stat3Value || '۴۸ ساعت'}</p>
                <p className="text-xs text-ink-500 mt-0.5">{hero.stats?.stat3Label || 'ارسال سریع'}</p>
              </div>
            </div>
          </div>

          {/* Hero Interactive 3D Mockup Left */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <HeroInteractiveMockup />
          </div>
        </div>
      </section>

      {/* 2. Categories Showcase */}
      {categories.length > 0 && (
        <section className="container-morico">
          <div className="mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-ink-100/70 pb-4">
            <div>
              <p className="text-xs font-bold tracking-widest uppercase text-powder-800">CATEGORIES</p>
              <h2 className="mt-1 text-2xl font-bold text-ink-900">دسته‌بندی‌های برگزیده</h2>
            </div>
            <Link
              href="/shop"
              className="text-xs font-bold text-ink-600 hover:text-ink-900 flex items-center gap-1.5 transition"
            >
              <span>مشاهده کاتالوگ کامل</span>
              <span>←</span>
            </Link>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {categories.map((c) => {
              const meta = CATEGORY_META[c.slug] ?? { icon: '✨', desc: 'محصولات باکیفیت' };
              return (
                <Link
                  key={c.id}
                  href={`/category/${c.slug}`}
                  className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-ink-100/80 bg-white p-5 text-center transition-all duration-300 hover:-translate-y-1.5 hover:border-ink-300 hover:shadow-soft"
                >
                  <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-powder-50/80 text-2xl transition-transform duration-300 group-hover:scale-110 group-hover:bg-powder-100">
                    {meta.icon}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-ink-900 group-hover:text-powder-900 transition-colors">
                      {c.name}
                    </h3>
                    <p className="mt-1 text-[11px] text-ink-400">{meta.desc}</p>
                  </div>
                </Link>
              );
            })}
          </div>
        </section>
      )}

      {/* 3. Featured Products Grid */}
      <section className="container-morico">
        <div className="mb-8 flex items-center justify-between border-b border-ink-100/70 pb-4">
          <div>
            <p className="text-xs font-bold tracking-widest uppercase text-powder-800">COLLECTION</p>
            <h2 className="mt-1 text-2xl font-bold text-ink-900">جدیدترین محصولات آماده چاپ</h2>
          </div>
          <Link href="/shop" className="text-xs font-bold text-ink-600 hover:text-ink-900 flex items-center gap-1">
            <span>مشاهده همه</span>
            <span>←</span>
          </Link>
        </div>

        {featuredProducts.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-ink-200 p-12 text-center text-sm text-ink-400">
            هنوز محصولی ثبت نشده است.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {featuredProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* 4. How It Works (Steps) */}
      <section className="container-morico">
        <div className="text-center max-w-xl mx-auto mb-12">
          <p className="text-xs font-bold tracking-widest uppercase text-powder-800">HOW IT WORKS</p>
          <h2 className="mt-1 text-2xl font-bold text-ink-900">{howItWorks.title}</h2>
          <p className="mt-2 text-sm text-ink-500">{howItWorks.subtitle}</p>
        </div>

        <div className="grid gap-6 sm:grid-cols-3">
          {howItWorks.steps.map((item) => (
            <div
              key={item.number}
              className="relative rounded-2xl border border-ink-100 bg-white p-7 transition-all duration-300 hover:-translate-y-1 hover:shadow-soft"
            >
              <span className="font-mono text-3xl font-extrabold text-powder-400">{item.number}</span>
              <h3 className="mt-3 text-base font-bold text-ink-900">{item.title}</h3>
              <p className="mt-2 text-xs leading-7 text-ink-500">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Promotional Ad Banner if configured */}
      <AdBanner placement="home" />

      {/* 6. Frequently Asked Questions */}
      <section className="container-morico">
        <div className="text-center max-w-xl mx-auto mb-10">
          <p className="text-xs font-bold tracking-widest uppercase text-powder-800">FAQ</p>
          <h2 className="mt-1 text-2xl font-bold text-ink-900">پرسش‌های متداول</h2>
        </div>

        <FaqSection faqs={faqs} />
      </section>

      {/* 7. Final Chic Banner */}
      <section className="container-morico pb-12">
        <div className="relative overflow-hidden rounded-3xl border border-ink-100 bg-gradient-to-r from-powder-100 via-powder-50 to-[#FAF8F5] p-8 sm:p-14 text-center">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-ink-900 tracking-tight">
            آماده‌ای استایل اختصاصی خودت رو بسازی؟
          </h2>
          <p className="mt-3 max-w-md mx-auto text-sm text-ink-600 leading-7 font-normal">
            همین حالا بدون هیچ هزینه‌ای وارد استودیو شو، لباست رو طراحی کن و پیش‌نمایش آنی رو ببین.
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <Link
              href="/shop?customizable=1"
              className="btn-primary !px-8 !py-3.5 text-sm font-bold shadow-soft hover:shadow-md"
            >
              ورود به استودیو طراحی
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
