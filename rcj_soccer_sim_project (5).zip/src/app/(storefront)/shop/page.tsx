import { prisma } from '@/lib/prisma';
import { applyDiscount } from '@/lib/currency';
import { ProductCard } from '@/components/ProductCard';
import { ShopFilters } from '@/components/ShopFilters';
import { AdBanner } from '@/components/AdBanner';
import type { Prisma } from '@prisma/client';

interface ShopPageProps {
  searchParams: {
    q?: string;
    category?: string;
    sort?: string;
    minPrice?: string;
    maxPrice?: string;
    available?: string;
    discounted?: string;
  };
}

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function ShopPage({ searchParams }: ShopPageProps) {
  const { q, category, sort = 'newest', minPrice, maxPrice, available, discounted } = searchParams;

  const where: Prisma.ProductWhereInput = {
    isArchived: false,
    ...(q ? { name: { contains: q, mode: 'insensitive' } } : {}),
    ...(category ? { category: { slug: category } } : {}),
    ...(available === '1' ? { isAvailable: true } : {}),
    ...(discounted === '1' ? { discountPercent: { gt: 0 } } : {}),
    ...(minPrice || maxPrice
      ? {
          basePrice: {
            ...(minPrice ? { gte: Number(minPrice) } : {}),
            ...(maxPrice ? { lte: Number(maxPrice) } : {})
          }
        }
      : {})
  };

  const orderBy: Prisma.ProductOrderByWithRelationInput =
    sort === 'cheapest' ? { basePrice: 'asc' } : sort === 'expensive' ? { basePrice: 'desc' } : { createdAt: 'desc' };

  const [products, categories] = await Promise.all([
    prisma.product.findMany({
      where,
      orderBy,
      include: {
        images: { take: 1, orderBy: { sortOrder: 'asc' } },
        views: { take: 1, orderBy: { sortOrder: 'asc' } },
        inventory: true
      }
    }),
    prisma.category.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } })
  ]);

  const items = products.map((p) => {
    const img = p.images?.[0]?.url || (p as any).views?.[0]?.imageUrl || '/brand/morico-logo.jpg';
    return {
      id: p.id,
      name: p.name,
      slug: p.slug,
      image: img,
      basePrice: p.basePrice,
      discountPercent: p.discountPercent,
      finalPrice: applyDiscount(p.basePrice, p.discountPercent),
      isAvailable: p.isAvailable && (p.inventory?.stock ?? 0) > 0,
      customizationEnabled: p.customizationEnabled
    };
  });

  return (
    <div>
      <AdBanner placement="shop" />
      <div className="container-morico py-8 sm:py-10">
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-ink-100 pb-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-ink-900">فروشگاه موریکو</h1>
            <p className="mt-1 text-xs text-ink-500">پوشاک و هدایای باکیفیت با قابلیت طراحی و چاپ اختصاصی</p>
          </div>
          <span className="rounded-full bg-powder-100 px-3 py-1 text-xs font-semibold text-ink-700 w-fit">
            {items.length} محصول موجود
          </span>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[260px_1fr]">
          <ShopFilters categories={categories.map((c) => ({ name: c.name, slug: c.slug }))} />

          <div>
            {items.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-ink-200 p-12 text-center">
                <span className="text-3xl">🔍</span>
                <p className="mt-3 text-sm font-semibold text-ink-800">محصولی با این مشخصات یافت نشد.</p>
                <p className="mt-1 text-xs text-ink-500">فیلترها را تغییر دهید یا واژه جستجوی دیگری را امتحان کنید.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-3">
                {items.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
