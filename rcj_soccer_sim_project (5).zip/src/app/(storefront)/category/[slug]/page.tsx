import { notFound } from 'next/navigation';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { applyDiscount, toPersianDigits } from '@/lib/currency';
import { ProductCard } from '@/components/ProductCard';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function CategoryPage({ params }: { params: { slug: string } }) {
  const category = await prisma.category.findUnique({ where: { slug: params.slug } });
  if (!category || !category.isActive) notFound();

  const products = await prisma.product.findMany({
    where: { categoryId: category.id, isArchived: false },
    orderBy: { createdAt: 'desc' },
    include: {
      images: { take: 1, orderBy: { sortOrder: 'asc' } },
      views: { take: 1, orderBy: { sortOrder: 'asc' } },
      inventory: true
    }
  });

  const items = products.map((p) => {
    const img = p.images?.[0]?.url || (p as any).views?.[0]?.imageUrl || '/brand/morico-logo.jpg';
    return {
      id: p.id,
      name: p.name,
      slug: p.slug,
      image: img,
      basePrice: p.basePrice,
      discountPercent: p.discountPercent,
      finalPrice: applyDiscount(p.basePrice, p.discountPercent),
      isAvailable: p.isAvailable && (p.inventory?.stock ?? 0) > 0,
      customizationEnabled: p.customizationEnabled
    };
  });

  return (
    <div className="container-morico py-8 sm:py-12">
      {/* Breadcrumbs */}
      <nav className="mb-6 flex items-center gap-2 text-xs text-ink-500">
        <Link href="/" className="hover:text-ink-900 transition">
          صفحه اصلی
        </Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-ink-900 transition">
          فروشگاه
        </Link>
        <span>/</span>
        <span className="text-ink-800 font-medium">{category.name}</span>
      </nav>

      {/* Header */}
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-ink-100 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-ink-900">{category.name}</h1>
          <p className="mt-1 text-xs text-ink-500">مجموعه محصولات {category.name} با امکان چاپ و طراحی اختصاصی</p>
        </div>
        <span className="rounded-full bg-powder-100 px-3 py-1 text-xs font-semibold text-ink-700 w-fit">
          {toPersianDigits(items.length)} محصول
        </span>
      </div>

      {items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-ink-200 p-12 text-center">
          <p className="text-sm font-semibold text-ink-800">محصولی در این دسته‌بندی وجود ندارد.</p>
          <Link href="/shop" className="mt-4 inline-block text-xs font-medium text-ink-600 underline">
            بازگشت به فروشگاه
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
