import { notFound } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { applyDiscount, formatPriceNumber, toPersianDigits } from '@/lib/currency';
import { ProductActions } from '@/components/ProductActions';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug },
    include: {
      images: { orderBy: { sortOrder: 'asc' } },
      views: { orderBy: { sortOrder: 'asc' } },
      inventory: true,
      category: true
    }
  });

  if (!product || product.isArchived) notFound();

  const finalPrice = applyDiscount(product.basePrice, product.discountPercent);
  const stock = product.inventory?.stock ?? 0;
  const isAvailable = product.isAvailable && stock > 0;
  const mainImage = product.images[0]?.url || (product as any).views?.[0]?.imageUrl || '/brand/morico-logo.jpg';

  return (
    <div className="container-morico py-8 sm:py-12">
      {/* Breadcrumbs */}
      <nav className="mb-6 flex items-center gap-2 text-xs text-ink-500">
        <Link href="/" className="hover:text-ink-900 transition">
          صفحه اصلی
        </Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-ink-900 transition">
          فروشگاه
        </Link>
        <span>/</span>
        <Link href={`/category/${product.category.slug}`} className="hover:text-ink-900 transition">
          {product.category.name}
        </Link>
        <span>/</span>
        <span className="text-ink-800 font-medium truncate max-w-[200px]">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        {/* Images Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square overflow-hidden rounded-3xl border border-ink-100 bg-powder-50/70 shadow-card">
            {mainImage ? (
              <Image
                src={mainImage}
                alt={product.name}
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
            ) : (
              <div className="flex h-full items-center justify-center text-xs text-ink-300">بدون تصویر</div>
            )}

            {product.discountPercent > 0 && (
              <span className="absolute right-4 top-4 rounded-lg bg-ink-900 px-2.5 py-1 font-mono text-xs font-bold text-cream shadow-sm">
                ٪{toPersianDigits(product.discountPercent)} تخفیف
              </span>
            )}
          </div>

          {product.images.length > 1 && (
            <div className="grid grid-cols-4 gap-3">
              {product.images.slice(0, 4).map((img) => (
                <div
                  key={img.id}
                  className="relative aspect-square overflow-hidden rounded-2xl border border-ink-100 bg-powder-50"
                >
                  <Image src={img.url} alt={img.altText || product.name} fill className="object-cover" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Product Details & Actions */}
        <div className="flex flex-col justify-between">
          <div>
            <div className="inline-block rounded-md bg-powder-100 px-2.5 py-1 text-xs font-semibold text-powder-800">
              {product.category.name}
            </div>

            <h1 className="mt-3 text-2xl sm:text-3xl font-extrabold text-ink-900 leading-snug">
              {product.name}
            </h1>

            {/* Pricing Section */}
            <div className="mt-5 flex items-baseline gap-2 border-b border-ink-100 pb-5">
              <span className="text-3xl font-extrabold text-ink-900 font-mono">
                {formatPriceNumber(finalPrice)}
              </span>
              <span className="text-sm font-medium text-ink-500">تومان</span>

              {product.discountPercent > 0 && (
                <span className="mr-3 text-base text-ink-400 line-through font-mono">
                  {formatPriceNumber(product.basePrice)}
                </span>
              )}
            </div>

            {/* Stock status */}
            <div className="mt-4 flex items-center gap-2 text-xs">
              <span className={`h-2 w-2 rounded-full ${isAvailable ? 'bg-emerald-500' : 'bg-red-500'}`} />
              <span className="font-medium text-ink-700">
                {isAvailable ? `موجود در انبار (${toPersianDigits(stock)} عدد)` : 'ناموجود'}
              </span>
            </div>

            {product.description && (
              <div className="mt-6 rounded-2xl bg-powder-50/40 p-4 border border-ink-50">
                <h4 className="text-xs font-bold text-ink-800 mb-2">توضیحات و مشخصات محصول:</h4>
                <p className="whitespace-pre-line text-xs sm:text-sm leading-7 text-ink-600">
                  {product.description}
                </p>
              </div>
            )}
          </div>

          <div className="mt-8 pt-6 border-t border-ink-100">
            <ProductActions
              productId={product.id}
              productSlug={product.slug}
              isAvailable={isAvailable}
              customizationEnabled={product.customizationEnabled}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
