import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { withApiErrorHandling } from '@/lib/api-response';
import { z } from 'zod';

const bodySchema = z.object({ isActive: z.boolean() });

export const PATCH = withApiErrorHandling<{ params: { id: string } }>(async (req, { params }) => {
  await requireAdmin();
  const { isActive } = bodySchema.parse(await req.json());
  await prisma.discount.update({ where: { id: params.id }, data: { isActive } });
  return NextResponse.json({ ok: true });
});

export const DELETE = withApiErrorHandling<{ params: { id: string } }>(async (_req, { params }) => {
  await requireAdmin();
  await prisma.discount.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
});
