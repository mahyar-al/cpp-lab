import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { withApiErrorHandling } from '@/lib/api-response';
import { productSchema } from '@/lib/validation';

export const GET = withApiErrorHandling(async () => {
  await requireAdmin();
  const products = await prisma.product.findMany({
    orderBy: { createdAt: 'desc' },
    include: { category: true, inventory: true, images: { take: 1 } }
  });
  return NextResponse.json({ products });
});

export const POST = withApiErrorHandling(async (req: Request) => {
  await requireAdmin();
  const body = await req.json();
  const data = productSchema.parse(body);

  let slug = (data.slug || '').trim().toLowerCase();
  if (!slug) {
    slug = data.name
      .trim()
      .toLowerCase()
      .replace(/[^\w\u0600-\u06FF\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');
  }
  if (!slug || slug === '-') {
    slug = `item-${Date.now().toString().slice(-6)}`;
  }

  const existing = await prisma.product.findUnique({ where: { slug } });
  if (existing) {
    slug = `${slug}-${Date.now().toString().slice(-4)}`;
  }

  let categoryId = data.categoryId;
  const category = await prisma.category.findUnique({ where: { id: categoryId } });
  if (!category) {
    const firstCat = await prisma.category.findFirst({ orderBy: { sortOrder: 'asc' } });
    if (!firstCat) {
      return NextResponse.json({ error: 'لطفاً ابتدا حداقل یک دسته‌بندی ایجاد کنید.' }, { status: 400 });
    }
    categoryId = firstCat.id;
  }

  const imageUrl = data.imageUrl || body.imageUrl || null;

  const product = await prisma.product.create({
    data: {
      name: data.name.trim(),
      slug,
      description: data.description || '',
      categoryId,
      basePrice: data.basePrice,
      discountPercent: data.discountPercent,
      isAvailable: data.isAvailable,
      customizationEnabled: data.customizationEnabled,
      inventory: { create: { stock: data.stock } },
      ...(imageUrl
        ? {
            images: {
              create: {
                url: imageUrl,
                altText: data.name.trim(),
                sortOrder: 0
              }
            }
          }
        : {})
    }
  });

  return NextResponse.json({ id: product.id, slug: product.slug });
});
