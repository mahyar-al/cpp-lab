import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/auth';
import { withApiErrorHandling } from '@/lib/api-response';
import { productSchema } from '@/lib/validation';
import { z } from 'zod';

export const GET = withApiErrorHandling<{ params: { id: string } }>(async (_req, { params }) => {
  await requireAdmin();
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: {
      category: true,
      images: { orderBy: { sortOrder: 'asc' } },
      inventory: true,
      views: { orderBy: { sortOrder: 'asc' }, include: { printableArea: true } }
    }
  });
  if (!product) {
    return NextResponse.json({ error: 'محصول یافت نشد.' }, { status: 404 });
  }
  return NextResponse.json({ product });
});

const updateSchema = productSchema.partial().extend({
  isArchived: z.boolean().optional()
});

export const PATCH = withApiErrorHandling<{ params: { id: string } }>(async (req, { params }) => {
  await requireAdmin();
  const data = updateSchema.parse(await req.json());

  const { stock, ...productFields } = data;

  await prisma.product.update({
    where: { id: params.id },
    data: productFields
  });

  if (typeof stock === 'number') {
    await prisma.inventory.upsert({
      where: { productId: params.id },
      create: { productId: params.id, stock },
      update: { stock }
    });
  }

  return NextResponse.json({ ok: true });
});

export const DELETE = withApiErrorHandling<{ params: { id: string } }>(async (_req, { params }) => {
  await requireAdmin();
  const id = params.id;

  const product = await prisma.product.findUnique({ where: { id } });
  if (!product) {
    return NextResponse.json({ error: 'محصول مورد نظر یافت نشد.' }, { status: 404 });
  }

  // 1. Delete dependent relations (inventory, images, views, printable areas, cart items)
  await prisma.cartItem.deleteMany({ where: { productId: id } }).catch(() => {});
  await prisma.inventory.deleteMany({ where: { productId: id } }).catch(() => {});
  await prisma.productImage.deleteMany({ where: { productId: id } }).catch(() => {});

  const views = await prisma.productView.findMany({ where: { productId: id } });
  for (const v of views) {
    await prisma.printableArea.deleteMany({ where: { productViewId: v.id } }).catch(() => {});
  }
  await prisma.productView.deleteMany({ where: { productId: id } }).catch(() => {});

  // 2. Hard delete product
  await prisma.product.delete({ where: { id } });

  return NextResponse.json({ ok: true, deleted: true, message: 'محصول با موفقیت حذف شد.' });
});
