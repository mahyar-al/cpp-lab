import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireUser } from '@/lib/auth';
import { withApiErrorHandling } from '@/lib/api-response';
import { checkoutSchema } from '@/lib/validation';
import { priceCartForUser } from '@/server/pricing';
import { getActivePaymentProvider, getActivePaymentProviderName, isPaymentGatewayConfigured } from '@/server/payments/registry';

function generateOrderNumber(): string {
  const stamp = Date.now().toString().slice(-8);
  const rand = Math.floor(Math.random() * 900 + 100);
  return `MRC-${stamp}${rand}`;
}

export const POST = withApiErrorHandling(async (req: Request) => {
  const user = await requireUser();
  const body = await req.json();
  const data = checkoutSchema.parse(body);

  // Source of truth for pricing — never trust anything the browser sends.
  const priced = await priceCartForUser(user.id, data.discountCode);

  const order = await prisma.order.create({
    data: {
      orderNumber: generateOrderNumber(),
      userId: user.id,
      status: 'PENDING_PAYMENT',
      fullName: data.fullName,
      mobile: data.mobile,
      email: data.email || null,
      province: data.province,
      city: data.city,
      address: data.address,
      postalCode: data.postalCode,
      notes: data.notes,
      subtotal: priced.subtotal,
      discountAmount: priced.discountAmount,
      discountCode: priced.appliedDiscountCode,
      shippingAmount: priced.shippingAmount,
      totalAmount: priced.totalAmount,
      items: {
        create: priced.items.map((item) => ({
          productId: item.productId,
          productNameSnapshot: item.name,
          unitPriceSnapshot: item.unitPrice,
          quantity: item.quantity,
          customizationId: item.customizationId ?? undefined
        }))
      }
    }
  });

  const providerName = getActivePaymentProviderName();
  const provider = getActivePaymentProvider();
  const isConfigured = isPaymentGatewayConfigured();

  if (!isConfigured) {
    // Gateway is not connected yet - keep order in PENDING_PAYMENT, register zero revenue
    return NextResponse.json(
      {
        error: 'درگاه پرداخت هنوز توسط مدیریت متصل نشده است. سفارش شما در وضعیت «در انتظار پرداخت» ثبت شد؛ تا زمان اتصال درگاه و واریز واقعی، هیچ پرداختی ثبت نخواهد شد.',
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: 'PENDING_PAYMENT'
      },
      { status: 400 }
    );
  }

  const callbackUrl = `${process.env.APP_URL ?? new URL(req.url).origin}/api/payment/${providerName}/callback`;

  const paymentRequest = await provider.requestPayment({
    amountToman: priced.totalAmount,
    description: `پرداخت سفارش ${order.orderNumber} - موریکو`,
    callbackUrl,
    orderId: order.id,
    mobile: data.mobile,
    email: data.email || undefined
  });

  if (!paymentRequest.ok) {
    await prisma.payment.create({
      data: {
        orderId: order.id,
        provider: providerName,
        amount: priced.totalAmount,
        status: 'FAILED'
      }
    });
    return NextResponse.json({ error: paymentRequest.errorMessageFa, orderId: order.id }, { status: 502 });
  }

  await prisma.payment.create({
    data: {
      orderId: order.id,
      provider: providerName,
      authority: paymentRequest.authority,
      amount: priced.totalAmount,
      status: 'PENDING'
    }
  });

  return NextResponse.json({ redirectUrl: paymentRequest.redirectUrl, orderId: order.id });
});
