import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { formatToman, toPersianDigits } from '@/lib/currency';

const STATUS_LABELS: Record<string, string> = {
  PENDING_PAYMENT: 'در انتظار پرداخت',
  PAID: 'پرداخت شده',
  PROCESSING: 'در حال پردازش',
  PRINTING: 'در حال چاپ',
  SHIPPED: 'ارسال شده',
  DELIVERED: 'تحویل داده شده',
  CANCELED: 'لغو شده'
};

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminOrdersPage() {
  const orders = await prisma.order.findMany({
    orderBy: { createdAt: 'desc' },
    include: { items: true }
  });

  return (
    <div>
      <h1 className="mb-6 text-xl font-semibold text-ink-900">سفارش‌ها</h1>
      <div className="card divide-y divide-ink-50">
        {orders.map((o) => (
          <Link
            key={o.id}
            href={`/admin/orders/${o.id}`}
            className="flex flex-wrap items-center justify-between gap-3 p-4 hover:bg-powder-50"
          >
            <div>
              <p className="text-sm font-medium text-ink-900">{toPersianDigits(o.orderNumber)}</p>
              <p className="text-xs text-ink-400">
                {o.fullName} — {o.items.length} قلم
                {o.discountCode && (
                  <>
                    {' — کد تخفیف: '}
                    <span dir="ltr" className="font-medium text-ink-600">
                      {o.discountCode}
                    </span>
                  </>
                )}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <span className="badge bg-powder-100 text-ink-700">{STATUS_LABELS[o.status] ?? o.status}</span>
              <span className="text-sm font-medium text-ink-900">{formatToman(o.totalAmount)}</span>
            </div>
          </Link>
        ))}
        {orders.length === 0 && <p className="p-6 text-sm text-ink-400">هنوز سفارشی ثبت نشده است.</p>}
      </div>
    </div>
  );
}
