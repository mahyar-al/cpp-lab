import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { formatToman, toPersianDigits } from '@/lib/currency';
import { isPaymentGatewayConfigured } from '@/server/payments/registry';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminDashboardPage() {
  const isGatewayConfigured = isPaymentGatewayConfigured();
  const [
    totalProducts,
    availableProducts,
    outOfStock,
    totalOrders,
    pendingOrders,
    paidOrders,
    revenue,
    totalCustomizations,
    recentCustomizations,
    recentAssets,
    products
  ] = await Promise.all([
    prisma.product.count({ where: { isArchived: false } }),
    prisma.product.count({ where: { isArchived: false, isAvailable: true } }),
    prisma.inventory.count({ where: { stock: 0 } }),
    prisma.order.count(),
    prisma.order.count({ where: { status: 'PENDING_PAYMENT' } }),
    prisma.order.count({ where: { status: { not: 'PENDING_PAYMENT' } } }),
    prisma.order.aggregate({
      where: { status: { in: ['PAID', 'PROCESSING', 'PRINTING', 'SHIPPED', 'DELIVERED'] } },
      _sum: { totalAmount: true }
    }),
    prisma.customization.count(),
    prisma.customization.findMany({
      take: 6,
      orderBy: { createdAt: 'desc' },
      include: {
        orderItem: { include: { order: { include: { user: true } } } },
        cartItem: { include: { cart: { include: { user: true } } } }
      }
    }),
    prisma.designAsset.findMany({
      take: 6,
      orderBy: { createdAt: 'desc' },
      include: { user: true }
    }),
    prisma.product.findMany()
  ]);

  const productMap = new Map((products || []).map((p) => [p.id, p]));

  const cards = [
    { label: 'تعداد محصولات', value: totalProducts },
    { label: 'محصولات موجود', value: availableProducts },
    { label: 'محصولات ناموجود', value: outOfStock },
    { label: 'کل سفارش‌ها', value: totalOrders },
    { label: 'در انتظار پرداخت', value: pendingOrders },
    { label: 'سفارش‌های پرداخت‌شده', value: paidOrders },
    { label: 'طرح‌های شخصی‌سازی کاربران', value: totalCustomizations, highlight: true }
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-bold text-ink-900">داشبورد مدیریت موریکو</h1>
        <p className="mt-1 text-xs text-ink-500">
          نمای کلی وضعیت فروشگاه، سفارش‌ها و طرح‌های در حال طراحی توسط مشتریان.
        </p>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className={`card p-5 ${c.highlight ? 'border-powder-400 bg-powder-50/60' : ''}`}>
            <p className="text-xs font-semibold text-ink-500">{c.label}</p>
            <p className={`mt-2 text-2xl font-black ${c.highlight ? 'text-powder-900' : 'text-ink-900'}`}>
              {toPersianDigits(c.value)}
            </p>
          </div>
        ))}
        <div className="card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-ink-500">درآمد (سفارش‌های پرداخت‌شده)</p>
            <span
              className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                isGatewayConfigured
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {isGatewayConfigured ? 'درگاه متصل' : 'درگاه نامتصل'}
            </span>
          </div>
          <p className="mt-2 text-2xl font-black text-emerald-600">
            {formatToman(revenue._sum.totalAmount ?? 0)}
          </p>
        </div>
      </div>

      {/* Customer Customizations Live Monitor */}
      <div className="card p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-ink-100 pb-3">
          <div>
            <h2 className="text-base font-bold text-ink-900">طرح‌ها و فرآیند طراحی اخیر مشتریان 🎨</h2>
            <p className="text-xs text-ink-500 mt-0.5">
              محصولات و طرح‌هایی که اخیراً توسط کاربران با آپلود تصویر یا متن شخصی‌سازی شده‌اند.
            </p>
          </div>
          <Link
            href="/admin/customizations"
            className="text-xs font-bold text-powder-900 hover:text-powder-950 flex items-center gap-1"
          >
            <span>مشاهده همه طرح‌ها و فایل‌ها</span>
            <span>←</span>
          </Link>
        </div>

        {recentCustomizations.length === 0 ? (
          <p className="py-6 text-center text-xs text-ink-400">هنوز طرحی ساخته نشده است.</p>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {recentCustomizations.map((c: any) => {
              const customerName =
                c.orderItem?.order?.fullName ||
                c.orderItem?.order?.user?.name ||
                c.cartItem?.cart?.user?.name ||
                'مشتری استودیو';

              const isOrdered = Boolean(c.orderItem?.order);
              const isInCart = Boolean(c.cartItem?.cart);

              return (
                <div
                  key={c.id}
                  className="flex items-center gap-3 rounded-xl border border-ink-100 bg-powder-50/40 p-3 transition hover:border-ink-300 hover:bg-white"
                >
                  <div className="relative h-16 w-16 shrink-0 rounded-lg border border-ink-100 bg-white p-1 overflow-hidden flex items-center justify-center">
                    {c.previewUrl ? (
                      <img src={c.previewUrl} alt="preview" className="h-full w-full object-contain" />
                    ) : (
                      <span className="text-xl">👕</span>
                    )}
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <p className="text-xs font-bold text-ink-900 truncate">
                      {productMap.get(c.productId)?.name || 'محصول سفارشی'}
                    </p>
                    <p className="text-[11px] text-ink-500 truncate">
                      طراح: {customerName}
                    </p>
                    <div className="flex items-center gap-2">
                      {isOrdered && (
                        <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold text-emerald-800">
                          سفارش #{c.orderItem.order.orderNumber}
                        </span>
                      )}
                      {!isOrdered && isInCart && (
                        <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">
                          در سبد خرید
                        </span>
                      )}
                      {!isOrdered && !isInCart && (
                        <span className="rounded bg-ink-100 px-1.5 py-0.5 text-[10px] font-medium text-ink-700">
                          پیش‌نویس
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Customer Uploaded Files Quick Gallery */}
      <div className="card p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-ink-100 pb-3">
          <div>
            <h2 className="text-base font-bold text-ink-900">آخرین تصاویر و لوگوهای آپلودشده مشتریان 🖼️</h2>
            <p className="text-xs text-ink-500 mt-0.5">
              فایل‌های خام یا برش‌خورده‌ای که کاربران در ادیتور آنلاین بارگذاری کرده‌اند.
            </p>
          </div>
          <Link
            href="/admin/customizations"
            className="text-xs font-bold text-powder-900 hover:text-powder-950 flex items-center gap-1"
          >
            <span>مدیریت فایل‌ها</span>
            <span>←</span>
          </Link>
        </div>

        {recentAssets.length === 0 ? (
          <p className="py-6 text-center text-xs text-ink-400">هنوز فایلی آپلود نشده است.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-6">
            {recentAssets.map((asset: any) => (
              <div
                key={asset.id}
                className="group relative flex flex-col justify-between overflow-hidden rounded-xl border border-ink-100 bg-white p-2"
              >
                <div className="relative aspect-square w-full rounded bg-powder-50/60 overflow-hidden flex items-center justify-center">
                  <img src={asset.url} alt="asset" className="h-full w-full object-contain p-1" />
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[10px] text-ink-500">
                  <span className="truncate">{asset.user?.name || 'مشتری'}</span>
                  <a href={asset.url} target="_blank" rel="noreferrer" className="text-powder-800 font-bold hover:underline">
                    دانلود
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
