import { prisma } from '@/lib/prisma';
import { DiscountForm } from '@/components/admin/DiscountForm';
import { DiscountToggle } from '@/components/admin/DiscountToggle';
import { toPersianDigits } from '@/lib/currency';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminDiscountsPage() {
  const discounts = await prisma.discount.findMany({ orderBy: { createdAt: 'desc' } });

  return (
    <div>
      <h1 className="mb-6 text-xl font-semibold text-ink-900">کدهای تخفیف</h1>
      <p className="mb-6 text-xs leading-6 text-ink-400">
        کد بسازید و به مشتری موردنظر بدهید. با تنظیم «حداکثر تعداد استفاده» روی ۱، کد فقط یک بار
        قابل استفاده خواهد بود.
      </p>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
        <div className="card divide-y divide-ink-50">
          {discounts.length === 0 && <p className="p-6 text-sm text-ink-400">هنوز کد تخفیفی ثبت نشده است.</p>}
          {discounts.map((d) => {
            const expired = d.expiresAt ? d.expiresAt < new Date() : false;
            const exhausted = d.usesCount >= d.maxUses;
            const statusLabel = !d.isActive
              ? 'غیرفعال'
              : expired
                ? 'منقضی‌شده'
                : exhausted
                  ? 'مصرف‌شده'
                  : 'فعال';
            const statusClass =
              statusLabel === 'فعال' ? 'bg-green-50 text-green-700' : 'bg-ink-100 text-ink-500';

            return (
              <div key={d.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
                <div>
                  <p dir="ltr" className="text-left text-sm font-medium text-ink-900">
                    {d.code}
                  </p>
                  <p className="text-xs text-ink-400">
                    ٪{toPersianDigits(d.percent)} تخفیف — استفاده‌شده: {toPersianDigits(d.usesCount)} از{' '}
                    {toPersianDigits(d.maxUses)}
                    {d.expiresAt && ` — انقضا: ${new Date(d.expiresAt).toLocaleDateString('fa-IR')}`}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`badge ${statusClass}`}>{statusLabel}</span>
                  <DiscountToggle discountId={d.id} isActive={d.isActive} />
                </div>
              </div>
            );
          })}
        </div>

        <div className="card p-5">
          <h2 className="mb-4 text-sm font-medium text-ink-900">کد جدید</h2>
          <DiscountForm />
        </div>
      </div>
    </div>
  );
}
