import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { formatToman, toPersianDigits } from '@/lib/currency';
import { ProductRowActions } from '@/components/admin/ProductRowActions';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminProductsPage() {
  const products = await prisma.product.findMany({
    orderBy: { createdAt: 'desc' },
    include: { category: true, inventory: true }
  });

  return (
    <div>
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-ink-900">مدیریت محصولات</h1>
          <p className="mt-1 text-xs text-ink-500">
            تعداد کل: {toPersianDigits(products.length)} محصول
          </p>
        </div>
        <Link href="/admin/products/new" className="btn-primary text-sm shadow-sm">
          + افزودن محصول جدید
        </Link>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-100 text-right text-ink-500">
              <th className="p-4 font-medium">نام محصول</th>
              <th className="p-4 font-medium">دسته‌بندی</th>
              <th className="p-4 font-medium">قیمت</th>
              <th className="p-4 font-medium">موجودی</th>
              <th className="p-4 font-medium">وضعیت</th>
              <th className="p-4 font-medium text-left">عملیات</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-b border-ink-50 last:border-0 hover:bg-ink-50/40 transition">
                <td className="p-4">
                  <Link href={`/admin/products/${p.id}/edit`} className="font-semibold text-ink-900 hover:text-powder-800 hover:underline">
                    {p.name}
                  </Link>
                  <p className="text-[10px] text-ink-400 font-mono" dir="ltr">/{p.slug}</p>
                </td>
                <td className="p-4 text-ink-600">{p.category?.name || 'نامشخص'}</td>
                <td className="p-4 text-ink-600 font-medium">{formatToman(p.basePrice)}</td>
                <td className="p-4 text-ink-600">{toPersianDigits(p.inventory?.stock ?? 0)}</td>
                <td className="p-4">
                  <span
                    className={`badge ${
                      p.isArchived
                        ? 'bg-ink-100 text-ink-500'
                        : p.isAvailable
                          ? 'bg-green-50 text-green-700'
                          : 'bg-red-50 text-red-600'
                    }`}
                  >
                    {p.isArchived ? 'آرشیو شده' : p.isAvailable ? 'فعال' : 'غیرفعال'}
                  </span>
                </td>
                <td className="p-4 text-left">
                  <ProductRowActions
                    productId={p.id}
                    isArchived={p.isArchived}
                    isAvailable={p.isAvailable}
                    productName={p.name}
                  />
                </td>
              </tr>
            ))}
            {products.length === 0 && (
              <tr>
                <td colSpan={6} className="p-10 text-center text-ink-400">
                  هنوز محصولی ثبت نشده است. از دکمه «افزودن محصول جدید» برای ساخت اولین محصول استفاده کنید.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
