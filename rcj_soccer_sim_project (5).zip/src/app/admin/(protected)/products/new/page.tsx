import { prisma } from '@/lib/prisma';
import { NewProductForm } from '@/components/admin/NewProductForm';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function NewProductPage() {
  const categories = await prisma.category.findMany({ orderBy: { sortOrder: 'asc' } });

  return (
    <div>
      <h1 className="mb-6 text-xl font-semibold text-ink-900">محصول جدید</h1>
      {categories.length === 0 ? (
        <p className="card p-6 text-sm text-ink-500">
          ابتدا از بخش «دسته‌بندی‌ها» حداقل یک دسته‌بندی بسازید.
        </p>
      ) : (
        <NewProductForm categories={categories.map((c) => ({ id: c.id, name: c.name }))} />
      )}
    </div>
  );
}
