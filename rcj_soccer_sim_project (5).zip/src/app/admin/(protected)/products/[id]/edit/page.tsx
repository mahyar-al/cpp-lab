import { notFound } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { EditProductForm } from '@/components/admin/EditProductForm';
import { ProductImagesManager } from '@/components/admin/ProductImagesManager';
import { ProductViewsManager } from '@/components/admin/ProductViewsManager';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const [product, categories] = await Promise.all([
    prisma.product.findUnique({
      where: { id: params.id },
      include: {
        images: { orderBy: { sortOrder: 'asc' } },
        inventory: true,
        views: { orderBy: { sortOrder: 'asc' }, include: { printableArea: true } }
      }
    }),
    prisma.category.findMany({ orderBy: { sortOrder: 'asc' } })
  ]);

  if (!product) notFound();

  return (
    <div className="space-y-8">
      <h1 className="text-xl font-semibold text-ink-900">ویرایش محصول: {product.name}</h1>

      <section className="card p-6">
        <h2 className="mb-4 text-sm font-medium text-ink-900">اطلاعات پایه</h2>
        <EditProductForm
          productId={product.id}
          categories={categories.map((c) => ({ id: c.id, name: c.name }))}
          initial={{
            name: product.name,
            slug: product.slug,
            categoryId: product.categoryId,
            description: product.description,
            basePrice: product.basePrice,
            discountPercent: product.discountPercent,
            stock: product.inventory?.stock ?? 0,
            isAvailable: product.isAvailable,
            customizationEnabled: product.customizationEnabled
          }}
        />
      </section>

      <section className="card p-6">
        <h2 className="mb-4 text-sm font-medium text-ink-900">تصاویر محصول</h2>
        <ProductImagesManager
          productId={product.id}
          initialImages={product.images.map((i) => ({ id: i.id, url: i.url }))}
        />
      </section>

      <section className="card p-6">
        <h2 className="mb-4 text-sm font-medium text-ink-900">نماها و محدودهٔ چاپ</h2>
        <p className="mb-4 text-xs leading-6 text-ink-400">
          هر محصول می‌تواند چند نما داشته باشد (مثلاً جلو/پشت، یا چپ/راست). محدودهٔ چاپ نسبت به
          تصویر نما و در فضای مرجع ۶۰۰×۶۰۰ پیکسل تعریف می‌شود.
        </p>
        <ProductViewsManager
          productId={product.id}
          initialViews={product.views.map((v) => ({
            id: v.id,
            name: v.name,
            imageUrl: v.imageUrl,
            sortOrder: v.sortOrder,
            printableArea: v.printableArea
              ? {
                  x: v.printableArea.x,
                  y: v.printableArea.y,
                  width: v.printableArea.width,
                  height: v.printableArea.height,
                  minDesignWidth: v.printableArea.minDesignWidth,
                  maxDesignWidth: v.printableArea.maxDesignWidth,
                  minDesignHeight: v.printableArea.minDesignHeight,
                  maxDesignHeight: v.printableArea.maxDesignHeight
                }
              : null
          }))}
        />
      </section>
    </div>
  );
}
