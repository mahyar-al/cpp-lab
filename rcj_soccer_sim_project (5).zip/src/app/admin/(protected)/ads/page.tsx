import { prisma } from '@/lib/prisma';
import { AdForm } from '@/components/admin/AdForm';
import { AdRow } from '@/components/admin/AdRow';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminAdsPage() {
  const ads = await prisma.advertisement.findMany({ orderBy: [{ placement: 'asc' }, { sortOrder: 'asc' }] });

  return (
    <div>
      <h1 className="mb-6 text-xl font-semibold text-ink-900">تبلیغات</h1>
      <p className="mb-6 text-xs leading-6 text-ink-400">
        بنر تبلیغاتی برای صفحه اصلی یا فروشگاه اضافه کنید. فقط بنرهای «فعال» روی سایت نمایش داده می‌شوند.
      </p>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-3">
          {ads.length === 0 && <p className="card p-6 text-sm text-ink-400">هنوز تبلیغی ثبت نشده است.</p>}
          {ads.map((ad) => (
            <AdRow
              key={ad.id}
              id={ad.id}
              title={ad.title}
              imageUrl={ad.imageUrl}
              placement={ad.placement}
              isActive={ad.isActive}
            />
          ))}
        </div>

        <div className="card p-5">
          <h2 className="mb-4 text-sm font-medium text-ink-900">بنر جدید</h2>
          <AdForm />
        </div>
      </div>
    </div>
  );
}
