import { prisma } from '@/lib/prisma';
import { CategoriesManager, CategoryItem } from '@/components/admin/CategoriesManager';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminCategoriesPage() {
  const rawCategories = await prisma.category.findMany({
    orderBy: { sortOrder: 'asc' },
    include: { _count: { select: { products: true } } }
  });

  const categories: CategoryItem[] = rawCategories.map((c) => ({
    id: c.id,
    name: c.name,
    slug: c.slug,
    isActive: c.isActive,
    sortOrder: c.sortOrder,
    _count: {
      products: (c as any)._count?.products ?? 0
    }
  }));

  return (
    <div className="space-y-6">
      <div className="border-b border-ink-100 pb-4">
        <h1 className="text-xl font-bold text-ink-900">مدیریت دسته‌بندی‌ها</h1>
        <p className="mt-1 text-xs text-ink-500">
          دسته‌بندی‌های محصولات فروشگاه را ایجاد، ویرایش، حذف و مدیریت کنید.
        </p>
      </div>

      <CategoriesManager initialCategories={categories} />
    </div>
  );
}
