'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import type { SiteContent } from '@/lib/site-content';
import { clientFetch } from '@/lib/client-fetch';

type Tab = 'announcement' | 'hero' | 'studio' | 'steps' | 'faqs' | 'footer';

export default function AdminContentPage() {
  const [content, setContent] = useState<SiteContent | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('hero');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    clientFetch('/api/admin/content')
      .then((res) => res.json())
      .then((data) => {
        if (data.content) setContent(data.content);
      })
      .catch((err) => setError('خطا در دریافت اطلاعات: ' + err.message))
      .finally(() => setLoading(false));
  }, []);

  async function handleSave() {
    if (!content) return;
    setSaving(true);
    setError(null);
    setSavedSuccess(false);

    try {
      const res = await clientFetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'خطا در ذخیره تغییرات');
        return;
      }
      setContent(data.content);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 4000);
    } catch (err: any) {
      setError(err.message || 'خطای شبکه در ذخیره اطلاعات');
    } finally {
      setSaving(false);
    }
  }

  async function handleReset() {
    if (!confirm('آیا از بازنشانی تمام متون به حالت پیش‌فرض اولیه اطمینان دارید؟')) return;
    setSaving(true);
    try {
      const res = await clientFetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reset' })
      });
      const data = await res.json();
      if (data.content) {
        setContent(data.content);
        setSavedSuccess(true);
        setTimeout(() => setSavedSuccess(false), 4000);
      }
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="p-8 text-center text-sm text-ink-500">در حال بارگذاری تنظیمات محتوا...</div>;
  }

  if (!content) {
    return (
      <div className="p-8 text-center text-sm text-red-600">
        خطا در اتصال به سرور محتوا. لطفاً صفحه را تازه‌سازی کنید.
      </div>
    );
  }

  return (
    <div className="max-w-4xl space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-ink-100 pb-4">
        <div>
          <h1 className="text-xl font-bold text-ink-900">مدیریت نوشته‌های وب‌سایت</h1>
          <p className="mt-1 text-xs text-ink-500">
            تمام عناوین، توضیحات، پیام‌ها و سوالات متداول سایت را از اینجا تغییر دهید و ذخیره کنید.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleReset}
            disabled={saving}
            className="rounded-xl border border-ink-200 px-3.5 py-2 text-xs font-medium text-ink-600 hover:bg-powder-100 transition"
          >
            بازنشانی پیش‌فرض
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="btn-primary !px-6 !py-2 text-xs font-semibold shadow-soft flex items-center gap-1.5"
          >
            {saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-xs font-bold text-emerald-800 flex items-center gap-2 animate-fadeUp">
          <span>✓</span>
          <span>تغییرات با موفقیت ذخیره شد و در صفحه اصلی سایت اعمال گردید.</span>
        </div>
      )}

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-xs font-bold text-red-700">
          {error}
        </div>
      )}

      {/* Tabs Bar */}
      <div className="flex flex-wrap gap-1.5 border-b border-ink-100 pb-2">
        {[
          { id: 'announcement', label: 'نوار بالای سایت (اعلان)' },
          { id: 'hero', label: 'هیرو و صفحه اصلی' },
          { id: 'studio', label: 'بنر استودیو طراحی' },
          { id: 'steps', label: 'مراحل سفارش' },
          { id: 'faqs', label: 'سوالات متداول (FAQ)' },
          { id: 'footer', label: 'فوتر و تماس' }
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id as Tab)}
            className={`rounded-xl px-4 py-2 text-xs font-medium transition ${
              activeTab === tab.id
                ? 'bg-ink-900 text-cream shadow-sm'
                : 'bg-white text-ink-600 hover:bg-powder-100 hover:text-ink-900'
            }`}
          >
            {tab.label}
          </button>
        ))}

        <Link
          href="/admin/navigation"
          className="rounded-xl px-4 py-2 text-xs font-semibold bg-powder-100 text-powder-900 hover:bg-powder-200 transition flex items-center gap-1.5"
        >
          <span>منوی بالای سایت (هدر)</span>
          <span className="text-[10px] text-powder-600">⚙</span>
        </Link>
      </div>

      {/* Tab 1: Announcement Bar */}
      {activeTab === 'announcement' && (
        <div className="rounded-2xl border border-ink-100 bg-white p-6 shadow-card space-y-4">
          <div className="flex items-center justify-between border-b border-ink-50 pb-3">
            <h2 className="text-sm font-bold text-ink-900">نوار پیام بالای سایت</h2>
            <label className="flex items-center gap-2 text-xs font-medium text-ink-700 cursor-pointer">
              <input
                type="checkbox"
                checked={content.announcement.enabled}
                onChange={(e) =>
                  setContent({
                    ...content,
                    announcement: { ...content.announcement, enabled: e.target.checked }
                  })
                }
                className="h-4 w-4 rounded border-ink-300 text-ink-900 focus:ring-powder-300"
              />
              فعال بودن نوار اعلان
            </label>
          </div>

          <div>
            <label className="label text-xs">متن اصلی پیام اعلان</label>
            <input
              className="input text-xs"
              value={content.announcement.text}
              onChange={(e) =>
                setContent({
                  ...content,
                  announcement: { ...content.announcement, text: e.target.value }
                })
              }
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label text-xs">برچسب پیش از کد تخفیف</label>
              <input
                className="input text-xs"
                value={content.announcement.discountLabel}
                onChange={(e) =>
                  setContent({
                    ...content,
                    announcement: { ...content.announcement, discountLabel: e.target.value }
                  })
                }
              />
            </div>
            <div>
              <label className="label text-xs">کد تخفیف نمایش داده شده</label>
              <input
                className="input text-xs font-mono"
                dir="ltr"
                value={content.announcement.discountCode}
                onChange={(e) =>
                  setContent({
                    ...content,
                    announcement: { ...content.announcement, discountCode: e.target.value }
                  })
                }
              />
            </div>
          </div>

          <div>
            <label className="label text-xs">شماره تماس پشتیبانی بالای سایت</label>
            <input
              className="input text-xs"
              value={content.announcement.supportPhone}
              onChange={(e) =>
                setContent({
                  ...content,
                  announcement: { ...content.announcement, supportPhone: e.target.value }
                })
              }
            />
          </div>
        </div>
      )}

      {/* Tab 2: Hero Section */}
      {activeTab === 'hero' && (
        <div className="rounded-2xl border border-ink-100 bg-white p-6 shadow-card space-y-5">
          <h2 className="text-sm font-bold text-ink-900 border-b border-ink-50 pb-3">بخش هیرو (Hero) صفحه اصلی</h2>

          <div>
            <label className="label text-xs">برچسب کوچک بالای تیتر اصلی</label>
            <input
              className="input text-xs"
              value={content.hero.badge}
              onChange={(e) =>
                setContent({
                  ...content,
                  hero: { ...content.hero, badge: e.target.value }
                })
              }
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label text-xs">تیتر اول (Headline)</label>
              <input
                className="input text-xs"
                value={content.hero.headline}
                onChange={(e) =>
                  setContent({
                    ...content,
                    hero: { ...content.hero, headline: e.target.value }
                  })
                }
              />
            </div>
            <div>
              <label className="label text-xs">تیتر دوم / رنگی (Sub-headline)</label>
              <input
                className="input text-xs"
                value={content.hero.subheadline}
                onChange={(e) =>
                  setContent({
                    ...content,
                    hero: { ...content.hero, subheadline: e.target.value }
                  })
                }
              />
            </div>
          </div>

          <div>
            <label className="label text-xs">متن پاراگراف توضیحات هیرو</label>
            <textarea
              rows={3}
              className="input text-xs leading-6"
              value={content.hero.description}
              onChange={(e) =>
                setContent({
                  ...content,
                  hero: { ...content.hero, description: e.target.value }
                })
              }
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-ink-50 pt-4">
            <div>
              <label className="label text-xs">عنوان دکمه اول (CTA اصلی)</label>
              <input
                className="input text-xs"
                value={content.hero.primaryCtaText}
                onChange={(e) =>
                  setContent({
                    ...content,
                    hero: { ...content.hero, primaryCtaText: e.target.value }
                  })
                }
              />
            </div>
            <div>
              <label className="label text-xs">عنوان دکمه دوم (CTA ثانویه)</label>
              <input
                className="input text-xs"
                value={content.hero.secondaryCtaText}
                onChange={(e) =>
                  setContent({
                    ...content,
                    hero: { ...content.hero, secondaryCtaText: e.target.value }
                  })
                }
              />
            </div>
          </div>

          <div className="border-t border-ink-50 pt-4 space-y-3">
            <h3 className="text-xs font-bold text-ink-900">آمارهای سه‌گانه پایین هیرو</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="rounded-xl border border-ink-100 bg-powder-50/50 p-3 space-y-2">
                <label className="text-[11px] font-semibold text-ink-700">آمار اول</label>
                <input
                  className="input text-xs"
                  placeholder="مقدار (مثلاً ۱۰۰٪)"
                  value={content.hero.stats.stat1Value}
                  onChange={(e) =>
                    setContent({
                      ...content,
                      hero: {
                        ...content.hero,
                        stats: { ...content.hero.stats, stat1Value: e.target.value }
                      }
                    })
                  }
                />
                <input
                  className="input text-xs"
                  placeholder="عنوان توضیح"
                  value={content.hero.stats.stat1Label}
                  onChange={(e) =>
                    setContent({
                      ...content,
                      hero: {
                        ...content.hero,
                        stats: { ...content.hero.stats, stat1Label: e.target.value }
                      }
                    })
                  }
                />
              </div>

              <div className="rounded-xl border border-ink-100 bg-powder-50/50 p-3 space-y-2">
                <label className="text-[11px] font-semibold text-ink-700">آمار دوم</label>
                <input
                  className="input text-xs"
                  placeholder="مقدار (مثلاً DTG)"
                  value={content.hero.stats.stat2Value}
                  onChange={(e) =>
                    setContent({
                      ...content,
                      hero: {
                        ...content.hero,
                        stats: { ...content.hero.stats, stat2Value: e.target.value }
                      }
                    })
                  }
                />
                <input
                  className="input text-xs"
                  placeholder="عنوان توضیح"
                  value={content.hero.stats.stat2Label}
                  onChange={(e) =>
                    setContent({
                      ...content,
                      hero: {
                        ...content.hero,
                        stats: { ...content.hero.stats, stat2Label: e.target.value }
                      }
                    })
                  }
                />
              </div>

              <div className="rounded-xl border border-ink-100 bg-powder-50/50 p-3 space-y-2">
                <label className="text-[11px] font-semibold text-ink-700">آمار سوم</label>
                <input
                  className="input text-xs"
                  placeholder="مقدار (مثلاً ۲-۳)"
                  value={content.hero.stats.stat3Value}
                  onChange={(e) =>
                    setContent({
                      ...content,
                      hero: {
                        ...content.hero,
                        stats: { ...content.hero.stats, stat3Value: e.target.value }
                      }
                    })
                  }
                />
                <input
                  className="input text-xs"
                  placeholder="عنوان توضیح"
                  value={content.hero.stats.stat3Label}
                  onChange={(e) =>
                    setContent({
                      ...content,
                      hero: {
                        ...content.hero,
                        stats: { ...content.hero.stats, stat3Label: e.target.value }
                      }
                    })
                  }
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Studio Banner */}
      {activeTab === 'studio' && (
        <div className="rounded-2xl border border-ink-100 bg-white p-6 shadow-card space-y-5">
          <h2 className="text-sm font-bold text-ink-900 border-b border-ink-50 pb-3">بنر معرفی استودیو آنلاین</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label text-xs">نشان بالای بنر</label>
              <input
                className="input text-xs font-mono"
                value={content.studioBanner.badge}
                onChange={(e) =>
                  setContent({
                    ...content,
                    studioBanner: { ...content.studioBanner, badge: e.target.value }
                  })
                }
              />
            </div>
            <div>
              <label className="label text-xs">تیتر اصلی استودیو</label>
              <input
                className="input text-xs"
                value={content.studioBanner.title}
                onChange={(e) =>
                  setContent({
                    ...content,
                    studioBanner: { ...content.studioBanner, title: e.target.value }
                  })
                }
              />
            </div>
          </div>

          <div>
            <label className="label text-xs">متن توضیحات استودیو</label>
            <textarea
              rows={3}
              className="input text-xs leading-6"
              value={content.studioBanner.description}
              onChange={(e) =>
                setContent({
                  ...content,
                  studioBanner: { ...content.studioBanner, description: e.target.value }
                })
              }
            />
          </div>

          <div className="border-t border-ink-50 pt-4 space-y-3">
            <h3 className="text-xs font-bold text-ink-900">کارت‌های ۴ گانه ویژگی‌های استودیو</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {content.studioBanner.features.map((feat, idx) => (
                <div key={idx} className="rounded-xl border border-ink-100 bg-powder-50/40 p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      className="input !w-16 text-center text-sm"
                      value={feat.icon}
                      onChange={(e) => {
                        const next = [...content.studioBanner.features];
                        next[idx].icon = e.target.value;
                        setContent({
                          ...content,
                          studioBanner: { ...content.studioBanner, features: next }
                        });
                      }}
                    />
                    <input
                      className="input flex-1 text-xs font-bold"
                      value={feat.title}
                      onChange={(e) => {
                        const next = [...content.studioBanner.features];
                        next[idx].title = e.target.value;
                        setContent({
                          ...content,
                          studioBanner: { ...content.studioBanner, features: next }
                        });
                      }}
                    />
                  </div>
                  <textarea
                    rows={2}
                    className="input text-xs leading-5"
                    value={feat.desc}
                    onChange={(e) => {
                      const next = [...content.studioBanner.features];
                      next[idx].desc = e.target.value;
                      setContent({
                        ...content,
                        studioBanner: { ...content.studioBanner, features: next }
                      });
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Steps */}
      {activeTab === 'steps' && (
        <div className="rounded-2xl border border-ink-100 bg-white p-6 shadow-card space-y-5">
          <h2 className="text-sm font-bold text-ink-900 border-b border-ink-50 pb-3">بخش مراحل ثبت سفارش</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label text-xs">تیتر بخش مراحل</label>
              <input
                className="input text-xs"
                value={content.howItWorks.title}
                onChange={(e) =>
                  setContent({
                    ...content,
                    howItWorks: { ...content.howItWorks, title: e.target.value }
                  })
                }
              />
            </div>
            <div>
              <label className="label text-xs">زیرتیتر توضیحات</label>
              <input
                className="input text-xs"
                value={content.howItWorks.subtitle}
                onChange={(e) =>
                  setContent({
                    ...content,
                    howItWorks: { ...content.howItWorks, subtitle: e.target.value }
                  })
                }
              />
            </div>
          </div>

          <div className="space-y-4 pt-3 border-t border-ink-50">
            {content.howItWorks.steps.map((step, idx) => (
              <div key={idx} className="rounded-xl border border-ink-100 bg-powder-50/40 p-4 space-y-2">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm font-bold text-ink-900">{step.number}</span>
                  <input
                    className="input flex-1 text-xs font-bold"
                    placeholder="عنوان مرحله"
                    value={step.title}
                    onChange={(e) => {
                      const next = [...content.howItWorks.steps];
                      next[idx].title = e.target.value;
                      setContent({
                        ...content,
                        howItWorks: { ...content.howItWorks, steps: next }
                      });
                    }}
                  />
                </div>
                <textarea
                  rows={2}
                  className="input text-xs leading-5"
                  placeholder="توضیحات این مرحله"
                  value={step.desc}
                  onChange={(e) => {
                    const next = [...content.howItWorks.steps];
                    next[idx].desc = e.target.value;
                    setContent({
                      ...content,
                      howItWorks: { ...content.howItWorks, steps: next }
                    });
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 5: FAQs */}
      {activeTab === 'faqs' && (
        <div className="rounded-2xl border border-ink-100 bg-white p-6 shadow-card space-y-5">
          <div className="flex items-center justify-between border-b border-ink-50 pb-3">
            <h2 className="text-sm font-bold text-ink-900">پرسش‌های متداول (FAQ)</h2>
            <button
              type="button"
              onClick={() => {
                setContent({
                  ...content,
                  faqs: [
                    ...content.faqs,
                    { q: 'عنوان سوال جدید', a: 'پاسخ کامل سوال جدید را اینجا بنویسید.' }
                  ]
                });
              }}
              className="rounded-xl bg-powder-100 px-3 py-1.5 text-xs font-semibold text-powder-900 hover:bg-powder-200 transition"
            >
              + افزودن سوال جدید
            </button>
          </div>

          <div className="space-y-4">
            {content.faqs.map((faq, idx) => (
              <div key={idx} className="rounded-xl border border-ink-100 bg-powder-50/40 p-4 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-ink-500">سوال {idx + 1}</span>
                  <button
                    type="button"
                    onClick={() => {
                      const next = content.faqs.filter((_, i) => i !== idx);
                      setContent({ ...content, faqs: next });
                    }}
                    className="text-xs text-red-500 hover:underline"
                  >
                    حذف سوال
                  </button>
                </div>
                <input
                  className="input text-xs font-bold"
                  placeholder="متن پرسش"
                  value={faq.q}
                  onChange={(e) => {
                    const next = [...content.faqs];
                    next[idx].q = e.target.value;
                    setContent({ ...content, faqs: next });
                  }}
                />
                <textarea
                  rows={2}
                  className="input text-xs leading-6"
                  placeholder="متن پاسخ"
                  value={faq.a}
                  onChange={(e) => {
                    const next = [...content.faqs];
                    next[idx].a = e.target.value;
                    setContent({ ...content, faqs: next });
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 6: Footer */}
      {activeTab === 'footer' && (
        <div className="rounded-2xl border border-ink-100 bg-white p-6 shadow-card space-y-4">
          <h2 className="text-sm font-bold text-ink-900 border-b border-ink-50 pb-3">اطلاعات فوتر و تماس</h2>

          <div>
            <label className="label text-xs">شعار / معرفی کوتاه در فوتر</label>
            <textarea
              rows={2}
              className="input text-xs leading-6"
              value={content.footer.tagline}
              onChange={(e) =>
                setContent({
                  ...content,
                  footer: { ...content.footer, tagline: e.target.value }
                })
              }
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label text-xs">شماره تماس پشتیبانی</label>
              <input
                className="input text-xs"
                value={content.footer.supportPhone}
                onChange={(e) =>
                  setContent({
                    ...content,
                    footer: { ...content.footer, supportPhone: e.target.value }
                  })
                }
              />
            </div>
            <div>
              <label className="label text-xs">ایمیل پشتیبانی</label>
              <input
                className="input text-xs font-mono"
                dir="ltr"
                value={content.footer.supportEmail}
                onChange={(e) =>
                  setContent({
                    ...content,
                    footer: { ...content.footer, supportEmail: e.target.value }
                  })
                }
              />
            </div>
          </div>

          <div>
            <label className="label text-xs">آدرس فیزیکی دفتر / کارگاه</label>
            <input
              className="input text-xs"
              value={content.footer.address}
              onChange={(e) =>
                setContent({
                  ...content,
                  footer: { ...content.footer, address: e.target.value }
                })
              }
            />
          </div>

          <div>
            <label className="label text-xs">ساعات کاری و پاسخگویی</label>
            <input
              className="input text-xs"
              placeholder="مثلاً: شنبه تا چهارشنبه ۹ الی ۱۸"
              value={content.footer.workingHours || ''}
              onChange={(e) =>
                setContent({
                  ...content,
                  footer: { ...content.footer, workingHours: e.target.value }
                })
              }
            />
          </div>

          <div>
            <label className="label text-xs">متن کپی‌رایت پایین فوتر</label>
            <input
              className="input text-xs"
              value={content.footer.copyright}
              onChange={(e) =>
                setContent({
                  ...content,
                  footer: { ...content.footer, copyright: e.target.value }
                })
              }
            />
          </div>
        </div>
      )}

      {/* Sticky Save Bar */}
      <div className="sticky bottom-4 z-20 flex items-center justify-between rounded-2xl border border-ink-100 bg-white/95 p-4 shadow-soft backdrop-blur">
        <span className="text-xs text-ink-500">
          تغییرات شما به صورت آنی در تمام بخش‌های فروشگاه و صفحه اصلی اعمال خواهد شد.
        </span>
        <button
          type="button"
          onClick={handleSave}
          disabled={saving}
          className="btn-primary !px-7 !py-2.5 text-xs font-bold shadow-soft"
        >
          {saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
        </button>
      </div>
    </div>
  );
}
