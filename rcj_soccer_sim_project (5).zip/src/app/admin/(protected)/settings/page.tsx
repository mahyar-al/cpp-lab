import { prisma } from '@/lib/prisma';
import { getActivePaymentProviderName } from '@/server/payments/registry';
import { StoreContactSettings } from '@/components/admin/StoreContactSettings';

const PROVIDER_LABELS: Record<string, string> = {
  zarinpal: 'زرین‌پال',
  idpay: 'آی‌دی‌پی (IDPay)'
};

export default async function AdminSettingsPage() {
  const activeProvider = getActivePaymentProviderName();
  const providerConfigured =
    activeProvider === 'zarinpal'
      ? Boolean(process.env.ZARINPAL_MERCHANT_ID)
      : activeProvider === 'idpay'
        ? Boolean(process.env.IDPAY_API_KEY)
        : false;
  const removeBgConfigured = Boolean(process.env.REMOVE_BG_API_KEY);
  const discountsCount = await prisma.discount.count();
  const adsCount = await prisma.advertisement.count();

  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="text-xl font-semibold text-ink-900">تنظیمات فروشگاه</h1>

      {/* Store & Contact Information Editor */}
      <StoreContactSettings />

      <div className="card space-y-4 p-6">
        <h2 className="text-sm font-medium text-ink-900">وضعیت سرویس‌های خارجی</h2>
        <div className="flex items-center justify-between text-sm">
          <span className="text-ink-600">درگاه پرداخت فعال: {PROVIDER_LABELS[activeProvider] ?? activeProvider}</span>
          <span className={`badge ${providerConfigured ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>
            {providerConfigured ? 'پیکربندی شده' : 'پیکربندی نشده'}
          </span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-ink-600">حذف پس‌زمینه (remove.bg)</span>
          <span className={`badge ${removeBgConfigured ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>
            {removeBgConfigured ? 'پیکربندی شده' : 'پیکربندی نشده'}
          </span>
        </div>
        <p className="text-xs leading-6 text-ink-400">
          درگاه پرداخت با متغیر محیطی <code dir="ltr">PAYMENT_PROVIDER</code> انتخاب می‌شود
          (<code dir="ltr">zarinpal</code> یا <code dir="ltr">idpay</code>) و مرچنت‌آیدی از <code dir="ltr">ZARINPAL_MERCHANT_ID</code> یا <code dir="ltr">IDPAY_API_KEY</code> خوانده می‌شود.
        </p>
        <div className="rounded-xl bg-amber-50 p-3 border border-amber-200 text-xs text-amber-800 leading-6">
          🔒 <strong>قانون محاسبه درآمد:</strong> تا زمانی که درگاه پرداخت متصل نشده باشد و مشتری وجه واقعی را از درگاه بانکی پرداخت نکرده باشد، هیچ مبلغی به عنوان درآمد در سیستم ثبت نمی‌شود و آمار درآمد صفر باقی می‌ماند.
        </div>
      </div>

      <div className="card space-y-2 p-6">
        <h2 className="text-sm font-medium text-ink-900">کدهای تخفیف</h2>
        <p className="text-sm text-ink-500">تعداد کدهای تخفیف ثبت‌شده: {discountsCount}</p>
        <p className="text-xs leading-6 text-ink-400">
          مدیریت کامل از بخش «کدهای تخفیف» در منوی کناری.
        </p>
      </div>

      <div className="card space-y-2 p-6">
        <h2 className="text-sm font-medium text-ink-900">تبلیغات</h2>
        <p className="text-sm text-ink-500">تعداد بنرهای ثبت‌شده: {adsCount}</p>
        <p className="text-xs leading-6 text-ink-400">مدیریت کامل از بخش «تبلیغات» در منوی کناری.</p>
      </div>
    </div>
  );
}
