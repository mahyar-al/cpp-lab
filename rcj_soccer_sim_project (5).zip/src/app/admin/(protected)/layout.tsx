import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { MoricoLogo } from '@/components/MoricoLogo';
import { LogoutButton } from '@/components/LogoutButton';

const NAV = [
  { href: '/admin', label: 'داشبورد' },
  { href: '/admin/orders', label: 'سفارش‌ها' },
  { href: '/admin/customizations', label: 'طرح‌ها و فایل‌های کاربران 🎨' },
  { href: '/admin/products', label: 'محصولات' },
  { href: '/admin/categories', label: 'دسته‌بندی‌ها' },
  { href: '/admin/inventory', label: 'موجودی' },
  { href: '/admin/discounts', label: 'کدهای تخفیف' },
  { href: '/admin/navigation', label: 'منوی بالای سایت (هدر)' },
  { href: '/admin/ads', label: 'تبلیغات' },
  { href: '/admin/content', label: 'نوشته‌های سایت' },
  { href: '/admin/settings', label: 'تنظیمات فروشگاه' }
];

export default async function AdminProtectedLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'ADMIN') redirect('/admin/login');

  return (
    <div className="flex min-h-screen bg-powder-50">
      <aside className="hidden w-60 shrink-0 border-l border-ink-100 bg-white p-5 md:block">
        <div className="mb-8 flex items-center gap-2">
          <MoricoLogo className="h-8 w-8" />
          <span className="font-serif text-sm tracking-widest">MORICO ADMIN</span>
        </div>
        <nav className="space-y-1">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="block rounded-lg px-3 py-2 text-sm text-ink-600 hover:bg-powder-100 hover:text-ink-900"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      <div className="flex-1">
        <header className="flex h-16 items-center justify-between border-b border-ink-100 bg-white px-6">
          <span className="text-sm text-ink-500">خوش آمدید، {user.name}</span>
          <LogoutButton />
        </header>
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}
