import { z } from 'zod';

export const loginSchema = z.object({
  email: z.string().email('ایمیل وارد شده نامعتبر است.'),
  password: z.string().min(6, 'رمز عبور باید حداقل ۶ کاراکتر باشد.')
});

export const registerSchema = z.object({
  name: z.string().min(2, 'نام باید حداقل ۲ کاراکتر باشد.'),
  email: z.string().email('ایمیل وارد شده نامعتبر است.'),
  phone: z.string().optional().nullable(),
  password: z.string().min(6, 'رمز عبور باید حداقل ۶ کاراکتر باشد.')
});

export const checkoutSchema = z.object({
  fullName: z.string().min(2, 'نام و نام خانوادگی الزامی است.'),
  mobile: z.string().min(10, 'شماره همراه نامعتبر است.'),
  email: z.string().email('ایمیل نامعتبر است.').optional().or(z.literal('')),
  province: z.string().min(1, 'استان الزامی است.'),
  city: z.string().min(1, 'شهر الزامی است.'),
  address: z.string().min(5, 'آدرس دقیق الزامی است.'),
  postalCode: z.string().min(5, 'کد پستی الزامی است.'),
  notes: z.string().optional().nullable(),
  discountCode: z.string().optional().nullable()
});

export const saveCustomizationSchema = z.object({
  productId: z.string().min(1),
  views: z.record(z.any()),
  previewUrl: z.string().min(1)
});

export const productSchema = z.object({
  name: z.string().min(1, 'نام محصول الزامی است.'),
  slug: z.string().optional().default(''),
  description: z.string().optional().default(''),
  categoryId: z.string().min(1, 'دسته‌بندی الزامی است.'),
  basePrice: z.coerce.number().nonnegative('قیمت نمی‌تواند منفی باشد.'),
  discountPercent: z.coerce.number().min(0).max(100).default(0),
  stock: z.coerce.number().int().nonnegative().default(0),
  isAvailable: z.boolean().default(true),
  customizationEnabled: z.boolean().default(true),
  imageUrl: z.string().optional().nullable()
});

export const printableAreaSchema = z.object({
  x: z.coerce.number(),
  y: z.coerce.number(),
  width: z.coerce.number().positive(),
  height: z.coerce.number().positive(),
  minDesignWidth: z.coerce.number().optional().nullable(),
  minDesignHeight: z.coerce.number().optional().nullable(),
  maxDesignWidth: z.coerce.number().optional().nullable(),
  maxDesignHeight: z.coerce.number().optional().nullable()
});

export const productViewSchema = z.object({
  name: z.string().min(1, 'نام نما الزامی است.'),
  imageUrl: z.string().min(1, 'آدرس تصویر نما الزامی است.'),
  sortOrder: z.coerce.number().int().default(0),
  printableArea: printableAreaSchema
});

export const categorySchema = z.object({
  name: z.string().min(1, 'نام دسته‌بندی الزامی است.'),
  slug: z.string().min(1, 'نامک الزامی است.'),
  sortOrder: z.coerce.number().int().default(0),
  isActive: z.boolean().default(true)
});

export const discountSchema = z.object({
  code: z.string().min(2, 'کد تخفیف باید حداقل ۲ نویسه باشد.'),
  percent: z.coerce.number().min(1).max(100),
  maxUses: z.coerce.number().int().positive().default(100),
  expiresAt: z.string().optional().nullable()
});

export const advertisementSchema = z.object({
  title: z.string().min(1, 'عنوان تبلیغ الزامی است.'),
  imageUrl: z.string().min(1, 'آدرس تصویر الزامی است.'),
  linkUrl: z.string().optional().nullable(),
  placement: z.string().default('home'),
  isActive: z.boolean().default(true)
});
