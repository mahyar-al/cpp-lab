const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(value: number | string): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  return str.replace(/[0-9]/g, (digit) => PERSIAN_DIGITS[parseInt(digit, 10)]);
}

export function formatPriceNumber(amount: number): string {
  if (typeof amount !== 'number' || isNaN(amount)) return '۰';
  const formatted = Math.round(amount).toLocaleString('en-US');
  return toPersianDigits(formatted);
}

export function formatToman(amount: number): string {
  if (typeof amount !== 'number' || isNaN(amount)) return '۰ تومان';
  return `${formatPriceNumber(amount)} تومان`;
}

export function applyDiscount(price: number, discountPercent?: number | null): number {
  if (!discountPercent || discountPercent <= 0) return price;
  const safePercent = Math.min(100, Math.max(0, discountPercent));
  return Math.round(price * (1 - safePercent / 100));
}
