import fs from 'fs';
import path from 'path';

export interface SiteNavItem {
  id: string;
  label: string;
  href: string;
  isHighlight?: boolean;
  isExternal?: boolean;
  isActive: boolean;
  sortOrder: number;
}

export interface SiteContent {
  navigation: SiteNavItem[];
  announcement: {
    enabled: boolean;
    text: string;
    discountLabel: string;
    discountCode: string;
    supportPhone: string;
    link?: string;
  };
  hero: {
    badge: string;
    headline: string;
    subheadline: string;
    description: string;
    primaryCtaText: string;
    primaryCtaLink?: string;
    secondaryCtaText: string;
    secondaryCtaLink?: string;
    stats: {
      stat1Value: string;
      stat1Label: string;
      stat2Value: string;
      stat2Label: string;
      stat3Value: string;
      stat3Label: string;
    };
  };
  studioBanner: {
    badge: string;
    title: string;
    description: string;
    features: Array<{
      icon: string;
      title: string;
      desc: string;
    }>;
  };
  howItWorks: {
    title: string;
    subtitle: string;
    steps: Array<{
      number: string;
      title: string;
      desc: string;
    }>;
  };
  faqs: Array<{
    q: string;
    a: string;
  }>;
  footer: {
    tagline: string;
    supportPhone: string;
    supportEmail: string;
    address: string;
    workingHours?: string;
    copyright: string;
    about?: string;
  };
}

export const DEFAULT_NAV_ITEMS: SiteNavItem[] = [
  { id: 'nav-shop', label: 'فروشگاه', href: '/shop', isActive: true, sortOrder: 1 },
  { id: 'nav-tshirt', label: 'تی‌شرت', href: '/category/tshirt', isActive: true, sortOrder: 2 },
  { id: 'nav-hoodie', label: 'هودی', href: '/category/hoodie', isActive: true, sortOrder: 3 },
  { id: 'nav-mug', label: 'ماگ', href: '/category/mug', isActive: true, sortOrder: 4 },
  { id: 'nav-discounts', label: 'تخفیف‌ها', href: '/shop?discounted=1', isHighlight: true, isActive: true, sortOrder: 5 },
  { id: 'nav-orders', label: 'پیگیری سفارش', href: '/orders', isActive: true, sortOrder: 6 }
];

export const DEFAULT_SITE_CONTENT: SiteContent = {
  navigation: DEFAULT_NAV_ITEMS,
  announcement: {
    enabled: true,
    text: 'تخفیف ویژه سفارش اول با کد',
    discountLabel: 'کد تخفیف:',
    discountCode: 'MORICO20',
    supportPhone: '۰۲۱-۹۱۰۰۰۰۰۰',
    link: '/shop'
  },
  hero: {
    badge: 'استودیو طراحی آنلاین موریکو',
    headline: 'استایل اختصاصی خودت رو',
    subheadline: 'طراحی و چاپ کن',
    description:
      'در موریکو می‌توانید روی انواع تی‌شرت، هودی، ماگ، کلاه و قاب موبایل طرح دلخواهتان را با ابزار زنده طراحی کنید و در سراسر کشور تحویل بگیرید.',
    primaryCtaText: 'شروع طراحی اختصاصی',
    primaryCtaLink: '/shop?customizable=1',
    secondaryCtaText: 'مشاهده محصولات',
    secondaryCtaLink: '/shop',
    stats: {
      stat1Value: '+۵۰,۰۰۰',
      stat1Label: 'طرح چاپ‌شده',
      stat2Value: '۱۰۰٪',
      stat2Label: 'پنبه سوپر ارگانیک',
      stat3Value: '۴۸ ساعت',
      stat3Label: 'میانگین زمان تحویل'
    }
  },
  studioBanner: {
    badge: 'ابزار طراحی زنده',
    title: 'هر طرحی در ذهنت داری، روی محصول پیاده کن',
    description: 'بدون نیاز به نرم‌افزارهای پیچیده گرافیکی، تصاویرت رو آپلود کن و پس‌زمینه رو بردار.',
    features: [
      {
        icon: '✂️',
        title: 'حذف هوشمند پس‌زمینه',
        desc: 'حذف خودکار رنگ‌های پس‌زمینه و ترنسپرنت‌سازی تصاویر با الگوریتم دقیق'
      },
      {
        icon: '✍️',
        title: 'فونت‌های فارسی متنوع',
        desc: 'تایپ مستقیم متن با قلم‌های استاندارد وزیرمتن، تاهوما و ایران‌سنس'
      },
      {
        icon: '👕',
        title: 'پیش‌نمایش آنی چندنما',
        desc: 'مشاهده طرح روی نمای جلو، پشت یا آستین به صورت ریل‌تایم و دقیق'
      },
      {
        icon: '💎',
        title: 'چاپ باکیفیت و ماندگار',
        desc: 'تضمین ثبات رنگ و شستشو با دستگاه‌های چاپ صنعتی دیجیتال DTG'
      }
    ]
  },
  howItWorks: {
    title: 'چاپ اختصاصی در ۳ مرحله ساده',
    subtitle: 'بدون نیاز به نرم‌افزارهای پیچیده گرافیکی، طرح اختصاصی‌ات رو پیاده کن',
    steps: [
      {
        number: '۰۱',
        title: 'انتخاب محصول خام',
        desc: 'از میان ده‌ها مدل تیشرت، هودی، ماگ و اکسسوری، کالای مورد نظرت رو انتخاب کن.'
      },
      {
        number: '۰۲',
        title: 'شخصی‌سازی آنلاین',
        desc: 'با استودیوی طراحی موریکو متن، لوگو یا تصویرت رو قرار بده و پس‌زمینه رو بردار.'
      },
      {
        number: '۰۳',
        title: 'چاپ باکیفیت و تحویل سریع',
        desc: 'سفارش مستقیماً برای چاپ صنعتی با ماندگاری بالا ارسال و درب منزل تحویل داده میشه.'
      }
    ]
  },
  faqs: [
    {
      q: 'کیفیت پارچه‌ها و ماندگاری چاپ چگونه است؟',
      a: 'تمام تیشرت‌ها و هودی‌ها از ۱۰۰٪ پنبه سوپر تهیه شده و با چاپ صنعتی دیجیتال (DTG) انجام می‌شوند که در برابر شستشوی مداوم کاملاً مقاوم است.'
    },
    {
      q: 'آیا امکان حذف پس‌زمینه تصاویر وجود دارد؟',
      a: 'بله! در ادیتور آنلاین موریکو می‌توانید با یک کلیک پس‌زمینه سفید یا شلوغ تصاویرتان را به شکل هوشمند حذف کنید.'
    },
    {
      q: 'زمان تحویل سفارش‌ها چقدر است؟',
      a: 'سفارش‌های سفارشی معمولاً ظرف ۲ تا ۳ روز کاری چاپ و بسته‌بندی شده و با پست پیشتاز یا تیپاکس ارسال می‌گردند.'
    }
  ],
  footer: {
    tagline: 'هر چیزی که می‌پوشی، می‌تونه امضای تو باشه.',
    supportPhone: '۰۲۱-۹۱۰۰۰۰۰۰',
    supportEmail: 'support@morico.style',
    address: 'تهران، مرکز فناوری و چاپ اختصاصی موریکو',
    workingHours: 'شنبه تا چهارشنبه ۹ الی ۱۸',
    copyright: 'تمامی حقوق برای برند موریکو (MORICO) محفوظ است.',
    about: 'موریکو، سامانه سفارش و چاپ اختصاصی پوشاک و لوازم شخصی با متریال پریمیوم و ادیتور زنده.'
  }
};

const DATA_FILE = path.join(process.cwd(), 'data', 'site-content.json');

export async function getSiteContent(): Promise<SiteContent> {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf-8');
      if (data && data.trim()) {
        const parsed = JSON.parse(data);
        return {
          ...DEFAULT_SITE_CONTENT,
          ...parsed,
          navigation: Array.isArray(parsed.navigation) && parsed.navigation.length > 0
            ? parsed.navigation
            : DEFAULT_NAV_ITEMS,
          announcement: { ...DEFAULT_SITE_CONTENT.announcement, ...(parsed.announcement || {}) },
          hero: {
            ...DEFAULT_SITE_CONTENT.hero,
            ...(parsed.hero || {}),
            stats: { ...DEFAULT_SITE_CONTENT.hero.stats, ...(parsed.hero?.stats || {}) }
          },
          studioBanner: { ...DEFAULT_SITE_CONTENT.studioBanner, ...(parsed.studioBanner || {}) },
          howItWorks: { ...DEFAULT_SITE_CONTENT.howItWorks, ...(parsed.howItWorks || {}) },
          footer: { ...DEFAULT_SITE_CONTENT.footer, ...(parsed.footer || {}) }
        };
      }
    }
  } catch (err) {
    console.warn('[SiteContent] reading fallback to default:', err);
  }
  return DEFAULT_SITE_CONTENT;
}

export async function updateSiteContent(content: Partial<SiteContent>): Promise<SiteContent> {
  const current = await getSiteContent();
  const merged: SiteContent = {
    ...current,
    ...content,
    navigation: content.navigation !== undefined ? content.navigation : current.navigation,
    announcement: { ...current.announcement, ...(content.announcement || {}) },
    hero: {
      ...current.hero,
      ...(content.hero || {}),
      stats: { ...current.hero.stats, ...(content.hero?.stats || {}) }
    },
    studioBanner: { ...current.studioBanner, ...(content.studioBanner || {}) },
    howItWorks: { ...current.howItWorks, ...(content.howItWorks || {}) },
    footer: { ...current.footer, ...(content.footer || {}) }
  };

  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(merged, null, 2), 'utf-8');
  } catch (err) {
    console.warn('[SiteContent] error writing file:', err);
  }

  return merged;
}
