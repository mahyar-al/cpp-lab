import Link from 'next/link';
import { MoricoLogo } from './MoricoLogo';
import { getSiteContent } from '@/lib/site-content';

export async function Footer() {
  const content = await getSiteContent();
  const f = content.footer;

  return (
    <footer className="mt-20 border-t border-ink-100 bg-white">
      <div className="container-morico grid grid-cols-1 gap-10 py-14 sm:grid-cols-2 lg:grid-cols-12">
        {/* Brand & Tagline */}
        <div className="space-y-4 sm:col-span-2 lg:col-span-5">
          <div className="flex items-center gap-2.5">
            <MoricoLogo className="h-9 w-9" />
            <div className="flex flex-col">
              <span className="font-serif text-base font-bold tracking-[0.15em] text-ink-900 leading-none">MORICO</span>
              <span className="text-[8px] tracking-wider text-ink-400 font-medium leading-tight">STYLE • SINCE 2026</span>
            </div>
          </div>
          <p className="max-w-md text-sm leading-7 text-ink-500">
            {f.tagline}
          </p>
        </div>

        {/* Store Links */}
        <div className="lg:col-span-2">
          <h4 className="mb-4 text-sm font-bold text-ink-900">محصولات</h4>
          <ul className="space-y-2.5 text-sm text-ink-500">
            <li>
              <Link href="/shop" className="transition-colors hover:text-ink-900">
                همه محصولات
              </Link>
            </li>
            <li>
              <Link href="/category/tshirt" className="transition-colors hover:text-ink-900">
                تی‌شرت‌های اختصاصی
              </Link>
            </li>
            <li>
              <Link href="/category/hoodie" className="transition-colors hover:text-ink-900">
                هودی و دورس
              </Link>
            </li>
            <li>
              <Link href="/shop?discounted=1" className="transition-colors hover:text-ink-900">
                محصولات تخفیف‌دار
              </Link>
            </li>
          </ul>
        </div>

        {/* Quick Access */}
        <div className="lg:col-span-2">
          <h4 className="mb-4 text-sm font-bold text-ink-900">دسترسی سریع</h4>
          <ul className="space-y-2.5 text-sm text-ink-500">
            <li>
              <Link href="/shop?customizable=1" className="transition-colors hover:text-ink-900 font-medium text-ink-800">
                استودیو طراحی آنلاین
              </Link>
            </li>
            <li>
              <Link href="/orders" className="transition-colors hover:text-ink-900">
                پیگیری سفارش‌ها
              </Link>
            </li>
            <li>
              <Link href="/login" className="transition-colors hover:text-ink-900">
                ورود به حساب کاربری
              </Link>
            </li>
            <li>
              <Link href="/admin" className="transition-colors hover:text-ink-900 text-xs font-medium text-ink-700">
                پنل مدیریت (ادمین)
              </Link>
            </li>
          </ul>
        </div>

        {/* Support & Contact */}
        <div className="space-y-3 sm:col-span-2 lg:col-span-3">
          <h4 className="text-sm font-bold text-ink-900">تماس و پشتیبانی</h4>
          <div className="space-y-2 text-xs leading-6 text-ink-600">
            {f.supportPhone && (
              <p className="flex items-center gap-2">
                <span className="font-semibold text-ink-800">📞 شماره تماس:</span>
                <span dir="ltr" className="font-mono font-medium text-ink-900">{f.supportPhone}</span>
              </p>
            )}
            {f.supportEmail && (
              <p className="flex items-center gap-2">
                <span className="font-semibold text-ink-800">✉️ ایمیل پشتیبانی:</span>
                <span dir="ltr" className="font-mono text-ink-700">{f.supportEmail}</span>
              </p>
            )}
            <p className="text-ink-500">
              {f.address || 'تهران، مرکز فناوری و چاپ اختصاصی موریکو'}
            </p>
            <p className="text-[11px] text-ink-400">
              {f.workingHours ? `ساعات پاسخگویی: ${f.workingHours}` : 'ساعات پاسخگویی: شنبه تا چهارشنبه ۹ الی ۱۸'}
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-ink-100/80 bg-powder-50/40 py-5">
        <div className="container-morico flex flex-col items-center justify-between gap-3 text-xs text-ink-500 sm:flex-row">
          <p>© {new Date().getFullYear()} {f.copyright}</p>
          <div className="flex flex-wrap items-center justify-center gap-4 text-[11px] text-ink-400">
            <span>طراحی زنده با هوش مصنوعی</span>
            <span className="hidden sm:inline">•</span>
            <span>درگاه امن پرداخت شاپرک</span>
            <span className="hidden sm:inline">•</span>
            <span>ارسال مطمئن با بسته‌بندی اختصاصی</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
