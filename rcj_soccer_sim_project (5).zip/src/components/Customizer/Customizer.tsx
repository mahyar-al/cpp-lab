'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import type { fabric } from 'fabric';
import { CANVAS_SIZE, type ProductViewData } from './types';
import { Toolbar } from './Toolbar';
import { BackgroundTouchUp } from './BackgroundTouchUp';
import { ViewTabs } from './ViewTabs';
import { removeBackgroundFromImage } from '@/lib/background-remover';
import { clientFetch } from '@/lib/client-fetch';

interface Props {
  productId: string;
  productName: string;
  views: ProductViewData[];
}

type ViewSnapshot = Record<string, unknown> | null;

const PERSIAN_FONTS = ['Vazirmatn', 'Tahoma', 'IRANSans'];

export function Customizer({ productId, productName, views }: Props) {
  const router = useRouter();
  const canvasElRef = useRef<HTMLCanvasElement | null>(null);
  const fabricRef = useRef<fabric.Canvas | null>(null);
  const fabricModuleRef = useRef<typeof import('fabric').fabric | null>(null);

  const [activeViewIndex, setActiveViewIndex] = useState(0);
  const activeViewIndexRef = useRef(0);
  const activeViewRef = useRef<ProductViewData>(views[0]);
  const viewLayersRef = useRef<Record<string, fabric.Object[]>>({});
  const snapshotsRef = useRef<Record<string, ViewSnapshot>>({});
  const historyRef = useRef<Record<string, ViewSnapshot[]>>({});
  const redoRef = useRef<Record<string, ViewSnapshot[]>>({});

  const [hasSelection, setHasSelection] = useState(false);
  const [hasTextSelection, setHasTextSelection] = useState(false);
  const [textColor, setTextColor] = useState('#121316');
  const [busy, setBusy] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [bgProgress, setBgProgress] = useState<number | null>(null);
  const [touchUp, setTouchUp] = useState<{ originalUrl: string; cutoutUrl: string } | null>(null);
  const touchUpTargetRef = useRef<fabric.Image | null>(null);
  const bgTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    return () => {
      if (bgTimerRef.current) clearInterval(bgTimerRef.current);
    };
  }, []);

  const activeView = views[activeViewIndex];

  // ---------- Canvas bootstrap ----------
  useEffect(() => {
    let disposed = false;

    import('fabric').then(({ fabric }) => {
      if (disposed || !canvasElRef.current) return;
      fabricModuleRef.current = fabric;

      const canvas = new fabric.Canvas(canvasElRef.current, {
        width: CANVAS_SIZE,
        height: CANVAS_SIZE,
        preserveObjectStacking: true,
        selection: true
      });
      fabricRef.current = canvas;

      canvas.on('selection:created', (e) => syncSelectionState(e));
      canvas.on('selection:updated', (e) => syncSelectionState(e));
      canvas.on('selection:cleared', () => {
        setHasSelection(false);
        setHasTextSelection(false);
      });

      canvas.on('object:modified', () => pushHistory());
      canvas.on('object:moving', (e) => clampToPrintableArea(e.target as fabric.Object));
      canvas.on('object:scaling', (e) => clampScaling(e.target as fabric.Object));

      setReady(true);
      loadView(views[0], canvas, fabric);
    });

    return () => {
      disposed = true;
      fabricRef.current?.dispose();
      fabricRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function isTextObject(obj?: fabric.Object | null): obj is fabric.IText {
    return !!obj && (obj.type === 'i-text' || obj.type === 'text' || obj.type === 'textbox');
  }

  function syncSelectionState(e: fabric.IEvent) {
    const target = (e.selected?.[0] ?? (e as unknown as { target?: fabric.Object }).target) as
      | fabric.Object
      | undefined;
    setHasSelection(true);
    if (isTextObject(target)) {
      setHasTextSelection(true);
      const fill = target.fill;
      if (typeof fill === 'string') setTextColor(fill);
    } else {
      setHasTextSelection(false);
    }
  }

  function getPrintableArea() {
    return activeViewRef.current?.printableArea || activeView.printableArea;
  }

  function clampToPrintableArea(obj?: fabric.Object) {
    if (!obj) return;
    const area = getPrintableArea();
    obj.setCoords(); // make sure the bounding box is not stale while dragging
    const bounds = obj.getBoundingRect(true, true);

    // Returns how far to shift the object along one axis.
    // - Object smaller than the area: keep it fully inside.
    // - Object bigger than the area: keep the area covered (never jump between the two edges).
    const shift = (start: number, size: number, areaStart: number, areaSize: number) => {
      if (size <= areaSize) {
        if (start < areaStart) return areaStart - start;
        if (start + size > areaStart + areaSize) return areaStart + areaSize - (start + size);
        return 0;
      }
      if (start > areaStart) return areaStart - start;
      if (start + size < areaStart + areaSize) return areaStart + areaSize - (start + size);
      return 0;
    };

    const dx = shift(bounds.left, bounds.width, area.x, area.width);
    const dy = shift(bounds.top, bounds.height, area.y, area.height);
    if (dx || dy) {
      obj.set({ left: (obj.left ?? 0) + dx, top: (obj.top ?? 0) + dy });
      obj.setCoords();
    }
  }

  function clampScaling(obj?: fabric.Object) {
    if (!obj) return;
    const area = getPrintableArea();
    const bounds = obj.getBoundingRect(true);

    if (bounds.width < area.minDesignWidth || bounds.width > area.maxDesignWidth) {
      const targetWidth = Math.min(Math.max(bounds.width, area.minDesignWidth), area.maxDesignWidth);
      const factor = targetWidth / bounds.width;
      obj.scaleX = (obj.scaleX ?? 1) * factor;
    }
    if (bounds.height < area.minDesignHeight || bounds.height > area.maxDesignHeight) {
      const targetHeight = Math.min(Math.max(bounds.height, area.minDesignHeight), area.maxDesignHeight);
      const factor = targetHeight / bounds.height;
      obj.scaleY = (obj.scaleY ?? 1) * factor;
    }
    clampToPrintableArea(obj);
  }

  function loadView(view: ProductViewData, canvas: fabric.Canvas, fabricNS: typeof fabric) {
    fabricNS.Image.fromURL(
      view.imageUrl,
      (img) => {
        // Cover-fit into the CANVAS_SIZE x CANVAS_SIZE square (crop instead
        // of letterbox) so this matches the admin's object-cover preview
        // used when authoring the printable area — otherwise the same
        // x/y/width/height would land in different spots on each screen.
        const imgWidth = img.width ?? CANVAS_SIZE;
        const imgHeight = img.height ?? CANVAS_SIZE;
        const scale = Math.max(CANVAS_SIZE / imgWidth, CANVAS_SIZE / imgHeight);
        img.set({
          scaleX: scale,
          scaleY: scale,
          left: CANVAS_SIZE / 2,
          top: CANVAS_SIZE / 2,
          originX: 'center',
          originY: 'center'
        });
        canvas.setBackgroundImage(img, () => canvas.renderAll());
      },
      { crossOrigin: 'anonymous' }
    );

    const existingObjs = viewLayersRef.current[view.id];
    if (existingObjs && existingObjs.length > 0) {
      existingObjs.forEach((obj) => canvas.add(obj));
      canvas.renderAll();
    }
  }

  function saveCurrentSnapshot() {
    const canvas = fabricRef.current;
    const currentView = activeViewRef.current;
    if (!canvas || !currentView) return;
    const currentObjs = canvas.getObjects().slice();
    viewLayersRef.current[currentView.id] = currentObjs;
    snapshotsRef.current[currentView.id] = {
      objects: currentObjs.map((o) => o.toObject(['selectable', 'evented', 'assetId', 'originalUrl']))
    };
  }

  function pushHistory() {
    const canvas = fabricRef.current;
    const currentView = activeViewRef.current;
    if (!canvas || !currentView) return;
    const currentObjs = canvas.getObjects().slice();
    viewLayersRef.current[currentView.id] = currentObjs;
    const json = canvas.toJSON(['selectable', 'evented', 'assetId', 'originalUrl']);
    const stack = historyRef.current[currentView.id] ?? [];
    stack.push(json);
    historyRef.current[currentView.id] = stack.slice(-20); // cap history depth
    redoRef.current[currentView.id] = [];
    snapshotsRef.current[currentView.id] = json;
  }

  function switchView(index: number) {
    const canvas = fabricRef.current;
    const fabricNS = fabricModuleRef.current;
    if (!canvas || !fabricNS || index === activeViewIndexRef.current) return;

    // 1. Deselect active object first to avoid leaving ghost selection/group state
    canvas.discardActiveObject();

    // 2. Persist current view's living Fabric objects and snapshot
    const currentView = activeViewRef.current;
    const currentObjs = canvas.getObjects().slice();
    viewLayersRef.current[currentView.id] = currentObjs;
    snapshotsRef.current[currentView.id] = {
      objects: currentObjs.map((o) => o.toObject(['selectable', 'evented', 'assetId', 'originalUrl']))
    };

    // 3. Remove current objects from canvas without destroying them in memory
    currentObjs.forEach((obj) => canvas.remove(obj));

    // 4. Switch active view state and refs synchronously
    const targetView = views[index];
    activeViewIndexRef.current = index;
    activeViewRef.current = targetView;
    setActiveViewIndex(index);
    setHasSelection(false);
    setHasTextSelection(false);

    // 5. Restore target view's objects directly from memory and re-bind coords
    const targetObjs = viewLayersRef.current[targetView.id] || [];
    targetObjs.forEach((obj) => {
      canvas.add(obj);
      obj.setCoords();
    });

    // 6. Update the background product mockup image
    fabricNS.Image.fromURL(
      targetView.imageUrl,
      (img) => {
        // If user rapidly switched views while loading, verify target view still matches
        if (activeViewRef.current.id !== targetView.id) return;
        const imgWidth = img.width ?? CANVAS_SIZE;
        const imgHeight = img.height ?? CANVAS_SIZE;
        const scale = Math.max(CANVAS_SIZE / imgWidth, CANVAS_SIZE / imgHeight);
        img.set({
          scaleX: scale,
          scaleY: scale,
          left: CANVAS_SIZE / 2,
          top: CANVAS_SIZE / 2,
          originX: 'center',
          originY: 'center'
        });
        canvas.setBackgroundImage(img, () => canvas.renderAll());
      },
      { crossOrigin: 'anonymous' }
    );

    canvas.renderAll();
  }

  const addText = useCallback(() => {
    const canvas = fabricRef.current;
    const fabricNS = fabricModuleRef.current;
    if (!canvas || !fabricNS) return;
    const area = getPrintableArea();
    const text = new fabricNS.IText('متن خود را وارد کنید', {
      left: area.x + area.width / 2,
      top: area.y + area.height / 2,
      originX: 'center',
      originY: 'center',
      fontFamily: PERSIAN_FONTS[0],
      fontSize: 32,
      fill: textColor
    });
    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.renderAll();
    setHasSelection(true);
    setHasTextSelection(true);
    pushHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [textColor]);

  function changeTextColor(color: string) {
    setTextColor(color);
    const canvas = fabricRef.current;
    const active = canvas?.getActiveObject();
    if (canvas && isTextObject(active)) {
      active.set({ fill: color });
      canvas.renderAll();
      pushHistory();
    }
  }

  async function handleImageUpload(file: File) {
    setBusy(true);
    setStatusMessage(null);
    try {
      const form = new FormData();
      form.append('file', file);
      const res = await clientFetch('/api/upload', { method: 'POST', body: form });
      const data = await res.json();
      if (!res.ok) {
        setStatusMessage(data.error ?? 'بارگذاری تصویر با خطا مواجه شد.');
        return;
      }
      placeImageOnCanvas(data.url, data.id);
    } finally {
      setBusy(false);
    }
  }

  function placeImageOnCanvas(url: string, assetId?: string) {
    const canvas = fabricRef.current;
    const fabricNS = fabricModuleRef.current;
    if (!canvas || !fabricNS) return;
    const area = getPrintableArea();

    fabricNS.Image.fromURL(
      url,
      (img) => {
        const maxW = Math.min(area.width, area.maxDesignWidth);
        const maxH = Math.min(area.height, area.maxDesignHeight);
        const naturalW = img.width ?? maxW;
        const naturalH = img.height ?? maxH;
        // Fit inside the allowed size in both directions (tall photos used to overflow the height).
        const fit = Math.min(1, maxW / naturalW, maxH / naturalH);
        if (fit < 1) {
          img.scale(fit);
        }
        img.set({
          left: area.x + area.width / 2,
          top: area.y + area.height / 2,
          originX: 'center',
          originY: 'center'
        });
        if (assetId) {
          (img as unknown as { assetId?: string }).assetId = assetId;
        }
        canvas.add(img);
        canvas.setActiveObject(img);
        canvas.renderAll();
        pushHistory();
      },
      { crossOrigin: 'anonymous' }
    );
  }

  // The remove-bg API is a single request with no real progress events, so the
  // percentage is an estimate: it eases toward 92% while waiting, then jumps to 100%
  // when the server answers.
  function startBgProgress() {
    if (bgTimerRef.current) clearInterval(bgTimerRef.current);
    setBgProgress(3);
    bgTimerRef.current = setInterval(() => {
      setBgProgress((p) => (p === null ? p : p + (92 - p) * 0.06));
    }, 300);
  }

  function stopBgProgress(success: boolean) {
    if (bgTimerRef.current) {
      clearInterval(bgTimerRef.current);
      bgTimerRef.current = null;
    }
    if (success) {
      setBgProgress(100);
      setTimeout(() => setBgProgress(null), 700);
    } else {
      setBgProgress(null);
    }
  }

  async function handleRemoveBackground() {
    const canvas = fabricRef.current;
    const active = canvas?.getActiveObject() as (fabric.Image & { _element?: HTMLImageElement }) | undefined;
    if (!canvas || !active || active.type !== 'image') {
      setStatusMessage('برای حذف پس‌زمینه، ابتدا یک تصویر را انتخاب کنید.');
      return;
    }

    setBusy(true);
    setStatusMessage(null);
    startBgProgress();
    let succeeded = false;

    try {
      let resultUrl: string | null = null;
      let resultId: string | null = null;

      // 1. Try server remove-bg API first if assetId exists
      const assetId = (active as unknown as { assetId?: string }).assetId;
      if (assetId) {
        try {
          const res = await clientFetch('/api/remove-bg', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ assetId })
          });
          if (res.ok) {
            const data = await res.json();
            if (data?.url) {
              resultUrl = data.url;
              resultId = data.id;
            }
          }
        } catch {
          // fall through to client-side smart removal
        }
      }

      // 2. Fallback to client-side smart background removal (100% reliable)
      if (!resultUrl) {
        const imgElement = active.getElement() as HTMLImageElement;
        if (!imgElement) {
          throw new Error('تصویر برای پردازش یافت نشد.');
        }

        const { blob } = await removeBackgroundFromImage(imgElement, {
          tolerance: 32,
          feather: 2
        });

        const formData = new FormData();
        formData.append('file', new File([blob], 'cutout.png', { type: 'image/png' }));
        const uploadRes = await clientFetch('/api/upload', {
          method: 'POST',
          body: formData
        });

        if (!uploadRes.ok) {
          const errData = await uploadRes.json().catch(() => ({}));
          throw new Error(errData.error || 'ذخیره تصویر بدون پس‌زمینه با خطا مواجه شد.');
        }

        const uploadData = await uploadRes.json();
        resultUrl = uploadData.url;
        resultId = uploadData.id;
      }

      if (!resultUrl) {
        throw new Error('حذف پس‌زمینه انجام نشد.');
      }

      // 3. SAFELY load new image BEFORE removing active image
      const fabricNS = fabricModuleRef.current!;
      const originalUrl =
        (active as unknown as { originalUrl?: string }).originalUrl ?? (active as fabric.Image).getSrc();

      const oldW = (active as fabric.Image).width ?? 1;
      const oldH = (active as fabric.Image).height ?? 1;
      const { left, top, angle, flipX, flipY, originX, originY, scaleX, scaleY } = active;

      await new Promise<void>((resolve, reject) => {
        fabricNS.Image.fromURL(
          resultUrl!,
          (img) => {
            if (!img || !img.width) {
              reject(new Error('خطا در بارگذاری تصویر بدون پس‌زمینه'));
              return;
            }
            const newScaleX = (scaleX ?? 1) * (oldW / (img.width || oldW));
            const newScaleY = (scaleY ?? 1) * (oldH / (img.height || oldH));

            img.set({
              left,
              top,
              angle,
              flipX,
              flipY,
              originX,
              originY,
              scaleX: isFinite(newScaleX) && newScaleX > 0 ? newScaleX : (scaleX ?? 1),
              scaleY: isFinite(newScaleY) && newScaleY > 0 ? newScaleY : (scaleY ?? 1)
            });
            (img as unknown as { assetId?: string }).assetId = resultId || undefined;
            (img as unknown as { originalUrl?: string }).originalUrl = originalUrl;

            // Safely swap only after image is successfully loaded and validated
            canvas.remove(active);
            canvas.add(img);
            canvas.setActiveObject(img);
            canvas.renderAll();
            pushHistory();
            succeeded = true;
            setStatusMessage('پس‌زمینه تصویر با موفقیت حذف شد.');
            resolve();
          },
          { crossOrigin: 'anonymous' }
        );
      });
    } catch (err: any) {
      setStatusMessage(err?.message || 'حذف پس‌زمینه با خطا مواجه شد. تصویر اصلی بدون تغییر حفظ شد.');
    } finally {
      stopBgProgress(succeeded);
      setBusy(false);
    }
  }

  async function openManualEdit() {
    const canvas = fabricRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active || active.type !== 'image') {
      setStatusMessage('برای ویرایش دستی، ابتدا یک تصویر را انتخاب کنید.');
      return;
    }
    const img = active as fabric.Image;
    const meta = img as unknown as { originalUrl?: string; assetId?: string };
    const cutoutUrl = img.getSrc();
    let originalUrl = meta.originalUrl;

    if (!originalUrl && meta.assetId) {
      try {
        const res = await fetch(`/api/assets/${meta.assetId}/source`);
        if (res.ok) {
          const data = (await res.json()) as { originalUrl?: string | null };
          if (data.originalUrl) {
            originalUrl = data.originalUrl;
            meta.originalUrl = data.originalUrl;
          }
        }
      } catch {
        /* fall back */
      }
    }

    setStatusMessage(null);
    touchUpTargetRef.current = img;
    setTouchUp({ originalUrl: originalUrl ?? cutoutUrl, cutoutUrl });
  }

  // Uploads the hand-edited image and swaps it in place of the selected one.
  async function saveTouchUp(blob: Blob): Promise<string | null> {
    const canvas = fabricRef.current;
    const fabricNS = fabricModuleRef.current;
    const target = touchUpTargetRef.current;
    if (!canvas || !fabricNS || !target) return 'ذخیره ویرایش ممکن نشد.';

    try {
      const form = new FormData();
      form.append('file', new File([blob], 'edited.png', { type: 'image/png' }));
      const res = await fetch('/api/upload', { method: 'POST', body: form });
      const data = await res.json().catch(() => ({}) as { error?: string; id?: string; url?: string; width?: number; height?: number });
      if (!res.ok) return data.error ?? 'ذخیره ویرایش با خطا مواجه شد.';

      const originalUrl =
        (target as unknown as { originalUrl?: string }).originalUrl ?? target.getSrc();
      const targetW = target.width || 1;
      const targetH = target.height || 1;
      const dataW = data.width || targetW;
      const dataH = data.height || targetH;

      const calcScaleX = (target.scaleX ?? 1) * (targetW / dataW);
      const calcScaleY = (target.scaleY ?? 1) * (targetH / dataH);
      const scaleX = isFinite(calcScaleX) && calcScaleX > 0 ? calcScaleX : (target.scaleX ?? 1);
      const scaleY = isFinite(calcScaleY) && calcScaleY > 0 ? calcScaleY : (target.scaleY ?? 1);
      const { left, top, angle, flipX, flipY, originX, originY } = target;

      await new Promise<void>((resolve, reject) => {
        fabricNS.Image.fromURL(
          data.url,
          (img) => {
            if (!img || !img.width) {
              reject(new Error('خطا در بارگذاری'));
              return;
            }
            img.set({ left, top, angle, flipX, flipY, originX, originY, scaleX, scaleY });
            (img as unknown as { assetId?: string }).assetId = data.id;
            (img as unknown as { originalUrl?: string }).originalUrl = originalUrl;
            canvas.remove(target);
            canvas.add(img);
            canvas.setActiveObject(img);
            canvas.renderAll();
            pushHistory();
            resolve();
          },
          { crossOrigin: 'anonymous' }
        );
      });

      touchUpTargetRef.current = null;
      setTouchUp(null);
      setStatusMessage('ویرایش تصویر با موفقیت اعمال شد.');
      return null;
    } catch {
      return 'ارتباط با سرور برقرار نشد. دوباره تلاش کنید.';
    }
  }

  function deleteSelected() {
    const canvas = fabricRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) return;
    canvas.remove(active);
    canvas.discardActiveObject();
    canvas.renderAll();
    pushHistory();
  }

  function bringForward() {
    const canvas = fabricRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) return;
    canvas.bringForward(active);
    canvas.renderAll();
    pushHistory();
  }

  function sendBackward() {
    const canvas = fabricRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) return;
    canvas.sendBackwards(active);
    canvas.renderAll();
    pushHistory();
  }

  function undo() {
    const canvas = fabricRef.current;
    const fabricNS = fabricModuleRef.current;
    const currentView = activeViewRef.current;
    if (!canvas || !fabricNS || !currentView) return;
    const stack = historyRef.current[currentView.id] ?? [];
    if (stack.length < 2) return;
    const current = stack.pop()!;
    redoRef.current[currentView.id] = [...(redoRef.current[currentView.id] ?? []), current];
    historyRef.current[currentView.id] = stack;
    const previous = stack[stack.length - 1];
    canvas.loadFromJSON(previous ?? {}, () => {
      canvas.renderAll();
      viewLayersRef.current[currentView.id] = canvas.getObjects().slice();
    });
    snapshotsRef.current[currentView.id] = previous ?? null;
  }

  function redo() {
    const canvas = fabricRef.current;
    const currentView = activeViewRef.current;
    if (!canvas || !currentView) return;
    const redoStack = redoRef.current[currentView.id] ?? [];
    const next = redoStack.pop();
    if (!next) return;
    redoRef.current[currentView.id] = redoStack;
    const stack = historyRef.current[currentView.id] ?? [];
    stack.push(next);
    historyRef.current[currentView.id] = stack;
    canvas.loadFromJSON(next, () => {
      canvas.renderAll();
      viewLayersRef.current[currentView.id] = canvas.getObjects().slice();
    });
    snapshotsRef.current[currentView.id] = next;
  }

  function dataUrlToBlob(dataUrl: string): Blob {
    const [header, base64] = dataUrl.split(',');
    const mimeMatch = header.match(/data:(.*?);base64/);
    const mime = mimeMatch?.[1] ?? 'image/png';
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  }

  async function uploadPreviewImage(): Promise<string | undefined> {
    const canvas = fabricRef.current;
    if (!canvas) return undefined;
    try {
      const dataUrl = canvas.toDataURL({ format: 'png', quality: 0.92 });
      const blob = dataUrlToBlob(dataUrl);
      const form = new FormData();
      form.append('file', blob, 'preview.png');
      const res = await clientFetch('/api/upload', { method: 'POST', body: form });
      if (!res.ok) return undefined;
      const data = await res.json();
      return data.url as string;
    } catch {
      // Preview generation is a nice-to-have, not a save blocker.
      return undefined;
    }
  }

  async function saveAndAddToCart() {
    const canvas = fabricRef.current;
    const currentView = activeViewRef.current;
    if (!canvas || !currentView) return;

    // 1. Sync current active view objects
    canvas.discardActiveObject();
    const currentObjs = canvas.getObjects().slice();
    viewLayersRef.current[currentView.id] = currentObjs;
    saveCurrentSnapshot();

    setBusy(true);
    setStatusMessage(null);
    try {
      const viewsPayload: Record<string, { objects: unknown[] }> = {};
      for (const v of views) {
        let objs: any[] = [];
        if (v.id === currentView.id) {
          objs = currentObjs.map((obj) => obj.toObject(['selectable', 'evented', 'assetId', 'originalUrl']));
        } else {
          const cachedLiving = viewLayersRef.current[v.id];
          if (cachedLiving && cachedLiving.length > 0) {
            objs = cachedLiving.map((obj) => obj.toObject(['selectable', 'evented', 'assetId', 'originalUrl']));
          } else if (snapshotsRef.current[v.id]?.objects) {
            objs = (snapshotsRef.current[v.id]!.objects as any[]) || [];
          }
        }
        viewsPayload[v.id] = { objects: objs };
      }

      // Render the CURRENT view for the preview thumbnail
      const previewUrl = await uploadPreviewImage();

      const saveRes = await clientFetch('/api/customizations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, views: viewsPayload, previewUrl })
      });
      const saveData = await saveRes.json();
      if (!saveRes.ok) {
        setStatusMessage(saveData.error ?? 'ذخیره طرح با خطا مواجه شد.');
        return;
      }

      const cartRes = await clientFetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, quantity: 1, customizationId: saveData.id })
      });
      if (!cartRes.ok) {
        const cartData = await cartRes.json();
        setStatusMessage(cartData.error ?? 'افزودن به سبد خرید با خطا مواجه شد.');
        return;
      }

      router.push('/cart');
    } catch (err: any) {
      setStatusMessage(err?.message || 'خطا در ثبت سفارش سفارشی.');
    } finally {
      setBusy(false);
    }
  }

  if (!activeView) return null;

  return (
    <div className="container-morico grid grid-cols-1 gap-8 py-8 lg:grid-cols-[280px_1fr]">
      <div className="order-2 lg:order-1">
        <Toolbar
          busy={busy}
          hasSelection={hasSelection}
          hasTextSelection={hasTextSelection}
          textColor={textColor}
          onAddText={addText}
          onUploadImage={handleImageUpload}
          onRemoveBackground={handleRemoveBackground}
          onManualEdit={openManualEdit}
          onDelete={deleteSelected}
          onBringForward={bringForward}
          onSendBackward={sendBackward}
          onUndo={undo}
          onRedo={redo}
          onChangeTextColor={changeTextColor}
        />
        {bgProgress !== null && (
          <div className="mt-3 rounded-lg bg-black/5 p-3" role="progressbar" aria-valuenow={Math.round(bgProgress)} aria-valuemin={0} aria-valuemax={100}>
            <div className="mb-2 flex items-center justify-between text-xs">
              <span>{bgProgress >= 100 ? 'حذف پس‌زمینه انجام شد' : 'در حال حذف پس‌زمینه...'}</span>
              <span dir="ltr">{Math.round(bgProgress)}%</span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-black/10">
              <div className="h-full rounded-full bg-black transition-all duration-300" style={{ width: `${bgProgress}%` }} />
            </div>
          </div>
        )}
        {touchUp && (
          <BackgroundTouchUp
            originalUrl={touchUp.originalUrl}
            cutoutUrl={touchUp.cutoutUrl}
            onCancel={() => {
              touchUpTargetRef.current = null;
              setTouchUp(null);
            }}
            onSave={saveTouchUp}
          />
        )}
        {statusMessage && (
          <p className="mt-3 rounded-lg bg-red-50 p-3 text-xs leading-6 text-red-600">{statusMessage}</p>
        )}
      </div>

      <div className="order-1 lg:order-2">
        <h1 className="mb-4 text-lg font-semibold text-ink-900">شخصی‌سازی: {productName}</h1>

        <ViewTabs views={views} activeIndex={activeViewIndex} onChange={switchView} />

        <div className="mt-4 flex justify-center rounded-xl2 border border-ink-100 bg-powder-50 p-4">
          <div
            className="relative touch-none"
            style={{ width: CANVAS_SIZE, height: CANVAS_SIZE, maxWidth: '100%' }}
          >
            <canvas ref={canvasElRef} />
            <div
              aria-hidden
              className="pointer-events-none absolute border border-dashed border-ink-400/60"
              style={{
                left: activeView.printableArea.x,
                top: activeView.printableArea.y,
                width: activeView.printableArea.width,
                height: activeView.printableArea.height
              }}
            />
            {!ready && (
              <div className="absolute inset-0 flex items-center justify-center text-sm text-ink-400">
                در حال بارگذاری ویرایشگر...
              </div>
            )}
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button onClick={saveAndAddToCart} disabled={busy} className="btn-primary">
            {busy ? 'در حال ذخیره...' : 'ذخیره طرح و افزودن به سبد خرید'}
          </button>
        </div>
      </div>
    </div>
  );
}
