import Link from 'next/link';
import Image from 'next/image';
import { formatPriceNumber, toPersianDigits } from '@/lib/currency';

export interface ProductCardData {
  id: string;
  name: string;
  slug: string;
  image: string | null;
  basePrice: number;
  discountPercent: number;
  finalPrice: number;
  isAvailable: boolean;
  customizationEnabled?: boolean;
}

export function ProductCard({ product }: { product: ProductCardData }) {
  return (
    <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-ink-100/80 bg-white transition-all duration-300 hover:-translate-y-1 hover:border-ink-300 hover:shadow-soft">
      {/* Product Image Stage */}
      <Link href={`/product/${product.slug}`} className="relative aspect-[4/5] w-full overflow-hidden bg-powder-50/60">
        {product.image ? (
          <Image
            src={product.image}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className="object-cover object-center transition-transform duration-500 will-change-transform group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-xs text-ink-300">
            تصویر در دسترس نیست
          </div>
        )}

        {/* Minimalist Top Badges */}
        <div className="absolute inset-x-3 top-3 flex items-center justify-between pointer-events-none">
          {product.discountPercent > 0 ? (
            <span className="rounded-md bg-ink-900 px-2 py-0.5 font-mono text-[11px] font-semibold text-cream shadow-sm">
              ٪{toPersianDigits(product.discountPercent)}
            </span>
          ) : <span />}

          {product.customizationEnabled !== false && (
            <span className="rounded-md bg-white/95 px-2 py-0.5 text-[11px] font-medium text-ink-700 shadow-sm backdrop-blur">
              طراحی آنلاین
            </span>
          )}
        </div>

        {!product.isAvailable && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/70 backdrop-blur-[2px]">
            <span className="rounded-md border border-ink-200 bg-white px-3 py-1 text-xs font-medium text-ink-600 shadow-sm">
              ناموجود
            </span>
          </div>
        )}

        {/* Quick Customize Action Overlay on Desktop Hover */}
        {product.customizationEnabled !== false && product.isAvailable && (
          <div className="pointer-events-none absolute inset-x-3 bottom-3 translate-y-2 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 md:block hidden">
            <span className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-ink-900/90 py-2.5 text-xs font-medium text-cream shadow-soft backdrop-blur hover:bg-ink-900 pointer-events-auto">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 20h9" />
                <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
              </svg>
              سفارشی‌سازی محصول
            </span>
          </div>
        )}
      </Link>

      {/* Info Container */}
      <div className="flex flex-1 flex-col justify-between p-4">
        <div>
          <Link href={`/product/${product.slug}`} className="block">
            <h3 className="line-clamp-1 text-sm font-semibold text-ink-900 transition-colors group-hover:text-ink-600">
              {product.name}
            </h3>
          </Link>
        </div>

        <div className="mt-3 flex items-center justify-between pt-2 border-t border-ink-50">
          <div className="flex items-baseline gap-1.5">
            <span className="text-base font-bold text-ink-900 font-mono">
              {formatPriceNumber(product.finalPrice)}
            </span>
            <span className="text-[11px] font-medium text-ink-500">تومان</span>
          </div>

          {product.discountPercent > 0 && (
            <span className="text-xs text-ink-400 line-through font-mono">
              {formatPriceNumber(product.basePrice)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
