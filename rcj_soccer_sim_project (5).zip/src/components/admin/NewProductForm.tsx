'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { clientFetch } from '@/lib/client-fetch';

interface NewProductFormProps {
  categories: Array<{ id: string; name: string }>;
}

function parsePersianNumber(val: any, fallback = 0): number {
  if (typeof val === 'number') return isNaN(val) ? fallback : val;
  if (!val) return fallback;
  const str = String(val)
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[,_٬\s]/g, '');
  const num = Number(str);
  return isNaN(num) ? fallback : num;
}

export function NewProductForm({ categories }: NewProductFormProps) {
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [categoryId, setCategoryId] = useState(categories[0]?.id || '');
  const [description, setDescription] = useState('');
  const [basePrice, setBasePrice] = useState('350000');
  const [discountPercent, setDiscountPercent] = useState('0');
  const [stock, setStock] = useState('50');
  const [customizationEnabled, setCustomizationEnabled] = useState(true);
  const [imageUrl, setImageUrl] = useState('');
  const [uploadingImage, setUploadingImage] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    setError(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await clientFetch('/api/upload', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'خطا در آپلود تصویر.');
        return;
      }
      setImageUrl(data.url);
    } catch {
      setError('خطای شبکه هنگام آپلود تصویر.');
    } finally {
      setUploadingImage(false);
    }
  }

  async function handleSave(target: 'list' | 'edit') {
    if (!name.trim()) {
      setError('لطفاً نام محصول را وارد کنید.');
      return;
    }

    setBusy(true);
    setError(null);
    setSuccess(null);

    const effectiveBasePrice = parsePersianNumber(basePrice, 0);
    const effectiveStock = parsePersianNumber(stock, 50);
    const effectiveDiscount = parsePersianNumber(discountPercent, 0);

    let effectiveSlug = (slug || name)
      .trim()
      .toLowerCase()
      .replace(/[^\w\u0600-\u06FF\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');

    if (!effectiveSlug || effectiveSlug === '-') {
      effectiveSlug = `item-${Date.now().toString().slice(-6)}`;
    }

    try {
      const res = await clientFetch('/api/admin/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          slug: effectiveSlug,
          categoryId: categoryId || categories[0]?.id,
          description: description.trim(),
          basePrice: effectiveBasePrice,
          discountPercent: effectiveDiscount,
          stock: effectiveStock,
          customizationEnabled,
          isAvailable: true,
          imageUrl: imageUrl || null
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'خطا در ثبت محصول.');
        setBusy(false);
        return;
      }

      setSuccess('محصول با موفقیت ثبت شد!');

      // Full navigation to ensure 100% fresh data from server
      setTimeout(() => {
        if (target === 'list') {
          window.location.href = '/admin/products';
        } else {
          window.location.href = `/admin/products/${data.id}/edit`;
        }
      }, 400);
    } catch (err: any) {
      setError(err?.message || 'خطای شبکه در ارتباط با سرور.');
      setBusy(false);
    }
  }

  return (
    <div className="card p-6 space-y-5 text-xs max-w-2xl">
      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-3.5 text-red-700 font-medium">
          {error}
        </div>
      )}

      {success && (
        <div className="rounded-xl border border-green-200 bg-green-50 p-3.5 text-green-700 font-bold flex items-center gap-2">
          <span>✓</span>
          <span>{success} در حال انتقال...</span>
        </div>
      )}

      {/* Row 1: Name and Category */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="label">
            نام محصول <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="مثلاً: هودی مشکی توکرکی زمستانه"
            className="input"
            required
          />
        </div>

        <div>
          <label className="label">
            دسته‌بندی <span className="text-red-500">*</span>
          </label>
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className="input"
            required
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Row 2: Price, Stock, Discount */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="label">قیمت پایه (تومان)</label>
          <input
            type="text"
            value={basePrice}
            onChange={(e) => setBasePrice(e.target.value)}
            className="input"
            placeholder="350000"
            required
          />
        </div>

        <div>
          <label className="label">موجودی اولیه</label>
          <input
            type="text"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            className="input"
            placeholder="50"
            required
          />
        </div>

        <div>
          <label className="label">درصد تخفیف (اختیاری)</label>
          <input
            type="text"
            value={discountPercent}
            onChange={(e) => setDiscountPercent(e.target.value)}
            className="input"
            placeholder="0"
          />
        </div>
      </div>

      {/* Row 3: Product Image Upload */}
      <div className="rounded-xl border border-ink-100 bg-powder-50/50 p-4">
        <label className="label">تصویر اصلی محصول (اختیاری)</label>
        <p className="text-[11px] text-ink-500 mb-3">
          می‌توانید همین حالا عکس محصول را آپلود کنید یا بعداً از صفحه ویرایش نماها اضافه فرمایید.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-4">
          {imageUrl ? (
            <div className="relative h-20 w-20 rounded-xl overflow-hidden border border-ink-200 bg-white shrink-0">
              <Image src={imageUrl} alt="پیش‌نمایش" fill className="object-contain p-1" />
              <button
                type="button"
                onClick={() => setImageUrl('')}
                className="absolute top-1 right-1 bg-red-600 text-white rounded-full h-4 w-4 text-[10px] flex items-center justify-center font-bold"
                title="حذف تصویر"
              >
                ✕
              </button>
            </div>
          ) : (
            <div className="h-20 w-20 rounded-xl border border-dashed border-ink-300 bg-white flex items-center justify-center text-ink-400 text-xs shrink-0">
              بدون تصویر
            </div>
          )}

          <div className="flex-1 space-y-2 w-full">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              disabled={uploadingImage || busy}
              className="text-xs text-ink-600 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-ink-900 file:text-white hover:file:bg-ink-800 cursor-pointer"
            />
            {uploadingImage && <p className="text-[11px] text-powder-800">در حال آپلود تصویر...</p>}
          </div>
        </div>
      </div>

      {/* Row 4: Description */}
      <div>
        <label className="label">توضیحات و مشخصات محصول</label>
        <textarea
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="توضیحات جنس پارچه، نحوه شستشو و کیفیت دوخت و چاپ..."
          className="input resize-none"
        />
      </div>

      {/* Optional Slug */}
      <div>
        <label className="label">نامک انگلیسی یا آدرس URL (اختیاری)</label>
        <input
          type="text"
          dir="ltr"
          value={slug}
          onChange={(e) => setSlug(e.target.value)}
          placeholder="اختیاری - در صورت خالی ماندن خودکار ایجاد می‌شود"
          className="input text-left font-mono text-[11px]"
        />
      </div>

      {/* Customization Checkbox */}
      <div className="flex items-center gap-2 pt-1">
        <input
          type="checkbox"
          id="customization"
          checked={customizationEnabled}
          onChange={(e) => setCustomizationEnabled(e.target.checked)}
          className="h-4 w-4 rounded border-ink-300 text-ink-900 focus:ring-ink-800"
        />
        <label htmlFor="customization" className="text-xs text-ink-800 font-medium cursor-pointer">
          قابلیت طراحی و چاپ سفارشی روی این محصول در ادیتور آنلاین فعال باشد
        </label>
      </div>

      {/* Buttons */}
      <div className="pt-4 border-t border-ink-100 flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => { window.location.href = '/admin/products'; }}
          className="btn-outline !px-4 !py-2 text-xs"
        >
          انصراف و بازگشت
        </button>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => handleSave('list')}
            disabled={busy || uploadingImage}
            className="btn-outline !px-4 !py-2.5 text-xs font-semibold hover:border-ink-900 disabled:opacity-50"
          >
            {busy ? 'در حال ثبت...' : '✓ ثبت و بازگشت به لیست'}
          </button>

          <button
            type="button"
            onClick={() => handleSave('edit')}
            disabled={busy || uploadingImage}
            className="btn-primary !px-5 !py-2.5 text-xs font-bold shadow-md shadow-ink-900/10 disabled:opacity-50"
          >
            {busy ? 'در حال ثبت...' : 'ثبت محصول و تنظیم نماهای چاپ ←'}
          </button>
        </div>
      </div>
    </div>
  );
}
