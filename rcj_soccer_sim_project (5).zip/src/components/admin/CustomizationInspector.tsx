'use client';

import { useState } from 'react';
import Link from 'next/link';
import { toPersianDigits } from '@/lib/currency';

export interface CustomizationRecord {
  id: string;
  productId: string;
  productName: string;
  productSlug: string;
  previewUrl: string | null;
  viewsData: Record<string, any>;
  createdAt: string;
  customerName: string;
  customerEmail?: string | null;
  customerPhone?: string | null;
  status: 'ordered' | 'in_cart' | 'draft';
  orderNumber?: string | null;
  orderId?: string | null;
  orderStatus?: string | null;
}

export function CustomizationInspector({ items }: { items: CustomizationRecord[] }) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'ordered' | 'in_cart' | 'draft'>('all');

  const filtered = items.filter((item) => {
    if (filter === 'all') return true;
    return item.status === filter;
  });

  const activeItem = items.find((i) => i.id === selectedId) || null;

  return (
    <div className="space-y-6">
      {/* Filters Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-ink-100 bg-white p-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-ink-500 ml-2">فیلتر وضعیت:</span>
          {(
            [
              { key: 'all', label: 'همه طرح‌ها' },
              { key: 'ordered', label: 'تبدیل‌شده به سفارش' },
              { key: 'in_cart', label: 'در سبد خرید مشتری' },
              { key: 'draft', label: 'پیش‌نویس‌ها' }
            ] as const
          ).map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setFilter(t.key)}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold transition ${
                filter === t.key
                  ? 'bg-ink-900 text-white shadow-xs'
                  : 'bg-powder-50 text-ink-700 hover:bg-powder-100'
              }`}
            >
              {t.label} ({toPersianDigits(items.filter((i) => t.key === 'all' || i.status === t.key).length)})
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-ink-200 bg-white p-12 text-center text-sm text-ink-400">
          هیچ طرحی با این فیلتر یافت نشد.
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((item) => {
            const viewsCount = Object.keys(item.viewsData || {}).length;
            let totalObjects = 0;
            let textCount = 0;
            let imageCount = 0;

            Object.values(item.viewsData || {}).forEach((v: any) => {
              if (Array.isArray(v?.objects)) {
                totalObjects += v.objects.length;
                v.objects.forEach((obj: any) => {
                  if (obj.type === 'textbox' || obj.type === 'text' || obj.type === 'i-text') {
                    textCount++;
                  } else if (obj.type === 'image') {
                    imageCount++;
                  }
                });
              }
            });

            return (
              <div
                key={item.id}
                className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-xs transition hover:border-ink-300 hover:shadow-soft"
              >
                {/* Visual Preview */}
                <div className="relative aspect-square w-full bg-powder-50/70 p-4 flex items-center justify-center overflow-hidden border-b border-ink-100/60">
                  {item.previewUrl ? (
                    <img
                      src={item.previewUrl}
                      alt={item.productName}
                      className="h-full w-full object-contain transition group-hover:scale-105"
                    />
                  ) : (
                    <div className="text-center text-xs text-ink-400">
                      <span className="block text-3xl mb-1">👕</span>
                      پیش‌نمایش در دسترس نیست
                    </div>
                  )}

                  {/* Status Badge */}
                  <div className="absolute top-3 right-3">
                    {item.status === 'ordered' && (
                      <span className="rounded-md bg-emerald-600 px-2.5 py-1 text-[11px] font-bold text-white shadow-xs">
                        سفارش ثبت‌شده
                      </span>
                    )}
                    {item.status === 'in_cart' && (
                      <span className="rounded-md bg-amber-500 px-2.5 py-1 text-[11px] font-bold text-white shadow-xs">
                        در سبد خرید
                      </span>
                    )}
                    {item.status === 'draft' && (
                      <span className="rounded-md bg-ink-600 px-2.5 py-1 text-[11px] font-medium text-white shadow-xs">
                        پیش‌نویس ذخیره‌شده
                      </span>
                    )}
                  </div>
                </div>

                {/* Card Info */}
                <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-medium text-powder-800">
                        محصول: {item.productName}
                      </span>
                      <span className="text-[10px] text-ink-400 font-mono">
                        {item.createdAt}
                      </span>
                    </div>

                    <p className="text-xs font-bold text-ink-900 line-clamp-1">
                      کاربر: {item.customerName}
                    </p>
                    {item.customerPhone && (
                      <p className="text-[11px] text-ink-500" dir="ltr">
                        {item.customerPhone}
                      </p>
                    )}
                  </div>

                  {/* Layers summary */}
                  <div className="flex items-center gap-3 rounded-xl bg-powder-50/60 p-2.5 text-[11px] text-ink-600">
                    <span>📐 {toPersianDigits(viewsCount)} نما</span>
                    <span>✍️ {toPersianDigits(textCount)} متن</span>
                    <span>🖼️ {toPersianDigits(imageCount)} تصویر</span>
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center gap-2 pt-1 border-t border-ink-50">
                    <button
                      type="button"
                      onClick={() => setSelectedId(item.id)}
                      className="btn-outline flex-1 !py-1.5 text-xs font-semibold text-ink-800"
                    >
                      بررسی جزئیات لایه‌ها 🔍
                    </button>
                    {item.orderId && (
                      <Link
                        href={`/admin/orders/${item.orderId}`}
                        className="btn-primary !py-1.5 !px-3 text-xs font-medium"
                        title="مشاهده سفارش"
                      >
                        سفارش #{item.orderNumber}
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Detail Inspection Modal */}
      {activeItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
          onClick={() => setSelectedId(null)}
        >
          <div
            className="flex max-h-[90vh] w-full max-w-3xl flex-col gap-4 overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
            dir="rtl"
          >
            <div className="flex items-center justify-between border-b border-ink-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-ink-900">
                  جزئیات طرح سفارشی: {activeItem.productName}
                </h3>
                <p className="text-xs text-ink-500 mt-0.5">
                  طراحی‌شده توسط: {activeItem.customerName} ({activeItem.customerPhone || activeItem.customerEmail || 'مشتری'})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedId(null)}
                className="rounded-xl border border-ink-200 px-3 py-1.5 text-xs font-bold text-ink-700 hover:bg-powder-50"
              >
                بستن ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              {/* Preview Image */}
              <div className="space-y-2">
                <p className="text-xs font-bold text-ink-700">پیش‌نمایش موکاپ محصول نهایی:</p>
                <div className="relative aspect-square w-full rounded-2xl border border-ink-100 bg-powder-50 p-3 flex items-center justify-center overflow-hidden">
                  {activeItem.previewUrl ? (
                    <img
                      src={activeItem.previewUrl}
                      alt={activeItem.productName}
                      className="h-full w-full object-contain"
                    />
                  ) : (
                    <span className="text-xs text-ink-400">پیش‌نمایشی ثبت نشده</span>
                  )}
                </div>
              </div>

              {/* Views & Elements Breakdown */}
              <div className="space-y-4 text-xs">
                <div>
                  <p className="text-xs font-bold text-ink-700 mb-2">لایه‌ها و المان‌های طراحی شده:</p>
                  <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                    {Object.entries(activeItem.viewsData || {}).map(([viewId, viewInfo]: [string, any], vIdx) => {
                      const objects = Array.isArray(viewInfo?.objects) ? viewInfo.objects : [];
                      return (
                        <div key={viewId} className="rounded-xl border border-ink-100 bg-powder-50/50 p-3 space-y-2">
                          <p className="font-bold text-ink-900 border-b border-ink-200/50 pb-1.5 flex items-center justify-between">
                            <span>نمای {toPersianDigits(vIdx + 1)} (شناسه: {viewId.slice(-6)})</span>
                            <span className="text-[11px] font-normal text-ink-500">{toPersianDigits(objects.length)} المان</span>
                          </p>

                          {objects.length === 0 ? (
                            <p className="text-ink-400 text-[11px]">بدون المان در این نما</p>
                          ) : (
                            objects.map((obj: any, oIdx: number) => (
                              <div key={oIdx} className="rounded-lg bg-white p-2 border border-ink-100 space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="font-semibold text-ink-800">
                                    {obj.type === 'textbox' || obj.type === 'text' || obj.type === 'i-text'
                                      ? '✍️ متن سفارشی'
                                      : '🖼️ تصویر آپلودشده'}
                                  </span>
                                  {obj.fill && (
                                    <span className="flex items-center gap-1 text-[10px]">
                                      <span className="h-3 w-3 rounded-full border border-ink-300" style={{ backgroundColor: obj.fill }} />
                                      <span dir="ltr" className="font-mono">{obj.fill}</span>
                                    </span>
                                  )}
                                </div>

                                {obj.text && (
                                  <p className="font-bold text-ink-900 bg-powder-50 p-1.5 rounded text-xs">
                                    &ldquo;{obj.text}&rdquo;
                                  </p>
                                )}

                                {obj.src && (
                                  <div className="flex items-center gap-2 pt-1">
                                    <img src={obj.src} alt="element" className="h-10 w-10 object-contain rounded border border-ink-100" />
                                    <a
                                      href={obj.src}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="text-xs text-blue-600 hover:underline"
                                    >
                                      دانلود فایل اصلی تصویر ↗
                                    </a>
                                  </div>
                                )}

                                <p className="text-[10px] text-ink-400 font-mono" dir="ltr">
                                  x: {Math.round(obj.left || 0)}, y: {Math.round(obj.top || 0)}, scale: {(obj.scaleX || 1).toFixed(2)}
                                </p>
                              </div>
                            ))
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {activeItem.orderId && (
                  <div className="rounded-xl bg-emerald-50 p-3 border border-emerald-200">
                    <p className="font-bold text-emerald-800">این طرح برای سفارش شماره #{activeItem.orderNumber} چاپ خواهد شد.</p>
                    <Link href={`/admin/orders/${activeItem.orderId}`} className="text-xs font-semibold text-emerald-700 underline mt-1 inline-block">
                      مشاهده فاکتور و وضعیت سفارش ↗
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
