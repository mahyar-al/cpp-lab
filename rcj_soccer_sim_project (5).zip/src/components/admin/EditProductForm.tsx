'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { clientFetch } from '@/lib/client-fetch';

interface EditProductFormProps {
  productId: string;
  categories: Array<{ id: string; name: string }>;
  initial: {
    name: string;
    slug: string;
    categoryId: string;
    description: string;
    basePrice: number;
    discountPercent: number;
    stock: number;
    isAvailable: boolean;
    customizationEnabled: boolean;
  };
}

export function EditProductForm({ productId, categories, initial }: EditProductFormProps) {
  const router = useRouter();
  const [name, setName] = useState(initial.name);
  const [slug, setSlug] = useState(initial.slug);
  const [categoryId, setCategoryId] = useState(initial.categoryId);
  const [description, setDescription] = useState(initial.description);
  const [basePrice, setBasePrice] = useState(String(initial.basePrice));
  const [discountPercent, setDiscountPercent] = useState(String(initial.discountPercent));
  const [stock, setStock] = useState(String(initial.stock));
  const [isAvailable, setIsAvailable] = useState(initial.isAvailable);
  const [customizationEnabled, setCustomizationEnabled] = useState(initial.customizationEnabled);
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSaved(false);

    try {
      const res = await clientFetch(`/api/admin/products/${productId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          slug: slug.trim().toLowerCase(),
          categoryId,
          description,
          basePrice: Number(basePrice),
          discountPercent: Number(discountPercent),
          stock: Number(stock),
          isAvailable,
          customizationEnabled
        })
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'خطا در ذخیره تغییرات.');
        return;
      }

      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      router.refresh();
    } catch (err: any) {
      setError(err?.message || 'خطای شبکه.');
    } finally {
      setBusy(false);
    }
  }

  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleteBusy, setDeleteBusy] = useState(false);

  async function handleDeleteProduct() {
    setDeleteBusy(true);
    setError(null);
    try {
      const res = await clientFetch(`/api/admin/products/${productId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        router.refresh();
        router.push('/admin/products');
      } else {
        const d = await res.json().catch(() => ({}));
        setError(d.error || 'خطا در حذف محصول.');
        setConfirmDelete(false);
      }
    } catch {
      setError('خطای شبکه در حذف محصول.');
      setConfirmDelete(false);
    } finally {
      setDeleteBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 text-xs">
      {error && <p className="rounded-lg bg-red-50 p-2.5 text-red-600">{error}</p>}
      {saved && <p className="rounded-lg bg-green-50 p-2.5 text-green-700 font-medium">اطلاعات محصول با موفقیت ذخیره شد.</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="label">نام محصول</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="input"
            required
          />
        </div>

        <div>
          <label className="label">نامک انگلیسی (Slug)</label>
          <input
            type="text"
            dir="ltr"
            value={slug}
            onChange={(e) => setSlug(e.target.value)}
            className="input text-left"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="label">دسته‌بندی</label>
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className="input"
            required
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="label">قیمت پایه (تومان)</label>
          <input
            type="number"
            min="0"
            step="1000"
            value={basePrice}
            onChange={(e) => setBasePrice(e.target.value)}
            className="input"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="label">موجودی انبار</label>
          <input
            type="number"
            min="0"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            className="input"
            required
          />
        </div>

        <div>
          <label className="label">درصد تخفیف</label>
          <input
            type="number"
            min="0"
            max="100"
            value={discountPercent}
            onChange={(e) => setDiscountPercent(e.target.value)}
            className="input"
          />
        </div>
      </div>

      <div>
        <label className="label">توضیحات</label>
        <textarea
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="input resize-none"
        />
      </div>

      <div className="flex flex-wrap items-center gap-6 pt-2">
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={isAvailable}
            onChange={(e) => setIsAvailable(e.target.checked)}
            className="h-4 w-4 rounded border-ink-300 text-ink-900"
          />
          <span className="text-xs text-ink-800 font-medium">محصول در سایت فعال و قابل خرید باشد</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={customizationEnabled}
            onChange={(e) => setCustomizationEnabled(e.target.checked)}
            className="h-4 w-4 rounded border-ink-300 text-ink-900"
          />
          <span className="text-xs text-ink-800 font-medium">قابلیت چاپ و طراحی آنلاین فعال باشد</span>
        </label>
      </div>

      <div className="pt-4 border-t border-ink-100 flex flex-wrap items-center justify-between gap-3">
        {confirmDelete ? (
          <div className="flex items-center gap-2 bg-red-50 p-2 rounded-xl border border-red-200">
            <span className="text-xs text-red-700 font-bold">حذف کامل این محصول؟</span>
            <button
              type="button"
              onClick={handleDeleteProduct}
              disabled={deleteBusy}
              className="rounded-lg bg-red-600 px-3 py-1 text-xs font-bold text-white hover:bg-red-700 disabled:opacity-50"
            >
              {deleteBusy ? 'در حال حذف...' : 'بله، حذف کن'}
            </button>
            <button
              type="button"
              onClick={() => setConfirmDelete(false)}
              disabled={deleteBusy}
              className="rounded-lg bg-ink-200 px-3 py-1 text-xs font-medium text-ink-700 hover:bg-ink-300"
            >
              انصراف
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setConfirmDelete(true)}
            className="rounded-xl border border-red-200 bg-red-50/50 px-4 py-2 text-xs font-medium text-red-600 hover:bg-red-100 transition"
          >
            حذف این محصول
          </button>
        )}

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => router.push('/admin/products')}
            className="btn-outline !px-4 !py-2 text-xs"
          >
            بازگشت به لیست
          </button>
          <button type="submit" disabled={busy} className="btn-primary !px-6 !py-2 text-xs font-bold">
            {busy ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
          </button>
        </div>
      </div>
    </form>
  );
}
