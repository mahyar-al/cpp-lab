'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { clientFetch } from '@/lib/client-fetch';

interface ProductRowActionsProps {
  productId: string;
  isArchived: boolean;
  isAvailable: boolean;
  productName: string;
}

export function ProductRowActions({
  productId,
  isArchived,
  isAvailable,
  productName
}: ProductRowActionsProps) {
  const router = useRouter();
  const [archived, setArchived] = useState(isArchived);
  const [available, setAvailable] = useState(isAvailable);
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleted, setDeleted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (deleted) {
    return (
      <span className="text-[11px] text-red-500 font-medium italic">
        حذف شد
      </span>
    );
  }

  async function handleToggleArchive() {
    setBusy(true);
    setError(null);
    try {
      const res = await clientFetch(`/api/admin/products/${productId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isArchived: !archived })
      });
      if (res.ok) {
        setArchived(!archived);
        router.refresh();
      } else {
        const d = await res.json().catch(() => ({}));
        setError(d.error || 'خطا در تغییر وضعیت آرشیو');
      }
    } catch {
      setError('خطای شبکه');
    } finally {
      setBusy(false);
    }
  }

  async function handleToggleAvailable() {
    setBusy(true);
    setError(null);
    try {
      const res = await clientFetch(`/api/admin/products/${productId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isAvailable: !available })
      });
      if (res.ok) {
        setAvailable(!available);
        router.refresh();
      } else {
        const d = await res.json().catch(() => ({}));
        setError(d.error || 'خطا در تغییر وضعیت');
      }
    } catch {
      setError('خطای شبکه');
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    setBusy(true);
    setError(null);
    try {
      const res = await clientFetch(`/api/admin/products/${productId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        setDeleted(true);
        router.refresh();
      } else {
        const d = await res.json().catch(() => ({}));
        setError(d.error || 'خطا در حذف محصول');
        setConfirmDelete(false);
      }
    } catch {
      setError('خطای شبکه در حذف محصول');
      setConfirmDelete(false);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col items-end gap-1.5">
      {error && <span className="text-[10px] text-red-600 max-w-[180px] truncate">{error}</span>}

      {confirmDelete ? (
        <div className="flex items-center gap-1.5 bg-red-50 p-1.5 rounded-lg border border-red-200">
          <span className="text-[11px] text-red-700 font-medium">حذف قطعی شود؟</span>
          <button
            type="button"
            onClick={handleDelete}
            disabled={busy}
            className="rounded bg-red-600 px-2 py-0.5 text-[11px] font-bold text-white hover:bg-red-700 disabled:opacity-50"
          >
            {busy ? '...' : 'بله، حذف کن'}
          </button>
          <button
            type="button"
            onClick={() => setConfirmDelete(false)}
            disabled={busy}
            className="rounded bg-ink-200 px-2 py-0.5 text-[11px] font-medium text-ink-700 hover:bg-ink-300"
          >
            انصراف
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          {/* Edit button */}
          <Link
            href={`/admin/products/${productId}/edit`}
            className="rounded-lg border border-ink-200 bg-white px-2.5 py-1 text-xs font-medium text-ink-700 hover:bg-ink-50 hover:border-ink-300 transition"
          >
            ویرایش
          </Link>

          {/* Toggle Active status */}
          <button
            type="button"
            onClick={handleToggleAvailable}
            disabled={busy}
            title={available ? 'غیرفعال کردن نمایش محصول' : 'فعال کردن نمایش محصول'}
            className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
              available
                ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
            }`}
          >
            {available ? 'فعال' : 'غیرفعال'}
          </button>

          {/* Archive / Unarchive */}
          <button
            type="button"
            onClick={handleToggleArchive}
            disabled={busy}
            title={archived ? 'خروج از بایگانی' : 'انتقال به بایگانی'}
            className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
              archived
                ? 'bg-ink-100 text-ink-700 hover:bg-ink-200'
                : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
            }`}
          >
            {archived ? 'در بایگانی' : 'بایگانی'}
          </button>

          {/* Real Delete button */}
          <button
            type="button"
            onClick={() => setConfirmDelete(true)}
            disabled={busy}
            className="rounded-lg bg-red-50 px-2.5 py-1 text-xs font-medium text-red-600 hover:bg-red-100 transition"
          >
            حذف
          </button>
        </div>
      )}
    </div>
  );
}
