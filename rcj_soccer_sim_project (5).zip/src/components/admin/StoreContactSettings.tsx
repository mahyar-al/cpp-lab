'use client';

import { useState, useEffect } from 'react';
import { clientFetch } from '@/lib/client-fetch';

interface FooterData {
  tagline: string;
  supportPhone: string;
  supportEmail: string;
  address: string;
  workingHours?: string;
  copyright: string;
}

export function StoreContactSettings() {
  const [data, setData] = useState<FooterData>({
    tagline: '',
    supportPhone: '',
    supportEmail: '',
    address: '',
    workingHours: '',
    copyright: ''
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    clientFetch('/api/admin/content')
      .then((res) => res.json())
      .then((resData) => {
        if (resData?.content?.footer) {
          setData({
            tagline: resData.content.footer.tagline || '',
            supportPhone: resData.content.footer.supportPhone || '',
            supportEmail: resData.content.footer.supportEmail || '',
            address: resData.content.footer.address || '',
            workingHours: resData.content.footer.workingHours || '',
            copyright: resData.content.footer.copyright || ''
          });
        }
      })
      .catch((err) => setError('خطا در دریافت اطلاعات: ' + err.message))
      .finally(() => setLoading(false));
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(false);

    try {
      const getRes = await clientFetch('/api/admin/content');
      const currentFull = await getRes.json();
      const updatedContent = {
        ...(currentFull.content || {}),
        footer: {
          ...(currentFull.content?.footer || {}),
          ...data
        }
      };

      const saveRes = await clientFetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: updatedContent })
      });

      if (!saveRes.ok) {
        const errData = await saveRes.json();
        throw new Error(errData.error || 'خطا در ذخیره اطلاعات');
      }

      setSuccess(true);
      setTimeout(() => setSuccess(false), 4000);
    } catch (err: any) {
      setError(err?.message || 'خطا در ثبت اطلاعات.');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="card p-6 text-xs text-ink-500">در حال بارگذاری اطلاعات تماس...</div>;
  }

  return (
    <div className="card space-y-5 p-6">
      <div className="border-b border-ink-100 pb-3">
        <h2 className="text-base font-bold text-ink-900">اطلاعات تماس، پشتیبانی و فروشگاه</h2>
        <p className="mt-1 text-xs text-ink-500">
          این اطلاعات مستقیماً در نوار پایینی و فوتر وب‌سایت برای مشتریان نمایش داده می‌شود.
        </p>
      </div>

      {success && (
        <div className="rounded-xl bg-emerald-50 p-3 text-xs font-semibold text-emerald-700 border border-emerald-200">
          ✓ اطلاعات تماس و فوتر با موفقیت ذخیره شد و در وب‌سایت اعمال گردید.
        </div>
      )}

      {error && (
        <div className="rounded-xl bg-red-50 p-3 text-xs font-medium text-red-600 border border-red-200">
          {error}
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="label text-xs">شماره تماس پشتیبانی</label>
            <input
              type="text"
              className="input text-xs"
              placeholder="مثال: ۰۲۱-۹۱۰۰۰۰۰۰ یا ۰۹۱۲..."
              value={data.supportPhone}
              onChange={(e) => setData({ ...data, supportPhone: e.target.value })}
            />
          </div>

          <div>
            <label className="label text-xs">ایمیل پشتیبانی و پاسخگویی</label>
            <input
              type="email"
              dir="ltr"
              className="input text-xs font-mono"
              placeholder="support@morico.style"
              value={data.supportEmail}
              onChange={(e) => setData({ ...data, supportEmail: e.target.value })}
            />
          </div>
        </div>

        <div>
          <label className="label text-xs">آدرس فیزیکی دفتر / کارگاه چاپ</label>
          <input
            type="text"
            className="input text-xs"
            placeholder="مثال: تهران، خیابان ولیعصر..."
            value={data.address}
            onChange={(e) => setData({ ...data, address: e.target.value })}
          />
        </div>

        <div>
          <label className="label text-xs">ساعات کاری و پاسخگویی</label>
          <input
            type="text"
            className="input text-xs"
            placeholder="مثال: شنبه تا چهارشنبه ۹ الی ۱۸"
            value={data.workingHours || ''}
            onChange={(e) => setData({ ...data, workingHours: e.target.value })}
          />
        </div>

        <div>
          <label className="label text-xs">شعار یا معرفی کوتاه برند در فوتر</label>
          <textarea
            rows={2}
            className="input text-xs leading-6"
            placeholder="هر چیزی که می‌پوشی، می‌تونه امضای تو باشه."
            value={data.tagline}
            onChange={(e) => setData({ ...data, tagline: e.target.value })}
          />
        </div>

        <div>
          <label className="label text-xs">متن کپی‌رایت پایین سایت</label>
          <input
            type="text"
            className="input text-xs"
            placeholder="تمامی حقوق برای برند موریکو محفوظ است."
            value={data.copyright}
            onChange={(e) => setData({ ...data, copyright: e.target.value })}
          />
        </div>

        <div className="pt-2">
          <button
            type="submit"
            disabled={saving}
            className="btn-primary w-full text-xs font-bold py-2.5"
          >
            {saving ? 'در حال ذخیره‌سازی...' : 'ذخیره و بروزرسانی اطلاعات در وب‌سایت'}
          </button>
        </div>
      </form>
    </div>
  );
}
