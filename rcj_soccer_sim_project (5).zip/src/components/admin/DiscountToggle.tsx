'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { clientFetch } from '@/lib/client-fetch';

export function DiscountToggle({ discountId, isActive }: { discountId: string; isActive: boolean }) {
  const router = useRouter();
  const [active, setActive] = useState(isActive);
  const [loading, setLoading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleted, setDeleted] = useState(false);

  if (deleted) {
    return <span className="text-[11px] text-red-500">حذف شد</span>;
  }

  async function handleToggle() {
    setLoading(true);
    try {
      const res = await clientFetch(`/api/admin/discounts/${discountId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !active })
      });
      if (res.ok) {
        setActive(!active);
        router.refresh();
      }
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete() {
    setLoading(true);
    try {
      const res = await clientFetch(`/api/admin/discounts/${discountId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        setDeleted(true);
        router.refresh();
      }
    } finally {
      setLoading(false);
    }
  }

  if (confirmDelete) {
    return (
      <div className="flex items-center gap-1.5 bg-red-50 p-1 rounded-lg">
        <span className="text-[11px] text-red-700">حذف کد؟</span>
        <button
          type="button"
          onClick={handleDelete}
          disabled={loading}
          className="rounded bg-red-600 px-2 py-0.5 text-[10px] font-bold text-white hover:bg-red-700"
        >
          {loading ? '...' : 'بله'}
        </button>
        <button
          type="button"
          onClick={() => setConfirmDelete(false)}
          className="rounded bg-ink-200 px-2 py-0.5 text-[10px] text-ink-700 hover:bg-ink-300"
        >
          خیر
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={handleToggle}
        disabled={loading}
        className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
          active
            ? 'bg-amber-50 text-amber-800 hover:bg-amber-100'
            : 'bg-green-50 text-green-700 hover:bg-green-100'
        }`}
      >
        {active ? 'غیرفعال‌سازی' : 'فعال‌سازی'}
      </button>
      <button
        type="button"
        onClick={() => setConfirmDelete(true)}
        disabled={loading}
        className="rounded-lg bg-red-50 px-2.5 py-1 text-xs font-medium text-red-600 hover:bg-red-100 transition"
      >
        حذف
      </button>
    </div>
  );
}
