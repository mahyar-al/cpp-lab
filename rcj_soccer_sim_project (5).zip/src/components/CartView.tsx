'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { formatPriceNumber, formatToman, toPersianDigits } from '@/lib/currency';
import { clientFetch } from '@/lib/client-fetch';

interface CartItem {
  id: string;
  quantity: number;
  product: { id: string; name: string; slug: string; image: string | null; unitPrice: number };
  customization: { id: string; previewUrl: string | null } | null;
}

export function CartView() {
  const [items, setItems] = useState<CartItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    try {
      const res = await clientFetch('/api/cart');
      if (res.status === 401) {
        setItems([]);
        return;
      }
      const data = await res.json();
      setItems(data.items ?? []);
    } catch {
      setItems([]);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function updateQuantity(id: string, quantity: number) {
    if (quantity < 1) return;
    setError(null);
    try {
      const res = await clientFetch(`/api/cart/items/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quantity })
      });
      if (!res.ok) {
        const data = await res.json();
        setError(data.error);
        return;
      }
      load();
    } catch (err: any) {
      setError(err?.message || 'خطای شبکه در بروزرسانی سبد');
    }
  }

  async function removeItem(id: string) {
    setError(null);
    try {
      const res = await clientFetch(`/api/cart/items/${id}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        setError(data.error);
        return;
      }
      load();
    } catch (err: any) {
      setError(err?.message || 'خطای شبکه در حذف محصول');
    }
  }

  if (items === null) {
    return (
      <div className="flex h-64 items-center justify-center">
        <p className="text-sm text-ink-500 font-medium">در حال بارگذاری سبد خرید...</p>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="rounded-3xl border border-ink-100 bg-white p-12 text-center shadow-card max-w-lg mx-auto">
        <span className="text-4xl">🛍️</span>
        <h3 className="mt-4 text-base font-bold text-ink-900">سبد خرید شما خالی است</h3>
        <p className="mt-2 text-xs text-ink-500 leading-6">
          می‌توانید از بخش فروشگاه محصولات موردعلاقه خود را انتخاب کرده یا طرح اختصاصی خود را بسازید.
        </p>
        <Link href="/shop" className="btn-primary mt-6 !px-8 shadow-soft">
          مشاهده فروشگاه
        </Link>
      </div>
    );
  }

  const subtotal = items.reduce((sum, i) => sum + i.product.unitPrice * i.quantity, 0);
  const freeShippingThreshold = 500000;
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_340px]">
      <div className="space-y-4">
        {error && (
          <div className="rounded-xl border border-red-100 bg-red-50 p-3 text-xs text-red-600 font-medium">
            {error}
          </div>
        )}

        {items.map((item) => (
          <div
            key={item.id}
            className="flex flex-col sm:flex-row gap-4 rounded-2xl border border-ink-100 bg-white p-4 sm:p-5 shadow-card transition hover:border-ink-200"
          >
            <div className="relative aspect-square h-24 w-24 shrink-0 overflow-hidden rounded-xl border border-ink-100 bg-powder-50/70">
              {(item.customization?.previewUrl || item.product.image) ? (
                <Image
                  src={item.customization?.previewUrl || item.product.image!}
                  alt={item.product.name}
                  fill
                  className="object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-[10px] text-ink-300">
                  بدون تصویر
                </div>
              )}
            </div>

            <div className="flex flex-1 flex-col justify-between">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <Link
                    href={`/product/${item.product.slug}`}
                    className="text-sm font-bold text-ink-900 hover:text-ink-600 transition"
                  >
                    {item.product.name}
                  </Link>
                  {item.customization ? (
                    <span className="mt-1 inline-flex items-center gap-1 rounded bg-powder-100 px-2 py-0.5 text-[11px] font-medium text-powder-800">
                      <span>🎨</span>
                      طرح اختصاصی ثبت‌شده
                    </span>
                  ) : (
                    <p className="mt-1 text-xs text-ink-400">محصول خام بدون چاپ</p>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => removeItem(item.id)}
                  className="text-xs font-medium text-red-500 hover:text-red-700 transition"
                >
                  حذف
                </button>
              </div>

              <div className="mt-4 flex items-center justify-between border-t border-ink-50 pt-3">
                <div className="flex items-center overflow-hidden rounded-xl border border-ink-200 bg-powder-50/50">
                  <button
                    type="button"
                    className="px-3 py-1 text-ink-600 hover:bg-powder-100 transition"
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  >
                    −
                  </button>
                  <span className="w-8 text-center text-xs font-semibold text-ink-900 font-mono">
                    {toPersianDigits(item.quantity)}
                  </span>
                  <button
                    type="button"
                    className="px-3 py-1 text-ink-600 hover:bg-powder-100 transition"
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  >
                    +
                  </button>
                </div>

                <div className="text-left">
                  <span className="text-sm font-bold text-ink-900 font-mono">
                    {formatToman(item.product.unitPrice * item.quantity)}
                  </span>
                  <span className="text-[11px] text-ink-400 mr-1">تومان</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Cart Summary Card */}
      <div className="h-fit space-y-5 rounded-3xl border border-ink-100 bg-white p-6 shadow-soft">
        <h3 className="text-base font-bold text-ink-900 border-b border-ink-50 pb-3">خلاصه سفارش</h3>

        {/* Free shipping progress */}
        <div className="rounded-2xl bg-powder-50/80 p-3.5 border border-powder-200 text-xs">
          {remainingForFreeShipping > 0 ? (
            <p className="text-ink-700 font-medium leading-6">
              با افزودن <span className="font-bold text-ink-900 font-mono">{formatToman(remainingForFreeShipping)}</span> دیگر، ارسال شما <span className="font-bold text-emerald-700">کاملاً رایگان</span> خواهد شد!
            </p>
          ) : (
            <p className="font-bold text-emerald-700 flex items-center gap-1.5">
              <span>🎉</span>
              سفارش شما شامل ارسال رایگان است!
            </p>
          )}
        </div>

        <div className="space-y-3 text-xs">
          <div className="flex justify-between text-ink-600">
            <span>مجموع اقلام:</span>
            <span className="font-bold text-ink-900 font-mono">{formatToman(subtotal)}</span>
          </div>
          <div className="flex justify-between text-ink-600">
            <span>هزینه بسته‌بندی و ارسال:</span>
            <span className="font-medium text-ink-700">
              {remainingForFreeShipping === 0 ? 'رایگان' : 'محاسبه در مرحله نهایی'}
            </span>
          </div>
        </div>

        <div className="border-t border-ink-100 pt-4 flex justify-between items-baseline">
          <span className="text-sm font-bold text-ink-900">مبلغ قابل پرداخت:</span>
          <div className="text-left flex items-baseline gap-1">
            <span className="text-lg font-extrabold text-ink-900 font-mono">{formatPriceNumber(subtotal)}</span>
            <span className="text-xs text-ink-500 font-medium">تومان</span>
          </div>
        </div>

        <Link
          href="/checkout"
          className="btn-primary w-full !py-3.5 text-center text-sm font-bold shadow-soft flex items-center justify-center gap-2"
        >
          <span>تکمیل اطلاعات و پرداخت</span>
          <span>←</span>
        </Link>
      </div>
    </div>
  );
}
