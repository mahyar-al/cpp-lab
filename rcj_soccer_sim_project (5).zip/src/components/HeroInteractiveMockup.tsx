'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';

interface ShowcaseProduct {
  id: string;
  name: string;
  category: string;
  price: string;
  originalPrice?: string;
  slug: string;
  image: string;
}

const SHOWCASE_PRODUCTS: ShowcaseProduct[] = [
  {
    id: 'tshirt',
    name: 'تی‌شرت سوپرپنبه ۱۰۰٪ ارگانیک',
    category: 'تی‌شرت و پولوشرت',
    price: '۳۴۲,۰۰۰ تومان',
    originalPrice: '۳۸۰,۰۰۰ تومان',
    slug: 'basic-tshirt',
    image: '/uploads/04c91ebc-bf5b-4f13-8693-da245a1cffbc.png'
  },
  {
    id: 'hoodie',
    name: 'هودی سه‌نخ توکرکی لش زمستانه',
    category: 'هودی و دورس',
    price: '۶۱۲,۰۰۰ تومان',
    originalPrice: '۷۲۰,۰۰۰ تومان',
    slug: 'black-hoodie',
    image: '/uploads/a3ee1fb1-8676-4b59-80e3-99e204a8624d.png'
  },
  {
    id: 'mug',
    name: 'ماگ سرامیکی حرارتی مینیمال',
    category: 'ماگ و ظروف سرامیکی',
    price: '۱۹۵,۰۰۰ تومان',
    slug: 'ceramic-mug',
    image: '/uploads/0ccafa0c-53da-46e1-ab70-e8b9fe177845.jpg'
  },
  {
    id: 'tote',
    name: 'ساک دستی پارچه‌ای کتان (توت‌بگ)',
    category: 'کیف و ساک پارچه‌ای',
    price: '۱۵۲,۰۰۰ تومان',
    originalPrice: '۱۶۰,۰۰۰ تومان',
    slug: 'canvas-tote-bag',
    image: '/uploads/c95f6184-bfe8-482c-a339-922ee3436b7c.png'
  },
  {
    id: 'cap',
    name: 'کلاه کپ کتان استریت‌استایل',
    category: 'کلاه نقاب‌دار و اکسسوری',
    price: '۲۳۰,۰۰۰ تومان',
    slug: 'basic-tshirt',
    image: '/uploads/0af0880c-7b55-4bbb-8853-595a4abdb828.jpg'
  },
  {
    id: 'apparel',
    name: 'تی‌شرت استایل خیابانی مشکی',
    category: 'پوشاک اختصاصی',
    price: '۳۶۰,۰۰۰ تومان',
    slug: 'basic-tshirt',
    image: '/uploads/08111ff9-ea9b-4f1c-b72a-2b421f8a1eb5.png'
  }
];

export function HeroInteractiveMockup() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // 5-second cycle timer
  useEffect(() => {
    if (isHovered) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % SHOWCASE_PRODUCTS.length);
    }, 5000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isHovered]);

  const activeProduct = SHOWCASE_PRODUCTS[currentIndex];

  return (
    <div className="relative w-full max-w-md lg:max-w-[460px] xl:max-w-[500px] transition-all">
      {/* Subtle atmospheric glow ring */}
      <div className="absolute -inset-1 rounded-[2.5rem] bg-gradient-to-r from-powder-300/40 via-powder-100/30 to-powder-400/40 blur-xl opacity-75" />

      {/* Main Glass Mockup Container */}
      <div
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="relative overflow-hidden rounded-[2rem] border border-ink-100/80 bg-white/95 p-5 sm:p-6 lg:p-7 shadow-2xl backdrop-blur-xl transition-all"
      >
        {/* Top Control Bar */}
        <div className="mb-4 flex items-center justify-between border-b border-ink-100/70 pb-3">
          {/* Live Animation Beacon */}
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
            <span className="font-serif text-[11px] font-bold tracking-[0.16em] text-ink-900">
              MORICO SHOWCASE
            </span>
          </div>
        </div>

        {/* Animated Product Card Canvas with Real Product Photos */}
        <div
          key={activeProduct.id}
          className="group relative aspect-[1/1] w-full rounded-2xl p-4 sm:p-5 lg:p-6 flex flex-col items-center justify-between border border-ink-100/80 bg-gradient-to-b from-[#FAF8F5] via-white to-powder-50/50 shadow-inner overflow-hidden animate-fadeUp"
        >
          {/* Subtle ambient light highlight */}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/5 via-transparent to-white/40 rounded-2xl" />

          {/* Central Real Product Photo (Targeted Container) */}
          <div className="relative z-10 my-auto flex h-[210px] w-full items-center justify-center sm:h-[240px] lg:h-[270px]">
            <div className="relative h-full w-full max-w-[280px] sm:max-w-[320px] flex items-center justify-center">
              <Image
                src={activeProduct.image}
                alt={activeProduct.name}
                fill
                sizes="(max-width: 640px) 260px, (max-width: 1024px) 300px, 340px"
                className="object-contain p-2 drop-shadow-xl transition-transform duration-500 will-change-transform group-hover:scale-105"
                priority
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Floating Product Name & Price Bar */}
          <div className="relative z-10 w-full rounded-xl bg-white/95 px-3.5 py-2.5 shadow-lg backdrop-blur-md border border-ink-100/60">
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold text-ink-900">
                  {activeProduct.name}
                </p>
                <p className="text-[10px] text-ink-500 truncate">
                  دسته‌بندی: {activeProduct.category}
                </p>
              </div>

              <div className="text-left shrink-0">
                <p className="text-xs font-bold text-ink-900 font-mono">
                  {activeProduct.price}
                </p>
                {activeProduct.originalPrice && (
                  <p className="text-[10px] text-ink-400 line-through font-mono">
                    {activeProduct.originalPrice}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 6 Dots Indicator (Clickable to inspect any product) */}
        <div className="mt-4 flex items-center justify-center gap-2">
          {SHOWCASE_PRODUCTS.map((prod, idx) => {
            const isActive = idx === currentIndex;
            return (
              <button
                key={prod.id}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                className={`group relative flex items-center transition-all ${
                  isActive ? 'scale-110' : 'hover:scale-105'
                }`}
                title={prod.name}
                aria-label={prod.name}
              >
                <span
                  className={`h-2 rounded-full transition-all duration-300 ${
                    isActive
                      ? 'w-7 bg-ink-900 shadow-xs'
                      : 'w-2 bg-ink-200 group-hover:bg-ink-400'
                  }`}
                />
              </button>
            );
          })}
        </div>

        {/* Action Button: Directly Customize the active product */}
        <Link
          href={`/product/${activeProduct.slug}`}
          className="mt-3.5 flex w-full items-center justify-center gap-2 rounded-xl bg-ink-900 py-3 text-xs font-bold text-cream shadow-md transition hover:bg-ink-800 active:scale-[0.99]"
        >
          <span>شخصی‌سازی و چاپ روی {activeProduct.category}</span>
          <span>←</span>
        </Link>
      </div>
    </div>
  );
}
