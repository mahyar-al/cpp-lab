/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        cream: '#FFFDF9',
        powder: {
          50: '#FAF8F5',
          100: '#F4EFE6',
          200: '#E9DEC9',
          300: '#DCC9A8',
          400: '#CBB285',
          500: '#B89965',
          600: '#9B7B4B',
          700: '#7C603A',
          800: '#5F482D',
          900: '#453421'
        },
        ink: {
          50: '#F7F7F8',
          100: '#EBECEF',
          200: '#D5D7DE',
          300: '#A9ACB9',
          400: '#7B7E8F',
          500: '#5A5D6E',
          600: '#434553',
          700: '#32343E',
          800: '#22232A',
          900: '#141419'
        }
      },
      boxShadow: {
        card: '0 2px 8px -2px rgba(0, 0, 0, 0.05), 0 1px 4px -1px rgba(0, 0, 0, 0.03)',
        soft: '0 10px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.04)'
      }
    }
  },
  plugins: []
};
