# راهنمای استقرار و آپلود روی هاست (Deployment Guide)

این راهنما مراحل کامل آماده‌سازی، آپلود و اجرای پروژه **موریکو (MORICO)** را روی انواع هاست‌ها توضیح می‌دهد.

---

## ۱. پیش‌نیازهای سرور / هاست

- **Node.js**: نسخه ۱۸، ۲۰ یا ۲۲
- **دیتابیس**: دیتابیس PostgreSQL (یا در صورت عدم دسترسی به دیتابیس، سیستم به طور خودکار با دیتابیس داخلی In-Memory اجرا می‌شود)
- **فضای دیسک**: حداقل ۵۰۰ مگابایت برای فایل‌های بیلد و کتابخانه‌ها

---

## ۲. متغیرهای محیطی (.env)

قبل از اجرای پروداکشن، یک فایل `.env` در ریشه پروژه بسازید و مقادیر زیر را تنظیم کنید:

```env
PORT=3000
APP_URL="https://yourdomain.com"
COOKIE_SECURE="true"

# دیتابیس PostgreSQL
DATABASE_URL="postgresql://username:password@localhost:5432/morico?schema=public"

# کلید سکرت دلخواه و طولانی
JWT_SECRET="یک-رشته-طولانی-و-امن-برای-امضای-نشست‌ها"

# درگاه پرداخت (زرین‌پال یا آی‌دی‌پی)
PAYMENT_PROVIDER="zarinpal"
ZARINPAL_MERCHANT_ID="مرچنت-کد-درگاه-شما"
ZARINPAL_SANDBOX="false"

# اطلاعات ورود پیش‌فرض ادمین
SEED_ADMIN_EMAIL="admin@morico.style"
SEED_ADMIN_PASSWORD="ChangeMe123!"
```

---

## ۳. مراحل نصب و بیلد پروژه

روی سرور یا سیستم خود این مراحل را اجرا کنید:

```bash
# ۱. نصب پکیج‌ها
npm install

# ۲. ایجاد کلاینت پریزما و ساخت جداول دیتابیس
npx prisma generate
npx prisma db push

# ۳. مقداردهی اولیه داده‌ها (ادمین و محصولات اولیه)
npm run seed

# ۴. ساخت بیلد پروداکشن
npm run build
```

---

## ۴. روش‌های اجرا روی انواع هاست

### روش اول: سرور لینوکس (VPS) با PM2 و Nginx (پیشنهادی)

۱. پروژه را روی سرور کلون کرده و مراحل بخش ۳ را اجرا کنید.
۲. با ابزار PM2 پروژه را همیشه روشن نگه دارید:
```bash
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

۳. کانفیگ ساده Nginx به عنوان Reverse Proxy:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

### روش دوم: هاست ابری لیارا (Liara)

۱. در پنل لیارا یک برنامه با پلتفرم **Next.js** بسازید.
۲. یک دیتابیس **PostgreSQL** در لیارا بسازید و آدرس `DATABASE_URL` آن را در بخش متغیرهای محیطی برنامه کپی کنید.
۳. متغیرهای محیطی بخش ۲ را در پنل لیارا تعریف کنید.
۴. دستور استقرار را اجرا کنید:
```bash
liara deploy
```

---

### روش سوم: هاست سی‌پنل (cPanel با Setup Node.js App)

۱. فایل‌های پروژه (شامل `src`, `public`, `prisma`, `package.json`, `next.config.js`, `.eslintrc.json`, `tsconfig.json`) را در فایل منیجر آپلود کنید (پوشه `node_modules` و `.next` را آپلود نکنید؛ روی خود هاست ساخته شوند).
۲. در سی‌پنل به بخش **Setup Node.js App** بروید.
۳. نسخه Node.js را روی ۱۸ یا بالاتر بگذارید.
۴. **Application mode** را روی `Production` قرار دهید.
۵. دکمه **Run NPM Install** را بزنید.
۶. از طریق ترمینال سی‌پنل یا دستور بیلد:
```bash
npx prisma generate
npm run build
```
۷. اپلیکیشن را استارت یا Restart کنید.

---

## ۵. تست و ورود به پنل ادمین

- آدرس سایت: `https://yourdomain.com`
- ورود مدیریت: `https://yourdomain.com/admin/login`
- ایمیل مدیر پیش‌فرض: `admin@morico.style`
- رمز عبور پیش‌فرض: `ChangeMe123!`
