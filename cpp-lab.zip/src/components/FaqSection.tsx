'use client';

import { useState } from 'react';

interface FaqItem {
  q: string;
  a: string;
}

export function FaqSection({ faqs }: { faqs: FaqItem[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  if (!faqs || faqs.length === 0) return null;

  return (
    <div className="mx-auto max-w-3xl space-y-3">
      {faqs.map((faq, idx) => {
        const isOpen = openIndex === idx;
        return (
          <div
            key={idx}
            className="overflow-hidden rounded-2xl border border-ink-100 bg-white transition"
          >
            <button
              onClick={() => setOpenIndex(isOpen ? null : idx)}
              className="flex w-full items-center justify-between p-5 text-right font-medium text-ink-900 transition hover:bg-powder-50/50"
            >
              <span className="text-sm font-semibold">{faq.q}</span>
              <span className="mr-3 text-lg font-bold text-ink-400">
                {isOpen ? '−' : '+'}
              </span>
            </button>
            {isOpen && (
              <div className="border-t border-ink-50 p-5 pt-3 text-xs leading-7 text-ink-600 sm:text-sm">
                {faq.a}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
