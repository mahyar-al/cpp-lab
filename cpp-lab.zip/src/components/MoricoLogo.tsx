import Image from 'next/image';

interface MoricoLogoProps {
  className?: string;
  showText?: boolean;
}

export function MoricoLogo({ className = 'h-8 w-8', showText = false }: MoricoLogoProps) {
  return (
    <div className="flex items-center gap-2">
      <div className={`relative overflow-hidden rounded-xl border border-ink-100 bg-white ${className}`}>
        <Image
          src="/brand/morico-logo.jpg"
          alt="MORICO"
          fill
          sizes="64px"
          className="object-cover"
        />
      </div>
      {showText && (
        <div className="flex flex-col">
          <span className="font-serif text-sm font-bold tracking-[0.15em] text-ink-900 leading-none">
            MORICO
          </span>
          <span className="text-[7px] tracking-wider text-ink-400 font-medium leading-tight">
            CUSTOM STUDIO
          </span>
        </div>
      )}
    </div>
  );
}
