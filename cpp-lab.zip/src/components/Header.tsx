'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { MoricoLogo } from './MoricoLogo';
import { UserAuthButton } from './UserAuthButton';
import { clientFetch } from '@/lib/client-fetch';

interface NavItem {
  id: string;
  label: string;
  href: string;
  isHighlight?: boolean;
  isActive?: boolean;
}

const DEFAULT_NAV: NavItem[] = [
  { id: '1', label: 'فروشگاه', href: '/shop' },
  { id: '2', label: 'تی‌شرت', href: '/category/tshirt' },
  { id: '3', label: 'هودی و دورس', href: '/category/hoodie' },
  { id: '4', label: 'ماگ و لیوان', href: '/category/mug' },
  { id: '5', label: '٪ تخفیف‌ها', href: '/shop?discounted=1', isHighlight: true }
];

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [navItems, setNavItems] = useState<NavItem[]>(DEFAULT_NAV);

  useEffect(() => {
    // 1. Fetch Cart count
    clientFetch('/api/cart')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && data.items) {
          const count = data.items.reduce((acc: number, it: any) => acc + (it.quantity || 1), 0);
          setCartCount(count);
        }
      })
      .catch(() => {});

    // 2. Fetch Navigation dynamically so admin deletions/additions reflect live
    fetch('/api/navigation')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && Array.isArray(data.navigation) && data.navigation.length > 0) {
          setNavItems(data.navigation);
        }
      })
      .catch(() => {});
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-ink-100/80 bg-white/90 backdrop-blur-md">
      <div className="container-morico flex h-16 items-center justify-between">
        {/* Brand */}
        <Link href="/" className="flex items-center gap-2">
          <MoricoLogo className="h-8 w-8" />
          <span className="font-serif text-lg font-bold tracking-[0.15em] text-ink-900">MORICO</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden items-center gap-5 md:flex text-xs font-semibold text-ink-700">
          {navItems.map((item) => (
            <Link
              key={item.id}
              href={item.href}
              className={`nav-link transition ${
                item.isHighlight ? 'text-red-600 font-bold hover:text-red-700' : 'hover:text-ink-900'
              }`}
            >
              {item.label}
            </Link>
          ))}

          <Link
            href="/customizer"
            className="rounded-xl bg-ink-900 px-3.5 py-1.5 text-xs font-bold text-cream shadow-xs transition hover:bg-ink-800"
          >
            🎨 استودیو طراحی
          </Link>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <UserAuthButton />

          <Link
            href="/cart"
            className="relative flex items-center gap-1.5 rounded-xl border border-ink-200 px-3 py-1.5 text-xs font-semibold text-ink-800 transition hover:bg-powder-100"
          >
            <span>🛒 سبد خرید</span>
            {cartCount > 0 && (
              <span className="flex h-4 w-4 items-center justify-center rounded-full bg-ink-900 font-mono text-[10px] text-white">
                {cartCount}
              </span>
            )}
          </Link>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-ink-200 text-ink-700 md:hidden"
            aria-label="منو"
          >
            ☰
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="border-t border-ink-100 bg-white p-4 md:hidden">
          <nav className="flex flex-col space-y-2.5 text-xs font-semibold text-ink-800">
            {navItems.map((item) => (
              <Link
                key={item.id}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`rounded-xl p-2 transition ${
                  item.isHighlight
                    ? 'text-red-600 font-bold bg-red-50/50'
                    : 'hover:bg-powder-50'
                }`}
              >
                {item.label}
              </Link>
            ))}

            <Link
              href="/customizer"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-xl bg-ink-900 p-2.5 text-center text-white font-bold"
            >
              🎨 ورود به استودیو طراحی
            </Link>
            <Link
              href="/login"
              onClick={() => setMobileMenuOpen(false)}
              className="rounded-xl border border-ink-200 p-2 text-center text-ink-800 font-bold hover:bg-powder-50"
            >
              👤 ورود / عضویت در سایت
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
