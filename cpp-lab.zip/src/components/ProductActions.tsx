'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { clientFetch } from '@/lib/client-fetch';

interface ProductActionsProps {
  productId: string;
  productSlug: string;
  isAvailable: boolean;
  customizationEnabled: boolean;
}

export function ProductActions({
  productId,
  productSlug,
  isAvailable,
  customizationEnabled
}: ProductActionsProps) {
  const router = useRouter();
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function handleAddToCart() {
    setLoading(true);
    setMessage(null);
    try {
      const res = await clientFetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, quantity })
      });

      if (res.ok) {
        setMessage('به سبد خرید اضافه شد');
        setTimeout(() => setMessage(null), 3000);
      } else {
        const data = await res.json().catch(() => ({}));
        setMessage(data.error || 'خطا در افزودن به سبد');
      }
    } catch {
      setMessage('خطای اتصال به سرور');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-4">
      {isAvailable && (
        <div className="flex items-center gap-4">
          <span className="text-xs font-semibold text-ink-700">تعداد:</span>
          <div className="flex items-center rounded-xl border border-ink-200 bg-white">
            <button
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              className="px-3 py-1.5 text-sm font-bold text-ink-600 hover:bg-powder-100 rounded-r-xl"
              disabled={loading || quantity <= 1}
            >
              −
            </button>
            <span className="w-10 text-center font-mono text-sm font-bold">{quantity}</span>
            <button
              onClick={() => setQuantity((q) => q + 1)}
              className="px-3 py-1.5 text-sm font-bold text-ink-600 hover:bg-powder-100 rounded-l-xl"
              disabled={loading}
            >
              +
            </button>
          </div>
        </div>
      )}

      <div className="flex flex-col gap-3 sm:flex-row">
        {isAvailable && (
          <button
            onClick={handleAddToCart}
            disabled={loading}
            className="btn-primary flex-1 py-3.5 text-sm font-bold"
          >
            {loading ? 'در حال افزودن...' : 'افزودن به سبد خرید'}
          </button>
        )}

        {customizationEnabled && (
          <Link
            href={`/customizer?productId=${productId}`}
            className="btn-outline flex-1 py-3.5 text-center text-sm font-bold text-ink-900 border-ink-900 hover:bg-ink-900 hover:text-white transition"
          >
            🎨 طراحی و سفارشی‌سازی زنده
          </Link>
        )}
      </div>

      {message && (
        <div className="rounded-xl bg-powder-100 p-3 text-center text-xs font-semibold text-ink-800">
          {message}
        </div>
      )}
    </div>
  );
}
