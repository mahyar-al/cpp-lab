'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { clientFetch } from '@/lib/client-fetch';

export function LogoutButton() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleLogout() {
    setLoading(true);
    try {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('morico_token');
      }
      await clientFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    } finally {
      router.push('/admin/login');
      router.refresh();
      setLoading(false);
    }
  }

  return (
    <button
      onClick={handleLogout}
      disabled={loading}
      className="rounded-lg border border-ink-200 px-3 py-1.5 text-xs font-medium text-ink-600 transition hover:bg-powder-100 hover:text-ink-900 disabled:opacity-50"
    >
      {loading ? 'در حال خروج...' : 'خروج از حساب'}
    </button>
  );
}
