export const CANVAS_SIZE = 600;

export interface PrintableArea {
  x: number;
  y: number;
  width: number;
  height: number;
  minDesignWidth: number;
  maxDesignWidth: number;
  minDesignHeight: number;
  maxDesignHeight: number;
}

export interface ProductViewData {
  id: string;
  name: string;
  imageUrl: string;
  sortOrder?: number;
  printableArea: PrintableArea;
}
