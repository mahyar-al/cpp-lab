'use client';

interface BackgroundTouchUpProps {
  originalUrl: string;
  cutoutUrl: string;
  onCancel: () => void;
  onSave: (blob: Blob) => Promise<string | null>;
}

export function BackgroundTouchUp({
  cutoutUrl,
  onCancel,
  onSave
}: BackgroundTouchUpProps) {
  async function handleConfirm() {
    try {
      const res = await fetch(cutoutUrl);
      const blob = await res.blob();
      await onSave(blob);
    } catch {
      onCancel();
    }
  }

  return (
    <div className="mt-3 rounded-2xl border border-ink-200 bg-white p-4 shadow-card">
      <h4 className="text-xs font-bold text-ink-900 mb-2">تایید و اصلاح پس‌زمینه</h4>
      <p className="text-[11px] leading-5 text-ink-500 mb-3">
        پیش‌نمایش حذف پس‌زمینه را بررسی کنید. در صورت تایید روی دکمه ذخیره کلیک کنید.
      </p>

      <div className="flex gap-2">
        <button
          onClick={handleConfirm}
          className="btn-primary flex-1 py-1.5 text-xs"
        >
          ذخیره و اعمال
        </button>
        <button
          onClick={onCancel}
          className="btn-outline flex-1 py-1.5 text-xs"
        >
          انصراف
        </button>
      </div>
    </div>
  );
}
