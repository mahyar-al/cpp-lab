'use client';

import { ProductViewData } from './types';

interface ViewTabsProps {
  views: ProductViewData[];
  activeIndex: number;
  onChange: (index: number) => void;
}

export function ViewTabs({ views, activeIndex, onChange }: ViewTabsProps) {
  if (views.length <= 1) return null;

  return (
    <div className="flex gap-2 border-b border-ink-100 pb-2">
      {views.map((v, i) => (
        <button
          key={v.id}
          onClick={() => onChange(i)}
          className={`rounded-xl px-4 py-2 text-xs font-semibold transition ${
            activeIndex === i
              ? 'bg-ink-900 text-white shadow-sm'
              : 'bg-white text-ink-600 border border-ink-200 hover:bg-powder-100 hover:text-ink-900'
          }`}
        >
          {v.name}
        </button>
      ))}
    </div>
  );
}
