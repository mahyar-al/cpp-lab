'use client';

import { useRef } from 'react';

interface ToolbarProps {
  busy: boolean;
  hasSelection: boolean;
  hasTextSelection: boolean;
  textColor: string;
  onAddText: () => void;
  onUploadImage: (file: File) => void;
  onRemoveBackground: () => void;
  onManualEdit: () => void;
  onDelete: () => void;
  onBringForward: () => void;
  onSendBackward: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onChangeTextColor: (color: string) => void;
}

export function Toolbar({
  busy,
  hasSelection,
  hasTextSelection,
  textColor,
  onAddText,
  onUploadImage,
  onRemoveBackground,
  onManualEdit,
  onDelete,
  onBringForward,
  onSendBackward,
  onUndo,
  onRedo,
  onChangeTextColor
}: ToolbarProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      onUploadImage(file);
      e.target.value = '';
    }
  }

  return (
    <div className="card space-y-4 p-5 shadow-card">
      <h3 className="text-xs font-bold uppercase tracking-wider text-ink-500">ابزارهای طراحی</h3>

      {/* Main Action Buttons */}
      <div className="space-y-2">
        <button
          onClick={onAddText}
          disabled={busy}
          className="btn-outline w-full justify-start text-xs font-semibold"
        >
          ✏️ افزودن متن دلخواه
        </button>

        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={busy}
          className="btn-outline w-full justify-start text-xs font-semibold"
        >
          🖼️ آپلود عکس / لوگو
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />
      </div>

      {/* Selection controls */}
      {hasSelection && (
        <div className="space-y-3 border-t border-ink-100 pt-3">
          <h4 className="text-[11px] font-bold text-ink-600">تنظیمات عنصر انتخاب‌شده:</h4>

          {hasTextSelection && (
            <div>
              <label className="mb-1 block text-[11px] text-ink-500">رنگ متن:</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={textColor}
                  onChange={(e) => onChangeTextColor(e.target.value)}
                  className="h-8 w-10 cursor-pointer rounded border border-ink-200 bg-transparent p-0.5"
                />
                <span className="font-mono text-xs text-ink-600">{textColor}</span>
              </div>
            </div>
          )}

          {!hasTextSelection && (
            <div className="space-y-2">
              <button
                onClick={onRemoveBackground}
                disabled={busy}
                className="btn-outline w-full justify-start text-xs font-medium"
              >
                ✂️ حذف هوشمند پس‌زمینه
              </button>
              <button
                onClick={onManualEdit}
                disabled={busy}
                className="btn-outline w-full justify-start text-xs font-medium"
              >
                🪄 ویرایش دستی ماسک
              </button>
            </div>
          )}

          <div className="flex gap-2">
            <button
              onClick={onBringForward}
              className="btn-outline flex-1 !px-2 text-[11px]"
              title="جلو آوردن لایه"
            >
              ⬆️ یک لایه رو
            </button>
            <button
              onClick={onSendBackward}
              className="btn-outline flex-1 !px-2 text-[11px]"
              title="عقب بردن لایه"
            >
              ⬇️ یک لایه زیر
            </button>
          </div>

          <button
            onClick={onDelete}
            className="w-full rounded-xl bg-red-50 py-2 text-xs font-semibold text-red-600 hover:bg-red-100 transition"
          >
            🗑️ حذف عنصر انتخابی
          </button>
        </div>
      )}

      {/* Undo / Redo */}
      <div className="flex gap-2 border-t border-ink-100 pt-3">
        <button
          onClick={onUndo}
          className="btn-outline flex-1 py-1.5 text-xs"
          title="مرحله قبل"
        >
          ↩ بازگشت
        </button>
        <button
          onClick={onRedo}
          className="btn-outline flex-1 py-1.5 text-xs"
          title="مرحله بعد"
        >
          ↪ جلو رفتن
        </button>
      </div>
    </div>
  );
}
