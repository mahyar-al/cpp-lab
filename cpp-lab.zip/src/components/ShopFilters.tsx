'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';

interface CategoryOption {
  name: string;
  slug: string;
}

export function ShopFilters({ categories }: { categories: CategoryOption[] }) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [q, setQ] = useState(searchParams.get('q') || '');
  const selectedCat = searchParams.get('category') || '';
  const selectedSort = searchParams.get('sort') || 'newest';
  const onlyAvailable = searchParams.get('available') === '1';
  const onlyDiscounted = searchParams.get('discounted') === '1';

  function updateParams(updates: Record<string, string | null>) {
    const current = new URLSearchParams(Array.from(searchParams.entries()));
    for (const [key, value] of Object.entries(updates)) {
      if (value === null || value === '') {
        current.delete(key);
      } else {
        current.set(key, value);
      }
    }
    router.push(`/shop?${current.toString()}`);
  }

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    updateParams({ q: q.trim() || null });
  }

  return (
    <aside className="space-y-6 rounded-2xl border border-ink-100 bg-white p-5 shadow-card">
      {/* Search Input */}
      <div>
        <label className="label">جستجوی محصول</label>
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <input
            type="text"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="مثلا تی‌شرت مشکی..."
            className="input text-xs"
          />
          <button type="submit" className="btn-primary !px-3 !py-2 text-xs">
            جستجو
          </button>
        </form>
      </div>

      {/* Categories */}
      <div>
        <label className="label">دسته‌بندی‌ها</label>
        <div className="space-y-1.5 text-xs">
          <button
            onClick={() => updateParams({ category: null })}
            className={`block w-full rounded-lg px-2.5 py-1.5 text-right font-medium transition ${
              !selectedCat ? 'bg-ink-900 text-white font-bold' : 'text-ink-600 hover:bg-powder-100'
            }`}
          >
            همه دسته‌ها
          </button>
          {categories.map((c) => {
            const isSelected = selectedCat === c.slug;
            return (
              <button
                key={c.slug}
                onClick={() => updateParams({ category: isSelected ? null : c.slug })}
                className={`block w-full rounded-lg px-2.5 py-1.5 text-right font-medium transition ${
                  isSelected ? 'bg-ink-900 text-white font-bold' : 'text-ink-600 hover:bg-powder-100'
                }`}
              >
                {c.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Sort */}
      <div>
        <label className="label">مرتب‌سازی</label>
        <select
          value={selectedSort}
          onChange={(e) => updateParams({ sort: e.target.value })}
          className="input text-xs"
        >
          <option value="newest">جدیدترین</option>
          <option value="cheapest">ارزان‌ترین</option>
          <option value="expensive">گران‌ترین</option>
        </select>
      </div>

      {/* Toggles */}
      <div className="space-y-3 border-t border-ink-100 pt-4 text-xs">
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={onlyAvailable}
            onChange={(e) => updateParams({ available: e.target.checked ? '1' : null })}
            className="rounded border-ink-300 text-ink-900"
          />
          <span className="text-ink-700">فقط کالاهای موجود</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={onlyDiscounted}
            onChange={(e) => updateParams({ discounted: e.target.checked ? '1' : null })}
            className="rounded border-ink-300 text-ink-900"
          />
          <span className="text-ink-700">فقط تخفیف‌دارها</span>
        </label>
      </div>

      {/* Reset */}
      {(selectedCat || selectedSort !== 'newest' || onlyAvailable || onlyDiscounted || q) && (
        <button
          onClick={() => {
            setQ('');
            router.push('/shop');
          }}
          className="w-full rounded-lg border border-ink-200 py-1.5 text-center text-xs font-semibold text-ink-500 hover:bg-powder-100 hover:text-ink-800"
        >
          پاک کردن فیلترها
        </button>
      )}
    </aside>
  );
}
