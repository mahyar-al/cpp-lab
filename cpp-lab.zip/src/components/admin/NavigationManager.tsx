'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Trash2, Plus, AlertTriangle, Menu, ExternalLink, Check, Eye, EyeOff } from 'lucide-react';
import { clientFetch } from '@/lib/client-fetch';
import { SiteNavItem } from '@/lib/site-content';

export function NavigationManager({ initialNav }: { initialNav: SiteNavItem[] }) {
  const router = useRouter();
  const [navItems, setNavItems] = useState<SiteNavItem[]>(initialNav);
  const [label, setLabel] = useState('');
  const [href, setHref] = useState('');
  const [isHighlight, setIsHighlight] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [targetForDelete, setTargetForDelete] = useState<SiteNavItem | null>(null);
  const [deleting, setDeleting] = useState(false);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!label.trim() || !href.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await clientFetch('/api/admin/navigation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          label: label.trim(),
          href: href.trim(),
          isHighlight
        })
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || 'خطا در افزودن آیتم');
        return;
      }

      const data = await res.json();
      setNavItems(data.navigation || [...navItems, data.item]);
      setLabel('');
      setHref('');
      setIsHighlight(false);
      router.refresh();
    } catch {
      setError('خطای شبکه در ثبت');
    } finally {
      setLoading(false);
    }
  }

  async function handleDeleteConfirm() {
    if (!targetForDelete) return;
    setDeleting(true);

    try {
      const res = await clientFetch(`/api/admin/navigation?id=${targetForDelete.id}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        const data = await res.json();
        setNavItems(data.navigation || navItems.filter((i) => i.id !== targetForDelete.id));
        setTargetForDelete(null);
        router.refresh();
      } else {
        const data = await res.json().catch(() => ({}));
        alert(data.error || 'خطا در حذف آیتم منو');
      }
    } catch {
      alert('خطای ارتباط با سرور در حذف آیتم');
    } finally {
      setDeleting(false);
    }
  }

  async function handleToggleActive(item: SiteNavItem) {
    try {
      const res = await clientFetch('/api/admin/navigation', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: item.id,
          isActive: !item.isActive
        })
      });

      if (res.ok) {
        const data = await res.json();
        setNavItems(data.navigation || navItems.map((i) => (i.id === item.id ? { ...i, isActive: !i.isActive } : i)));
        router.refresh();
      }
    } catch {
      alert('خطا در تغییر وضعیت آیتم');
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_340px]">
      {/* Navigation Items List */}
      <div className="card divide-y divide-ink-50 overflow-hidden">
        <div className="p-4 bg-powder-50/70 border-b border-ink-100 flex items-center justify-between">
          <span className="text-xs font-bold text-ink-800">
            فهرست پیوندهای هدر بالای سایت ({navItems.length} پیوند)
          </span>
          <span className="text-[11px] text-ink-500">
            برای حذف یا تغییر وضعیت هر پیوند از دکمه‌های مقابل آن استفاده کنید
          </span>
        </div>

        {navItems.length === 0 ? (
          <p className="p-8 text-center text-sm text-ink-400">هیچ پیوندی در منوی بالای سایت تعریف نشده است.</p>
        ) : (
          navItems.map((item) => (
            <div key={item.id} className="flex flex-wrap items-center justify-between gap-3 p-4 hover:bg-powder-50/40 transition">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-ink-900">{item.label}</span>
                  {item.isHighlight && (
                    <span className="rounded-md bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">
                      برجسته
                    </span>
                  )}
                  <span
                    className={`badge ${
                      item.isActive ? 'bg-green-50 text-green-700' : 'bg-ink-100 text-ink-500'
                    }`}
                  >
                    {item.isActive ? 'فعال در هدر' : 'غیرفعال'}
                  </span>
                </div>
                <p dir="ltr" className="text-xs font-mono text-ink-400 text-right">
                  {item.href}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleActive(item)}
                  className={`flex items-center gap-1 rounded-xl border px-2.5 py-1.5 text-xs font-semibold transition ${
                    item.isActive
                      ? 'border-ink-200 text-ink-600 hover:bg-powder-100'
                      : 'border-green-200 bg-green-50 text-green-700 hover:bg-green-100'
                  }`}
                  title={item.isActive ? 'غیرفعال کردن نمایش در هدر' : 'فعال‌سازی نمایش'}
                >
                  {item.isActive ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                  <span>{item.isActive ? 'مخفی‌سازی' : 'نمایش'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTargetForDelete(item)}
                  className="flex items-center gap-1 rounded-xl border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-bold text-red-600 hover:bg-red-100 transition shadow-xs"
                  title={`حذف پیوند ${item.label}`}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>حذف</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add New Navigation Item */}
      <div className="card p-5 h-fit space-y-4">
        <h2 className="text-sm font-bold text-ink-900 flex items-center gap-1.5">
          <Plus className="h-4 w-4 text-ink-700" />
          <span>افزودن پیوند جدید به هدر</span>
        </h2>

        {error && <div className="rounded-xl bg-red-50 p-2.5 text-xs font-semibold text-red-600">{error}</div>}

        <form onSubmit={handleAdd} className="space-y-4">
          <div>
            <label className="label">عنوان پیوند (متن دکمه در هدر)</label>
            <input
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="مثلا: تخفیف‌های ویژه یا وبلاگ"
              required
              className="input text-xs"
            />
          </div>

          <div>
            <label className="label">آدرس لینک مقصد (URL / مسیر)</label>
            <input
              type="text"
              value={href}
              onChange={(e) => setHref(e.target.value)}
              placeholder="/category/tshirt یا https://..."
              dir="ltr"
              required
              className="input text-xs font-mono"
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="isHighlight"
              checked={isHighlight}
              onChange={(e) => setIsHighlight(e.target.checked)}
              className="rounded border-ink-300 text-ink-900 focus:ring-ink-900"
            />
            <label htmlFor="isHighlight" className="text-xs font-medium text-ink-700 cursor-pointer">
              نمایش با رنگ قرمز یا نشان ویژه
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full py-2.5 text-xs font-bold shadow-xs"
          >
            {loading ? 'در حال افزودن...' : '+ افزودن به منوی هدر'}
          </button>
        </form>
      </div>

      {/* Delete Confirmation Modal */}
      {targetForDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl border border-red-100">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-red-100">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-ink-900">حذف پیوند از هدر سایت</h3>
            </div>

            <p className="text-xs text-ink-600 leading-relaxed mb-6">
              آیا از حذف آیتم «<strong className="text-ink-900 font-bold">{targetForDelete.label}</strong>»
              با آدرس <code dir="ltr" className="bg-powder-100 px-1 py-0.5 rounded font-mono text-[11px]">{targetForDelete.href}</code> از
              منوی بالای سایت اطمینان دارید؟
            </p>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setTargetForDelete(null)}
                disabled={deleting}
                className="rounded-xl border border-ink-200 px-4 py-2 text-xs font-semibold text-ink-700 hover:bg-powder-100 transition"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={deleting}
                className="rounded-xl bg-red-600 px-5 py-2 text-xs font-bold text-white hover:bg-red-700 transition"
              >
                {deleting ? 'در حال حذف...' : 'بله، حذف قطعی پیوند'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
