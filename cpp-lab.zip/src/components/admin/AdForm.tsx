'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { clientFetch } from '@/lib/client-fetch';

export function AdForm() {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [placement, setPlacement] = useState('home');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await clientFetch('/api/admin/ads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          imageUrl: imageUrl.trim() || null,
          linkUrl: linkUrl.trim() || null,
          placement,
          isActive: true
        })
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || 'خطا در ثبت بنر');
        return;
      }

      setTitle('');
      setDescription('');
      setImageUrl('');
      setLinkUrl('');
      router.refresh();
    } catch {
      setError('خطای شبکه در ثبت');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && <div className="rounded-lg bg-red-50 p-2 text-xs text-red-600">{error}</div>}
      <div>
        <label className="label">عنوان بنر</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="مثلا جشنواره تخفیف بهاره"
          required
          className="input text-xs"
        />
      </div>
      <div>
        <label className="label">محل نمایش</label>
        <select value={placement} onChange={(e) => setPlacement(e.target.value)} className="input text-xs">
          <option value="home">صفحه اصلی (Home)</option>
          <option value="shop">فروشگاه (Shop)</option>
        </select>
      </div>
      <div>
        <label className="label">توضیحات کوتاه</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="توضیحات تبلیغ یا متن دکمه..."
          rows={2}
          className="input text-xs"
        />
      </div>
      <div>
        <label className="label">لینک بنر (اختیاری)</label>
        <input
          type="text"
          value={linkUrl}
          onChange={(e) => setLinkUrl(e.target.value)}
          placeholder="/shop?discounted=1"
          dir="ltr"
          className="input text-xs"
        />
      </div>
      <button type="submit" disabled={loading} className="btn-primary w-full py-2.5 text-xs">
        {loading ? 'در حال ثبت...' : '+ ایجاد بنر جدید'}
      </button>
    </form>
  );
}
