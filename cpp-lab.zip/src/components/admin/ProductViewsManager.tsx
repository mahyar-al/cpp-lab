'use client';

import { useState } from 'react';
import Image from 'next/image';

interface PrintableArea {
  x: number;
  y: number;
  width: number;
  height: number;
  minDesignWidth?: number;
  maxDesignWidth?: number;
  minDesignHeight?: number;
  maxDesignHeight?: number;
}

interface ProductViewItem {
  id: string;
  name: string;
  imageUrl: string;
  sortOrder: number;
  printableArea: PrintableArea | null;
}

export function ProductViewsManager({
  productId,
  initialViews
}: {
  productId: string;
  initialViews: ProductViewItem[];
}) {
  const [views, setViews] = useState<ProductViewItem[]>(initialViews);

  return (
    <div className="space-y-4">
      {views.length === 0 ? (
        <p className="text-xs text-ink-400">هنوز نمایی برای این محصول تعریف نشده است.</p>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {views.map((v) => (
            <div key={v.id} className="rounded-xl border border-ink-100 bg-powder-50/50 p-4">
              <div className="relative mb-2 aspect-square w-full overflow-hidden rounded-lg bg-white border border-ink-100">
                <Image src={v.imageUrl} alt={v.name} fill className="object-contain" />
                {v.printableArea && (
                  <div
                    className="absolute border-2 border-dashed border-red-500 bg-red-500/10 pointer-events-none"
                    style={{
                      left: `${(v.printableArea.x / 600) * 100}%`,
                      top: `${(v.printableArea.y / 600) * 100}%`,
                      width: `${(v.printableArea.width / 600) * 100}%`,
                      height: `${(v.printableArea.height / 600) * 100}%`
                    }}
                  />
                )}
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-ink-800">{v.name}</span>
                {v.printableArea && (
                  <span className="font-mono text-[10px] text-ink-500">
                    محدوده: {v.printableArea.width}×{v.printableArea.height}px
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
