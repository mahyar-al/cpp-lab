'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Trash2, AlertTriangle, FolderTree, Plus } from 'lucide-react';
import { clientFetch } from '@/lib/client-fetch';

export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  isActive: boolean;
  sortOrder: number;
  _count?: {
    products: number;
  };
}

export function CategoriesManager({ initialCategories }: { initialCategories: CategoryItem[] }) {
  const router = useRouter();
  const [categories, setCategories] = useState<CategoryItem[]>(initialCategories);
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [targetCategoryForDelete, setTargetCategoryForDelete] = useState<CategoryItem | null>(null);
  const [deleting, setDeleting] = useState(false);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !slug.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await clientFetch('/api/admin/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), slug: slug.trim() })
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || 'خطا در ثبت دسته');
        return;
      }

      const created = await res.json();
      setCategories([...categories, { ...created, _count: { products: 0 } }]);
      setName('');
      setSlug('');
      router.refresh();
    } catch {
      setError('خطای شبکه در ثبت');
    } finally {
      setLoading(false);
    }
  }

  async function handleDeleteCategory() {
    if (!targetCategoryForDelete) return;
    setDeleting(true);

    try {
      const res = await clientFetch(`/api/admin/categories/${targetCategoryForDelete.id}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        setCategories(categories.filter((c) => c.id !== targetCategoryForDelete.id));
        setTargetCategoryForDelete(null);
        router.refresh();
      } else {
        const data = await res.json().catch(() => ({}));
        alert(data.error || 'خطا در حذف دسته‌بندی');
      }
    } catch {
      alert('خطای ارتباط با سرور در حذف دسته');
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
      <div className="card divide-y divide-ink-50 overflow-hidden">
        {categories.length === 0 ? (
          <p className="p-6 text-sm text-ink-400">دسته‌ای ثبت نشده است.</p>
        ) : (
          categories.map((c) => (
            <div key={c.id} className="flex items-center justify-between p-4 hover:bg-powder-50/50 transition">
              <div>
                <span className="font-bold text-sm text-ink-900">{c.name}</span>
                <span dir="ltr" className="mr-3 font-mono text-xs text-ink-400">
                  /{c.slug}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="badge bg-powder-100 text-ink-700 font-semibold">
                  {c._count?.products ?? 0} محصول
                </span>
                <span className={`badge ${c.isActive ? 'bg-green-50 text-green-700' : 'bg-ink-100 text-ink-500'}`}>
                  {c.isActive ? 'فعال' : 'غیرفعال'}
                </span>

                <button
                  type="button"
                  onClick={() => setTargetCategoryForDelete(c)}
                  className="rounded-xl border border-red-200 bg-red-50 p-2 text-red-600 hover:bg-red-100 transition shadow-xs"
                  title={`حذف دسته ${c.name}`}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="card p-5 h-fit">
        <h2 className="mb-4 text-sm font-bold text-ink-900 flex items-center gap-1.5">
          <Plus className="h-4 w-4 text-ink-700" />
          <span>افزودن دسته‌بندی جدید</span>
        </h2>
        <form onSubmit={handleAdd} className="space-y-4">
          {error && <div className="rounded-lg bg-red-50 p-2 text-xs font-semibold text-red-600">{error}</div>}
          <div>
            <label className="label">نام دسته</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثلا کوله‌پشتی"
              required
              className="input text-xs"
            />
          </div>
          <div>
            <label className="label">شناسه انگلیسی (slug)</label>
            <input
              type="text"
              value={slug}
              onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/\s+/g, '-'))}
              placeholder="مثلا backpack"
              dir="ltr"
              required
              className="input text-xs font-mono"
            />
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full py-2.5 text-xs font-bold">
            {loading ? 'در حال ثبت...' : '+ ایجاد دسته‌بندی'}
          </button>
        </form>
      </div>

      {/* Delete Confirmation Modal */}
      {targetCategoryForDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl border border-red-100">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-red-100">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-ink-900">حذف دسته‌بندی</h3>
            </div>

            <p className="text-xs text-ink-600 leading-relaxed mb-6">
              آیا از حذف دسته‌بندی «<strong className="text-ink-900 font-bold">{targetCategoryForDelete.name}</strong>» اطمینان دارید؟
              {targetCategoryForDelete._count?.products ? (
                <span className="block mt-2 text-amber-700 font-medium">
                  توجه: {targetCategoryForDelete._count.products} محصول در این دسته قرار دارند که پس از حذف به حالت بدون دسته‌بندی تغییر می‌یابند.
                </span>
              ) : null}
            </p>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setTargetCategoryForDelete(null)}
                disabled={deleting}
                className="rounded-xl border border-ink-200 px-4 py-2 text-xs font-semibold text-ink-700 hover:bg-powder-100 transition"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleDeleteCategory}
                disabled={deleting}
                className="rounded-xl bg-red-600 px-5 py-2 text-xs font-bold text-white hover:bg-red-700 transition"
              >
                {deleting ? 'در حال حذف...' : 'بله، حذف قطعی'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
