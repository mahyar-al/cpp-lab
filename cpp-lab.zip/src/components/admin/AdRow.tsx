'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { clientFetch } from '@/lib/client-fetch';

interface AdRowProps {
  id: string;
  title: string;
  imageUrl?: string | null;
  placement: string;
  isActive: boolean;
}

export function AdRow({ id, title, imageUrl, placement, isActive: initialActive }: AdRowProps) {
  const router = useRouter();
  const [isActive, setIsActive] = useState(initialActive);
  const [loading, setLoading] = useState(false);

  async function toggleActive() {
    setLoading(true);
    try {
      const next = !isActive;
      const res = await clientFetch(`/api/admin/ads/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: next })
      });
      if (res.ok) {
        setIsActive(next);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete() {
    if (!confirm('آیا از حذف این بنر اطمینان دارید؟')) return;
    setLoading(true);
    try {
      const res = await clientFetch(`/api/admin/ads/${id}`, { method: 'DELETE' });
      if (res.ok) {
        router.refresh();
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card flex items-center justify-between p-4">
      <div>
        <h4 className="text-sm font-semibold text-ink-900">{title}</h4>
        <span className="badge bg-powder-100 text-ink-600 mt-1">محل: {placement}</span>
      </div>
      <div className="flex items-center gap-3">
        <button
          onClick={toggleActive}
          disabled={loading}
          className={`badge cursor-pointer ${isActive ? 'bg-green-50 text-green-700' : 'bg-ink-100 text-ink-500'}`}
        >
          {isActive ? 'فعال' : 'غیرفعال'}
        </button>
        <button
          onClick={handleDelete}
          disabled={loading}
          className="text-xs text-red-500 hover:text-red-700"
        >
          حذف
        </button>
      </div>
    </div>
  );
}
