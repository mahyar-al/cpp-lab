'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Eye,
  Trash2,
  Search,
  Filter,
  Package,
  Calendar,
  AlertTriangle,
  User,
  CheckCircle2
} from 'lucide-react';
import { formatToman, toPersianDigits } from '@/lib/currency';
import { clientFetch } from '@/lib/client-fetch';

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  PENDING_PAYMENT: { label: 'در انتظار پرداخت', color: 'bg-amber-100 text-amber-800' },
  PAID: { label: 'پرداخت شده', color: 'bg-emerald-100 text-emerald-800' },
  PROCESSING: { label: 'در حال پردازش', color: 'bg-blue-100 text-blue-800' },
  PRINTING: { label: 'در حال چاپ اختصاصی', color: 'bg-purple-100 text-purple-800' },
  SHIPPED: { label: 'ارسال شده', color: 'bg-cyan-100 text-cyan-800' },
  DELIVERED: { label: 'تحویل داده شده', color: 'bg-green-100 text-green-800' },
  CANCELED: { label: 'لغو شده', color: 'bg-red-100 text-red-800' }
};

export function OrdersListManager({ initialOrders }: { initialOrders: any[] }) {
  const router = useRouter();
  const [orders, setOrders] = useState<any[]>(initialOrders);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [targetOrderForDelete, setTargetOrderForDelete] = useState<any | null>(null);

  const filteredOrders = orders.filter((o) => {
    if (statusFilter !== 'ALL' && o.status !== statusFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const orderNum = (o.orderNumber || '').toLowerCase();
    const name = (o.fullName || '').toLowerCase();
    const phone = (o.mobile || '').toLowerCase();
    return orderNum.includes(q) || name.includes(q) || phone.includes(q);
  });

  async function handleDeleteConfirm() {
    if (!targetOrderForDelete) return;
    setDeletingId(targetOrderForDelete.id);

    try {
      const res = await clientFetch(`/api/admin/orders/${targetOrderForDelete.id}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        setOrders(orders.filter((o) => o.id !== targetOrderForDelete.id));
        setTargetOrderForDelete(null);
        router.refresh();
      } else {
        const data = await res.json().catch(() => ({}));
        alert(data.error || 'خطا در حذف سفارش');
      }
    } catch {
      alert('خطای ارتباط با سرور در حذف سفارش');
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-stretch sm:items-center bg-white p-4 rounded-2xl border border-ink-100 shadow-xs">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجو با شماره سفارش، نام مشتری یا شماره تماس..."
            className="input pr-9 pl-4 text-xs w-full"
          />
          <Search className="h-4 w-4 text-ink-400 absolute right-3 top-3" />
        </div>

        {/* Filter Dropdown */}
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-ink-400 shrink-0" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-xl border border-ink-200 bg-white px-3 py-2 text-xs font-semibold text-ink-800 shadow-xs focus:border-ink-900 focus:outline-none"
          >
            <option value="ALL">همه وضعیت‌ها ({toPersianDigits(orders.length)})</option>
            <option value="PAID">پرداخت شده</option>
            <option value="PRINTING">در حال چاپ</option>
            <option value="PROCESSING">در حال پردازش</option>
            <option value="SHIPPED">ارسال شده</option>
            <option value="DELIVERED">تحویل شده</option>
            <option value="PENDING_PAYMENT">در انتظار پرداخت</option>
            <option value="CANCELED">لغو شده</option>
          </select>
        </div>
      </div>

      {/* Orders List */}
      <div className="card divide-y divide-ink-100 overflow-hidden">
        {filteredOrders.length === 0 ? (
          <div className="p-12 text-center">
            <Package className="h-10 w-10 text-ink-300 mx-auto mb-3" />
            <p className="text-sm font-semibold text-ink-700">هیچ سفارشی یافت نشد.</p>
            <p className="text-xs text-ink-400 mt-1">با فیلتر یا عبارت دیگری جستجو کنید.</p>
          </div>
        ) : (
          filteredOrders.map((o) => {
            const statusInfo = STATUS_LABELS[o.status] || {
              label: o.status,
              color: 'bg-powder-100 text-ink-700'
            };
            const dateStr = new Date(o.createdAt).toLocaleDateString('fa-IR', {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });

            return (
              <div
                key={o.id}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 hover:bg-powder-50/60 transition"
              >
                {/* Left: Info */}
                <div className="space-y-1">
                  <div className="flex items-center gap-3">
                    <Link
                      href={`/admin/orders/${o.id}`}
                      className="text-sm font-bold text-ink-900 hover:text-primary-700 transition"
                    >
                      سفارش #{toPersianDigits(o.orderNumber)}
                    </Link>
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                  </div>

                  <p className="text-xs text-ink-500 flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-ink-800">{o.fullName}</span>
                    <span>•</span>
                    <span dir="ltr" className="font-mono">{o.mobile}</span>
                    <span>•</span>
                    <span>{o.items?.length || 0} قلم کالا</span>
                    <span>•</span>
                    <span className="text-ink-400">{dateStr}</span>
                  </p>
                </div>

                {/* Right: Price & Action Buttons */}
                <div className="flex items-center gap-3 justify-between sm:justify-end">
                  <span className="font-serif text-sm font-bold text-ink-900">
                    {formatToman(o.totalAmount)}
                  </span>

                  <div className="flex items-center gap-2">
                    <Link
                      href={`/admin/orders/${o.id}`}
                      className="flex items-center gap-1.5 rounded-xl border border-ink-200 bg-white px-3 py-1.5 text-xs font-bold text-ink-700 hover:bg-powder-100 transition shadow-xs"
                      title="مشاهده جزئیات سفارش"
                    >
                      <Eye className="h-3.5 w-3.5" />
                      <span>جزئیات</span>
                    </Link>

                    <button
                      type="button"
                      onClick={() => setTargetOrderForDelete(o)}
                      className="flex items-center gap-1 rounded-xl border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-bold text-red-600 hover:bg-red-100 transition shadow-xs"
                      title="حذف سفارش"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>حذف</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {targetOrderForDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl border border-red-100">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-red-100">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-ink-900">حذف همیشگی سفارش</h3>
            </div>

            <p className="text-xs text-ink-600 leading-relaxed mb-6">
              آیا از حذف سفارش شماره{' '}
              <strong className="text-ink-900 font-bold">
                {toPersianDigits(targetOrderForDelete.orderNumber)}
              </strong>{' '}
              مربوط به «{targetOrderForDelete.fullName}» به مبلغ{' '}
              {formatToman(targetOrderForDelete.totalAmount)} اطمینان دارید؟
            </p>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setTargetOrderForDelete(null)}
                disabled={!!deletingId}
                className="rounded-xl border border-ink-200 px-4 py-2 text-xs font-semibold text-ink-700 hover:bg-powder-100 transition"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={!!deletingId}
                className="rounded-xl bg-red-600 px-5 py-2 text-xs font-bold text-white hover:bg-red-700 transition"
              >
                {deletingId ? 'در حال حذف...' : 'حذف قطعی'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
