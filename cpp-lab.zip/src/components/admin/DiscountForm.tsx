'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { clientFetch } from '@/lib/client-fetch';

export function DiscountForm() {
  const router = useRouter();
  const [code, setCode] = useState('');
  const [percent, setPercent] = useState('10');
  const [maxUses, setMaxUses] = useState('100');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!code.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await clientFetch('/api/admin/discounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: code.trim().toUpperCase(),
          percent: Number(percent) || 10,
          maxUses: Number(maxUses) || 100
        })
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || 'خطا در ثبت کد تخفیف');
        return;
      }

      setCode('');
      setPercent('10');
      setMaxUses('100');
      router.refresh();
    } catch {
      setError('خطای شبکه در ثبت');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && <div className="rounded-lg bg-red-50 p-2 text-xs text-red-600">{error}</div>}

      <div>
        <label className="label">کد تخفیف (لاتین)</label>
        <input
          type="text"
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="مثلا NOROOZ1403"
          dir="ltr"
          required
          className="input text-xs font-mono uppercase"
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">درصد تخفیف</label>
          <input
            type="number"
            min="1"
            max="100"
            value={percent}
            onChange={(e) => setPercent(e.target.value)}
            required
            className="input text-xs"
          />
        </div>
        <div>
          <label className="label">حداکثر استفاده</label>
          <input
            type="number"
            min="1"
            value={maxUses}
            onChange={(e) => setMaxUses(e.target.value)}
            required
            className="input text-xs"
          />
        </div>
      </div>

      <button type="submit" disabled={loading} className="btn-primary w-full py-2.5 text-xs">
        {loading ? 'در حال ثبت...' : '+ ایجاد کد تخفیف'}
      </button>
    </form>
  );
}
