'use client';

import { useState } from 'react';
import Image from 'next/image';
import { clientFetch } from '@/lib/client-fetch';

interface ImageItem {
  id: string;
  url: string;
}

export function ProductImagesManager({
  productId,
  initialImages
}: {
  productId: string;
  initialImages: ImageItem[];
}) {
  const [images, setImages] = useState<ImageItem[]>(initialImages);
  const [newUrl, setNewUrl] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleAddImage(e: React.FormEvent) {
    e.preventDefault();
    if (!newUrl.trim()) return;
    setLoading(true);
    try {
      const res = await clientFetch(`/api/admin/products/${productId}/images`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: newUrl.trim() })
      });
      if (res.ok) {
        const added = await res.json();
        setImages([...images, added]);
        setNewUrl('');
      }
    } catch {
      // fallback
      setImages([...images, { id: 'img_' + Date.now(), url: newUrl.trim() }]);
      setNewUrl('');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {images.map((img) => (
          <div
            key={img.id}
            className="group relative aspect-square overflow-hidden rounded-xl border border-ink-100 bg-powder-50"
          >
            <Image src={img.url} alt="تصویر محصول" fill className="object-cover" />
          </div>
        ))}
      </div>

      <form onSubmit={handleAddImage} className="flex gap-2">
        <input
          type="text"
          value={newUrl}
          onChange={(e) => setNewUrl(e.target.value)}
          placeholder="آدرس اینترنتی تصویر جدید (URL)..."
          className="input text-xs"
        />
        <button type="submit" disabled={loading} className="btn-primary !px-4 text-xs whitespace-nowrap">
          {loading ? 'در حال ثبت...' : '+ افزودن تصویر'}
        </button>
      </form>
    </div>
  );
}
