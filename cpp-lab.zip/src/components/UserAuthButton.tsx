'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { User, LogOut, Package, Shield, ChevronDown } from 'lucide-react';
import { clientFetch } from '@/lib/client-fetch';

interface UserData {
  id: string;
  name: string;
  email: string;
  role: string;
}

export function UserAuthButton() {
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function loadUser() {
      try {
        const res = await clientFetch('/api/auth/me');
        if (res.ok) {
          const data = await res.json();
          setUser(data.user || null);
        }
      } catch {
        // guest mode
      } finally {
        setLoading(false);
      }
    }

    loadUser();

    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  async function handleLogout() {
    try {
      await clientFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    if (typeof window !== 'undefined') {
      localStorage.removeItem('morico_token');
    }
    setUser(null);
    setDropdownOpen(false);
    window.location.reload();
  }

  if (loading) {
    return (
      <div className="h-8 w-20 animate-pulse rounded-xl bg-powder-200/60" />
    );
  }

  return (
    <div className="relative" ref={dropdownRef}>
      {user ? (
        <>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-1.5 rounded-xl border border-ink-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-ink-800 transition hover:bg-powder-100"
          >
            <div className={`flex h-5 w-5 items-center justify-center rounded-full ${user.role === 'ADMIN' ? 'bg-amber-200 text-amber-900' : 'bg-powder-200 text-ink-700'}`}>
              <User className="h-3.5 w-3.5" />
            </div>
            <span className="max-w-[110px] truncate sm:max-w-[150px]">
              {user.role === 'ADMIN' ? `مدیر (${user.name})` : user.name}
            </span>
            <ChevronDown className="h-3 w-3 text-ink-400" />
          </button>

          {dropdownOpen && (
            <div className="absolute left-0 top-full mt-2 w-56 rounded-2xl border border-ink-100 bg-white p-2 shadow-xl z-50 animate-in fade-in zoom-in-95">
              <div className="border-b border-ink-50 px-3 py-2 text-xs">
                <div className="flex items-center justify-between">
                  <p className="font-bold text-ink-900 truncate">{user.name}</p>
                  {user.role === 'ADMIN' && (
                    <span className="rounded-md bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">
                      مدیر
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-ink-400 truncate" dir="ltr">{user.email}</p>
              </div>

              <div className="space-y-1 py-1 text-xs text-ink-700">
                {user.role === 'ADMIN' && (
                  <Link
                    href="/admin"
                    onClick={() => setDropdownOpen(false)}
                    className="flex items-center gap-2 rounded-xl bg-amber-50 px-3 py-2 text-amber-900 hover:bg-amber-100 transition font-bold"
                  >
                    <Shield className="h-4 w-4 text-amber-600" />
                    <span>ورود به پنل مدیریت ادمین</span>
                  </Link>
                )}

                <Link
                  href="/orders"
                  onClick={() => setDropdownOpen(false)}
                  className="flex items-center gap-2 rounded-xl px-3 py-2 hover:bg-powder-50 transition"
                >
                  <Package className="h-4 w-4 text-ink-500" />
                  <span>پیگیری سفارش‌ها</span>
                </Link>

                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-red-600 hover:bg-red-50 transition"
                >
                  <LogOut className="h-4 w-4" />
                  <span>خروج از حساب</span>
                </button>
              </div>
            </div>
          )}
        </>
      ) : (
        <Link
          href="/login"
          className="flex items-center gap-1.5 rounded-xl border border-ink-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-ink-800 transition hover:bg-powder-100"
          title="ورود یا ثبت‌نام در سایت"
        >
          <User className="h-3.5 w-3.5 text-ink-600" />
          <span>ورود / ثبت‌نام</span>
        </Link>
      )}
    </div>
  );
}
