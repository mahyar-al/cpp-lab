import Link from 'next/link';
import Image from 'next/image';
import { prisma } from '@/lib/prisma';

export async function AdBanner({ placement = 'home' }: { placement?: string }) {
  try {
    const ads = await prisma.advertisement.findMany({
      where: { placement, isActive: true },
      orderBy: { sortOrder: 'asc' },
      take: 1
    });

    const ad = ads[0];
    if (!ad) return null;

    const content = (
      <div className="relative overflow-hidden rounded-2xl border border-ink-100 bg-powder-100 p-6 text-center sm:p-10">
        {ad.imageUrl && (
          <div className="relative mx-auto mb-4 h-32 w-full max-w-xl overflow-hidden rounded-xl">
            <Image src={ad.imageUrl} alt={ad.title || 'تبلیغ'} fill className="object-cover" />
          </div>
        )}
        {ad.title && <h3 className="text-lg font-bold text-ink-900">{ad.title}</h3>}
        {ad.description && <p className="mt-2 text-xs text-ink-600 sm:text-sm">{ad.description}</p>}
      </div>
    );

    return (
      <div className="container-morico my-8">
        {ad.linkUrl ? (
          <Link href={ad.linkUrl} className="block transition hover:opacity-95">
            {content}
          </Link>
        ) : (
          content
        )}
      </div>
    );
  } catch {
    return null;
  }
}
