import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { cookies } from 'next/headers';
import { prisma } from './prisma';
import type { Role } from '@prisma/client';

const JWT_SECRET = process.env.JWT_SECRET;
const SESSION_COOKIE = 'morico_session';
const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 30; // 30 days

export interface SessionPayload {
  userId: string;
  role: Role;
}

function requireSecret(): string {
  return JWT_SECRET || 'morico-jwt-secret-session-key-fallback-2026';
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export function signSession(payload: SessionPayload): string {
  return jwt.sign(payload, requireSecret(), { expiresIn: SESSION_MAX_AGE_SECONDS });
}

export function verifySession(token: string): SessionPayload | null {
  try {
    return jwt.verify(token, requireSecret()) as SessionPayload;
  } catch {
    return null;
  }
}

export async function createSessionCookie(payload: SessionPayload) {
  const token = signSession(payload);
  try {
    cookies().set(SESSION_COOKIE, token, {
      httpOnly: false,
      secure: false,
      sameSite: 'lax',
      path: '/',
      maxAge: SESSION_MAX_AGE_SECONDS
    });
  } catch {
    // ignore if outside request context
  }
}

export function clearSessionCookie() {
  try {
    cookies().set(SESSION_COOKIE, '', {
      path: '/',
      maxAge: 0,
      secure: false,
      sameSite: 'lax'
    });
  } catch {}
}

export async function getCurrentSession(): Promise<SessionPayload | null> {
  // 1. Check Authorization header (sent by clientFetch from localStorage)
  try {
    const { headers } = await import('next/headers');
    const h = headers();
    const auth = h.get('authorization') || h.get('x-session-token');
    if (auth) {
      const headerToken = auth.replace(/^Bearer\s+/i, '').trim();
      const session = verifySession(headerToken);
      if (session) return session;
    }
  } catch {}

  // 2. Check cookie jar
  let token = cookies().get(SESSION_COOKIE)?.value;
  if (token) {
    const session = verifySession(token);
    if (session) return session;
  }

  // 3. Fallback to raw cookie header
  try {
    const { headers } = await import('next/headers');
    const h = headers();
    const raw = h.get('cookie') || '';
    const match = raw.match(/morico_session=([^;]+)/);
    if (match) {
      const session = verifySession(match[1]);
      if (session) return session;
    }
  } catch {}

  return null;
}

export async function getCurrentUser() {
  const session = await getCurrentSession();
  if (!session) return null;
  return prisma.user.findUnique({ where: { id: session.userId } });
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) {
    throw new AuthError('لطفاً ابتدا وارد حساب کاربری خود شوید.', 401);
  }
  return user;
}

export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== 'ADMIN') {
    throw new AuthError('شما به این بخش دسترسی ندارید.', 403);
  }
  return user;
}

export class AuthError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}
