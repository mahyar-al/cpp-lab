export interface RemoveBackgroundOptions {
  tolerance?: number;
  feather?: number;
}

export async function removeBackgroundFromImage(
  source: HTMLImageElement | string,
  options?: RemoveBackgroundOptions
): Promise<{ blob: Blob; url: string }> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  let img: HTMLImageElement;
  if (typeof source === 'string') {
    img = new Image();
    img.crossOrigin = 'anonymous';
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = source;
    });
  } else {
    img = source;
  }

  canvas.width = img.naturalWidth || img.width || 400;
  canvas.height = img.naturalHeight || img.height || 400;

  if (!ctx) {
    throw new Error('Canvas context not available');
  }

  ctx.drawImage(img, 0, 0);

  try {
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;

    // Sample top-left corner color as background color
    const bgR = data[0];
    const bgG = data[1];
    const bgB = data[2];
    const tolerance = options?.tolerance || 32;

    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];

      const diff = Math.sqrt(
        Math.pow(r - bgR, 2) + Math.pow(g - bgG, 2) + Math.pow(b - bgB, 2)
      );

      if (diff < tolerance) {
        data[i + 3] = 0; // Transparent
      }
    }

    ctx.putImageData(imgData, 0, 0);
  } catch {
    // Canvas might be tainted if cross-origin, proceed with raw canvas
  }

  const blob = await new Promise<Blob>((resolve) => {
    canvas.toBlob((b) => {
      resolve(b || new Blob([], { type: 'image/png' }));
    }, 'image/png');
  });

  const url = URL.createObjectURL(blob);
  return { blob, url };
}
