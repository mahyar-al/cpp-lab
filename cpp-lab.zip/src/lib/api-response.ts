import { NextResponse } from 'next/server';
import { AuthError } from './auth';
import { ZodError } from 'zod';

export function withApiErrorHandling<T = any>(
  handler: (req: Request, context: T) => Promise<NextResponse | Response>
) {
  return async (req: Request, context: T) => {
    try {
      return await handler(req, context);
    } catch (err: any) {
      console.error('[API Error]', err);
      if (err instanceof AuthError) {
        return NextResponse.json({ error: err.message }, { status: err.status });
      }
      if (err instanceof ZodError) {
        return NextResponse.json(
          { error: 'اطلاعات ارسالی نامعتبر است', details: err.errors },
          { status: 400 }
        );
      }
      return NextResponse.json(
        { error: err?.message || 'خطای غیرمنتظره در سرور' },
        { status: 500 }
      );
    }
  };
}
