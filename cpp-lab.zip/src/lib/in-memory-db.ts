import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

// In-Memory Database for AI Studio preview / offline database fallback
export interface InMemoryStoreData {
  users: Map<string, any>;
  categories: Map<string, any>;
  products: Map<string, any>;
  productImages: Map<string, any>;
  productViews: Map<string, any>;
  printableAreas: Map<string, any>;
  inventories: Map<string, any>;
  carts: Map<string, any>;
  cartItems: Map<string, any>;
  customizations: Map<string, any>;
  designAssets: Map<string, any>;
  orders: Map<string, any>;
  orderItems: Map<string, any>;
  payments: Map<string, any>;
  discounts: Map<string, any>;
  advertisements: Map<string, any>;
}

function uid(prefix = 'id'): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

class InMemoryDatabase {
  public data: InMemoryStoreData = {
    users: new Map(),
    categories: new Map(),
    products: new Map(),
    productImages: new Map(),
    productViews: new Map(),
    printableAreas: new Map(),
    inventories: new Map(),
    carts: new Map(),
    cartItems: new Map(),
    customizations: new Map(),
    designAssets: new Map(),
    orders: new Map(),
    orderItems: new Map(),
    payments: new Map(),
    discounts: new Map(),
    advertisements: new Map()
  };

  constructor() {
    this.seed();
    this.loadFromDisk();
    this.saveToDisk();
  }

  private getDbFilePath(): string {
    return path.join(process.cwd(), 'data', 'mock-db.json');
  }

  public saveToDisk() {
    try {
      const dir = path.join(process.cwd(), 'data');
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      const serialized: Record<string, any[]> = {};
      for (const [key, map] of Object.entries(this.data)) {
        serialized[key] = Array.from((map as Map<string, any>).entries());
      }
      fs.writeFileSync(this.getDbFilePath(), JSON.stringify(serialized), 'utf-8');
    } catch {
      // ignore
    }
  }

  public loadFromDisk(): boolean {
    try {
      const file = this.getDbFilePath();
      if (!fs.existsSync(file)) return false;
      const content = fs.readFileSync(file, 'utf-8');
      if (!content) return false;
      const parsed = JSON.parse(content);
      for (const [key, entries] of Object.entries(parsed)) {
        if ((this.data as any)[key] && Array.isArray(entries)) {
          const targetMap = (this.data as any)[key] as Map<string, any>;
          for (const [id, item] of entries) {
            targetMap.set(id, item);
          }
        }
      }
      return true;
    } catch {
      return false;
    }
  }

  public seed() {
    const now = new Date();

    // 1. Admin & Customer Users
    const adminPasswordHash = bcrypt.hashSync('ChangeMe123!', 10);
    const adminUser = {
      id: 'usr_admin_1',
      name: 'مدیر موریکو',
      email: 'admin@morico.style',
      phone: '09120000000',
      passwordHash: adminPasswordHash,
      role: 'ADMIN',
      createdAt: now,
      updatedAt: now
    };
    this.data.users.set(adminUser.id, adminUser);

    const ownerUser = {
      id: 'usr_admin_mahyar',
      name: 'مهیار (مدیر ارشد)',
      email: 'mahyarshabrang6@gmail.com',
      phone: '09120000000',
      passwordHash: adminPasswordHash,
      role: 'ADMIN',
      createdAt: now,
      updatedAt: now
    };
    this.data.users.set(ownerUser.id, ownerUser);

    const customerUser = {
      id: 'usr_customer_1',
      name: 'کاربر نمونه',
      email: 'customer@morico.style',
      phone: '09121111111',
      passwordHash: adminPasswordHash,
      role: 'CUSTOMER',
      createdAt: now,
      updatedAt: now
    };
    this.data.users.set(customerUser.id, customerUser);

    // 2. Categories
    const categoriesList = [
      { id: 'cat_tshirt', name: 'تی‌شرت', slug: 'tshirt', sortOrder: 0, isActive: true },
      { id: 'cat_hoodie', name: 'هودی و دورس', slug: 'hoodie', sortOrder: 1, isActive: true },
      { id: 'cat_mug', name: 'ماگ و لیوان', slug: 'mug', sortOrder: 2, isActive: true },
      { id: 'cat_tote', name: 'کیف و ساک پارچه‌ای', slug: 'tote-bag', sortOrder: 3, isActive: true },
      { id: 'cat_cap', name: 'کلاه نقاب‌دار', slug: 'cap', sortOrder: 4, isActive: true },
      { id: 'cat_case', name: 'قاب موبایل', slug: 'phone-case', sortOrder: 5, isActive: true }
    ];

    for (const c of categoriesList) {
      this.data.categories.set(c.id, { ...c, createdAt: now, updatedAt: now });
    }

    // 3. Products
    const productsList = [
      {
        id: 'prod_tshirt_1',
        name: 'تی‌شرت نخی سفید بیسیک',
        slug: 'basic-tshirt',
        description: 'تی‌شرت نخی ۱۰۰٪ پنبه با بافت ریز و عالی، دوخت دوبل یقه و آستین. مناسب برای چاپ باکیفیت و بادوام طرح دلخواه روی جلو و پشت.',
        categoryId: 'cat_tshirt',
        basePrice: 380000,
        discountPercent: 10,
        isAvailable: true,
        isArchived: false,
        customizationEnabled: true,
        stock: 50,
        image: '/brand/morico-logo.jpg',
        views: [
          {
            name: 'جلو',
            imageUrl: '/brand/morico-logo.jpg',
            area: { x: 150, y: 150, width: 300, height: 300, minW: 40, maxW: 300, minH: 40, maxH: 300 }
          },
          {
            name: 'پشت',
            imageUrl: '/brand/morico-logo.jpg',
            area: { x: 150, y: 130, width: 300, height: 340, minW: 40, maxW: 300, minH: 40, maxH: 340 }
          }
        ]
      },
      {
        id: 'prod_hoodie_1',
        name: 'هودی سه نخ توکرکی مشکی',
        slug: 'black-hoodie',
        description: 'هودی ضخیم و زمستانه با پارچه سه نخ پنبه‌ای خارخورده، کلاه بنددار دولایه و جیب کانگورویی. چاپ دیجیتال مستقیم روی سینه و پشت.',
        categoryId: 'cat_hoodie',
        basePrice: 720000,
        discountPercent: 15,
        isAvailable: true,
        isArchived: false,
        customizationEnabled: true,
        stock: 30,
        image: '/brand/morico-mark.jpg',
        views: [
          {
            name: 'جلو',
            imageUrl: '/brand/morico-mark.jpg',
            area: { x: 160, y: 160, width: 280, height: 280, minW: 40, maxW: 280, minH: 40, maxH: 280 }
          },
          {
            name: 'پشت',
            imageUrl: '/brand/morico-mark.jpg',
            area: { x: 150, y: 120, width: 300, height: 350, minW: 40, maxW: 300, minH: 40, maxH: 350 }
          }
        ]
      },
      {
        id: 'prod_mug_1',
        name: 'ماگ سرامیکی دسته رنگی',
        slug: 'ceramic-mug',
        description: 'ماگ سرامیکی براق و درجه یک با قابلیت استفاده در مایکروویو و ماشین ظرفشویی. چاپ حرارتی با پوشش ۳۶۰ درجه و وضوح رنگ بالا.',
        categoryId: 'cat_mug',
        basePrice: 195000,
        discountPercent: 0,
        isAvailable: true,
        isArchived: false,
        customizationEnabled: true,
        stock: 80,
        image: '/brand/morico-logo.jpg',
        views: [
          {
            name: 'نمای اصلی',
            imageUrl: '/brand/morico-logo.jpg',
            area: { x: 140, y: 140, width: 320, height: 260, minW: 30, maxW: 320, minH: 30, maxH: 260 }
          }
        ]
      },
      {
        id: 'prod_tote_1',
        name: 'ساک دستی پارچه‌ای کتان (توت‌بگ)',
        slug: 'canvas-tote-bag',
        description: 'توت‌بگ مقاوم از جنس متقال کتان طبیعی با دسته‌های بلند و بادوام. بهترین گزینه سازگار با محیط زیست برای خریدهای روزمره و استایل مینیمال.',
        categoryId: 'cat_tote',
        basePrice: 160000,
        discountPercent: 5,
        isAvailable: true,
        isArchived: false,
        customizationEnabled: true,
        stock: 45,
        image: '/brand/morico-mark.jpg',
        views: [
          {
            name: 'رو',
            imageUrl: '/brand/morico-mark.jpg',
            area: { x: 140, y: 160, width: 320, height: 320, minW: 40, maxW: 320, minH: 40, maxH: 320 }
          }
        ]
      }
    ];

    for (const p of productsList) {
      const prodRecord = {
        id: p.id,
        name: p.name,
        slug: p.slug,
        description: p.description,
        categoryId: p.categoryId,
        basePrice: p.basePrice,
        discountPercent: p.discountPercent,
        isAvailable: p.isAvailable,
        isArchived: p.isArchived,
        customizationEnabled: p.customizationEnabled,
        createdAt: now,
        updatedAt: now
      };
      this.data.products.set(prodRecord.id, prodRecord);

      // Inventory
      const invId = `inv_${p.id}`;
      this.data.inventories.set(invId, {
        id: invId,
        productId: p.id,
        stock: p.stock,
        updatedAt: now
      });

      // Images
      const imgId = `img_${p.id}_0`;
      this.data.productImages.set(imgId, {
        id: imgId,
        productId: p.id,
        url: p.image,
        altText: p.name,
        sortOrder: 0
      });

      // Views & Printable Area
      p.views.forEach((v, vIndex) => {
        const vId = `view_${p.id}_${vIndex}`;
        this.data.productViews.set(vId, {
          id: vId,
          productId: p.id,
          name: v.name,
          imageUrl: v.imageUrl,
          sortOrder: vIndex
        });

        const areaId = `area_${vId}`;
        this.data.printableAreas.set(areaId, {
          id: areaId,
          productViewId: vId,
          x: v.area.x,
          y: v.area.y,
          width: v.area.width,
          height: v.area.height,
          minDesignWidth: v.area.minW,
          maxDesignWidth: v.area.maxW,
          minDesignHeight: v.area.minH,
          maxDesignHeight: v.area.maxH
        });
      });
    }

    // 4. Advertisements
    const adHome = {
      id: 'ad_home_1',
      title: 'چاپ اختصاصی با کیفیت استودیو موریکو',
      imageUrl: '/brand/morico-logo.jpg',
      linkUrl: '/shop?customizable=1',
      placement: 'home',
      isActive: true,
      sortOrder: 0,
      createdAt: now
    };
    this.data.advertisements.set(adHome.id, adHome);

    // 5. Discounts
    const discountWelcome = {
      id: 'disc_welcome',
      code: 'WELCOME',
      percent: 10,
      maxUses: 1000,
      usesCount: 14,
      isActive: true,
      expiresAt: null,
      createdAt: now
    };
    this.data.discounts.set(discountWelcome.id, discountWelcome);

    const discountMorico = {
      id: 'disc_morico',
      code: 'MORICO2026',
      percent: 15,
      maxUses: 500,
      usesCount: 8,
      isActive: true,
      expiresAt: null,
      createdAt: now
    };
    this.data.discounts.set(discountMorico.id, discountMorico);

    // 6. Sample User Design Asset & Customization
    const sampleAsset = {
      id: 'asset_seed_1',
      userId: 'usr_customer_1',
      url: '/brand/morico-logo.jpg',
      mimeType: 'image/jpeg',
      width: 1200,
      height: 1200,
      sizeBytes: 154200,
      isRemovedBg: true,
      createdAt: new Date(Date.now() - 3600000 * 2)
    };
    this.data.designAssets.set(sampleAsset.id, sampleAsset);

    const sampleCustomization = {
      id: 'cust_seed_1',
      productId: 'prod_hoodie_black',
      previewUrl: '/products/hoodie-black-front.jpg',
      data: {
        view_prod_hoodie_black_0: {
          objects: [
            { type: 'image', src: '/brand/morico-logo.jpg', left: 250, top: 220, scaleX: 0.35, scaleY: 0.35 },
            { type: 'textbox', text: 'MORICO DESIGN', fill: '#FFFFFF', left: 250, top: 310 }
          ]
        }
      },
      createdAt: new Date(Date.now() - 3600000 * 2),
      updatedAt: new Date(Date.now() - 3600000 * 2)
    };
    this.data.customizations.set(sampleCustomization.id, sampleCustomization);

    // Sample Order with customization (starts as PENDING_PAYMENT - no fake revenue before payment)
    const sampleOrder = {
      id: 'ord_seed_1',
      orderNumber: 'MOR-2026-101',
      userId: 'usr_customer_1',
      status: 'PENDING_PAYMENT',
      fullName: 'کاربر نمونه',
      mobile: '09121111111',
      email: 'customer@morico.style',
      province: 'تهران',
      city: 'تهران',
      address: 'خیابان ولیعصر، نرسیده به میدان ونک، پلاک ۱۲',
      postalCode: '1999999999',
      subtotal: 950000,
      discountAmount: 0,
      shippingAmount: 0,
      totalAmount: 950000,
      createdAt: new Date(Date.now() - 3600000 * 2),
      updatedAt: new Date(Date.now() - 3600000 * 2)
    };
    this.data.orders.set(sampleOrder.id, sampleOrder);

    const sampleOrderItem = {
      id: 'oi_seed_1',
      orderId: sampleOrder.id,
      productId: 'prod_hoodie_black',
      productNameSnapshot: 'هودی اورسایز مشکی',
      unitPriceSnapshot: 950000,
      quantity: 1,
      customizationId: sampleCustomization.id
    };
    this.data.orderItems.set(sampleOrderItem.id, sampleOrderItem);
  }

  // Model accessors
  public getModel(modelName: string) {
    const key = modelName.toLowerCase();
    switch (key) {
      case 'user':
        return this.createModelHandler(this.data.users, 'usr', (item, inc) => {
          if (inc?.cart) {
            item.cart = Array.from(this.data.carts.values()).find((c) => c.userId === item.id) ?? null;
          }
          if (inc?.orders) {
            item.orders = Array.from(this.data.orders.values()).filter((o) => o.userId === item.id);
          }
          return item;
        });

      case 'category':
        return this.createModelHandler(this.data.categories, 'cat', (item, inc) => {
          if (inc?.products) {
            item.products = Array.from(this.data.products.values()).filter(
              (p) => p.categoryId === item.id && !p.isArchived
            );
          }
          if (inc?._count) {
            const prodCount = Array.from(this.data.products.values()).filter(
              (p) => p.categoryId === item.id && !p.isArchived
            ).length;
            item._count = { products: prodCount };
          }
          return item;
        });

      case 'product':
        return this.createModelHandler(this.data.products, 'prod', (item, inc) => {
          if (inc?.images) {
            const imgs = Array.from(this.data.productImages.values())
              .filter((i) => i.productId === item.id)
              .sort((a, b) => a.sortOrder - b.sortOrder);
            item.images = inc.images.take ? imgs.slice(0, inc.images.take) : imgs;
          }
          if (inc?.inventory) {
            item.inventory =
              Array.from(this.data.inventories.values()).find((inv) => inv.productId === item.id) ?? null;
          }
          if (inc?.category) {
            item.category = this.data.categories.get(item.categoryId) ?? null;
          }
          if (inc?.views) {
            const views = Array.from(this.data.productViews.values())
              .filter((v) => v.productId === item.id)
              .sort((a, b) => a.sortOrder - b.sortOrder);

            item.views = views.map((v) => {
              const vCopy = { ...v };
              if (inc.views?.include?.printableArea) {
                vCopy.printableArea =
                  Array.from(this.data.printableAreas.values()).find((pa) => pa.productViewId === v.id) ?? null;
              }
              return vCopy;
            });
          }
          return item;
        });

      case 'productimage':
        return this.createModelHandler(this.data.productImages, 'img');

      case 'productview':
        return this.createModelHandler(this.data.productViews, 'view', (item, inc) => {
          if (inc?.printableArea) {
            item.printableArea =
              Array.from(this.data.printableAreas.values()).find((pa) => pa.productViewId === item.id) ?? null;
          }
          return item;
        });

      case 'printablearea':
        return this.createModelHandler(this.data.printableAreas, 'area');

      case 'inventory':
        return this.createModelHandler(this.data.inventories, 'inv');

      case 'cart':
        return this.createModelHandler(this.data.carts, 'cart', (item, inc) => {
          if (inc?.items) {
            const items = Array.from(this.data.cartItems.values()).filter((ci) => ci.cartId === item.id);
            item.items = items.map((ci) => {
              const ciCopy = { ...ci };
              if (inc.items?.include?.product) {
                const prod = this.data.products.get(ci.productId);
                if (prod) {
                  const prodCopy = { ...prod };
                  prodCopy.images = Array.from(this.data.productImages.values())
                    .filter((img) => img.productId === prod.id)
                    .sort((a, b) => a.sortOrder - b.sortOrder);
                  ciCopy.product = prodCopy;
                }
              }
              if (inc.items?.include?.customization) {
                ciCopy.customization = ci.customizationId
                  ? this.data.customizations.get(ci.customizationId) ?? null
                  : null;
              }
              return ciCopy;
            });
          }
          return item;
        });

      case 'cartitem':
        return this.createModelHandler(this.data.cartItems, 'ci', (item, inc) => {
          if (inc?.product) {
            const prod = this.data.products.get(item.productId);
            if (prod) {
              const prodCopy = { ...prod };
              prodCopy.images = Array.from(this.data.productImages.values())
                .filter((img) => img.productId === prod.id)
                .sort((a, b) => a.sortOrder - b.sortOrder);
              item.product = prodCopy;
            }
          }
          if (inc?.customization) {
            item.customization = item.customizationId
              ? this.data.customizations.get(item.customizationId) ?? null
              : null;
          }
          if (inc?.cart) {
            item.cart = this.data.carts.get(item.cartId) ?? null;
          }
          return item;
        });

      case 'customization':
        return this.createModelHandler(this.data.customizations, 'cust', (item, inc) => {
          if (inc?.product) {
            item.product = this.data.products.get(item.productId) ?? null;
          }
          if (inc?.orderItem) {
            const oi = Array.from(this.data.orderItems.values()).find((x) => x.customizationId === item.id);
            if (oi) {
              const oiCopy = { ...oi };
              if (inc.orderItem?.include?.order) {
                const ord = this.data.orders.get(oi.orderId);
                if (ord) {
                  const ordCopy = { ...ord };
                  if (inc.orderItem.include.order.include?.user) {
                    ordCopy.user = this.data.users.get(ord.userId) ?? null;
                  }
                  oiCopy.order = ordCopy;
                }
              }
              item.orderItem = oiCopy;
            } else {
              item.orderItem = null;
            }
          }
          if (inc?.cartItem) {
            const ci = Array.from(this.data.cartItems.values()).find((x) => x.customizationId === item.id);
            if (ci) {
              const ciCopy = { ...ci };
              if (inc.cartItem?.include?.cart) {
                const c = this.data.carts.get(ci.cartId);
                if (c) {
                  const cCopy = { ...c };
                  if (inc.cartItem.include.cart.include?.user) {
                    cCopy.user = this.data.users.get(c.userId) ?? null;
                  }
                  ciCopy.cart = cCopy;
                }
              }
              item.cartItem = ciCopy;
            } else {
              item.cartItem = null;
            }
          }
          return item;
        });

      case 'designasset':
        return this.createModelHandler(this.data.designAssets, 'asset', (item, inc) => {
          if (inc?.user) {
            item.user = item.userId ? this.data.users.get(item.userId) ?? null : null;
          }
          return item;
        });

      case 'order':
        return this.createModelHandler(this.data.orders, 'ord', (item, inc) => {
          if (inc?.items) {
            const items = Array.from(this.data.orderItems.values()).filter((oi) => oi.orderId === item.id);
            item.items = items.map((oi) => {
              const oiCopy = { ...oi };
              if (inc.items?.include?.product) {
                oiCopy.product = this.data.products.get(oi.productId) ?? null;
              }
              if (inc.items?.include?.customization) {
                oiCopy.customization = oi.customizationId
                  ? this.data.customizations.get(oi.customizationId) ?? null
                  : null;
              }
              return oiCopy;
            });
          }
          if (inc?.payment) {
            item.payment =
              Array.from(this.data.payments.values()).find((p) => p.orderId === item.id) ?? null;
          }
          if (inc?.user) {
            item.user = this.data.users.get(item.userId) ?? null;
          }
          return item;
        });

      case 'orderitem':
        return this.createModelHandler(this.data.orderItems, 'oi');

      case 'payment':
        return this.createModelHandler(this.data.payments, 'pay', (item, inc) => {
          if (inc?.order) {
            item.order = this.data.orders.get(item.orderId) ?? null;
          }
          return item;
        });

      case 'discount':
        return this.createModelHandler(this.data.discounts, 'disc');

      case 'advertisement':
        return this.createModelHandler(this.data.advertisements, 'ad');

      default:
        return this.createGenericHandler();
    }
  }

  private filterItem(item: any, where?: any): boolean {
    if (!where) return true;
    for (const [key, val] of Object.entries(where)) {
      if (val === undefined) continue;

      if (key === 'OR' && Array.isArray(val)) {
        if (!val.some((clause) => this.filterItem(item, clause))) return false;
        continue;
      }
      if (key === 'AND' && Array.isArray(val)) {
        if (!val.every((clause) => this.filterItem(item, clause))) return false;
        continue;
      }
      if (key === 'NOT') {
        if (this.filterItem(item, val)) return false;
        continue;
      }

      let itemVal = item[key];
      if (key === 'isArchived' && itemVal === undefined) itemVal = false;
      if (key === 'isAvailable' && itemVal === undefined) itemVal = true;
      if (key === 'isActive' && itemVal === undefined) itemVal = true;

      if (val !== null && typeof val === 'object' && !(val instanceof Date)) {
        const v = val as any;
        // Operators like { equals, contains, in, not, gt, gte, lt, lte, mode }
        if ('equals' in v && itemVal !== v.equals) return false;
        if ('not' in v && itemVal === v.not) return false;
        if ('in' in v && Array.isArray(v.in) && !v.in.includes(itemVal)) return false;
        if ('notIn' in v && Array.isArray(v.notIn) && v.notIn.includes(itemVal)) return false;
        if ('gt' in v && (typeof itemVal !== 'number' || itemVal <= (v.gt as number))) return false;
        if ('gte' in v && (typeof itemVal !== 'number' || itemVal < (v.gte as number))) return false;
        if ('lt' in v && (typeof itemVal !== 'number' || itemVal >= (v.lt as number))) return false;
        if ('lte' in v && (typeof itemVal !== 'number' || itemVal > (v.lte as number))) return false;
        if ('contains' in v && typeof itemVal === 'string') {
          const matchCase = v.mode !== 'insensitive';
          const needle = matchCase ? (v.contains as string) : (v.contains as string).toLowerCase();
          const haystack = matchCase ? itemVal : itemVal.toLowerCase();
          if (!haystack.includes(needle)) return false;
        }
        // Sub-relation where clause (e.g. category: { slug: '...' })
        if (key === 'category' && typeof v === 'object') {
          const cat = this.data.categories.get(item.categoryId);
          if (!cat || !this.filterItem(cat, v)) return false;
        }
      } else {
        if (itemVal !== val) return false;
      }
    }
    return true;
  }

  private sortItems(items: any[], orderBy?: any): any[] {
    if (!orderBy) return items;
    const rules = Array.isArray(orderBy) ? orderBy : [orderBy];

    return [...items].sort((a, b) => {
      for (const rule of rules) {
        for (const [key, dir] of Object.entries(rule)) {
          const mult = dir === 'desc' ? -1 : 1;
          const aVal = a[key];
          const bVal = b[key];
          if (aVal === bVal) continue;
          if (aVal === undefined || aVal === null) return 1 * mult;
          if (bVal === undefined || bVal === null) return -1 * mult;
          if (aVal > bVal) return 1 * mult;
          if (aVal < bVal) return -1 * mult;
        }
      }
      return 0;
    });
  }

  private createModelHandler(
    map: Map<string, any>,
    idPrefix: string,
    enrichFn?: (item: any, include?: any) => any
  ) {
    const handler = {
      findMany: async (args?: any) => {
        let results = Array.from(map.values()).filter((item) => this.filterItem(item, args?.where));
        results = this.sortItems(results, args?.orderBy);

        if (args?.skip) {
          results = results.slice(args.skip);
        }
        if (args?.take) {
          results = results.slice(0, args.take);
        }

        return results.map((item) => {
          const cloned = { ...item };
          return enrichFn ? enrichFn(cloned, args?.include) : cloned;
        });
      },

      findUnique: async (args?: any) => {
        const found = Array.from(map.values()).find((item) => this.filterItem(item, args?.where));
        if (!found) return null;
        const cloned = { ...found };
        return enrichFn ? enrichFn(cloned, args?.include) : cloned;
      },

      findFirst: async (args?: any) => {
        let results = Array.from(map.values()).filter((item) => this.filterItem(item, args?.where));
        results = this.sortItems(results, args?.orderBy);
        if (results.length === 0) return null;
        const cloned = { ...results[0] };
        return enrichFn ? enrichFn(cloned, args?.include) : cloned;
      },

      count: async (args?: any) => {
        return Array.from(map.values()).filter((item) => this.filterItem(item, args?.where)).length;
      },

      create: async (args?: any) => {
        const id = args?.data?.id || uid(idPrefix);
        const now = new Date();
        const item: any = {
          id,
          createdAt: now,
          updatedAt: now,
          ...args?.data
        };

        if (idPrefix === 'prod') {
          item.isArchived = item.isArchived ?? false;
          item.isAvailable = item.isAvailable ?? true;
          item.discountPercent = item.discountPercent ?? 0;
          item.customizationEnabled = item.customizationEnabled ?? true;
        }

        // Handle nested create triggers
        if (idPrefix === 'prod' && args?.data?.inventory?.create) {
          const invId = uid('inv');
          this.data.inventories.set(invId, {
            id: invId,
            productId: id,
            stock: args.data.inventory.create.stock ?? 0,
            updatedAt: now
          });
          delete item.inventory;
        }

        if (idPrefix === 'prod' && args?.data?.images?.create) {
          const imgList = Array.isArray(args.data.images.create)
            ? args.data.images.create
            : [args.data.images.create];
          imgList.forEach((im: any, idx: number) => {
            const imId = uid('img');
            this.data.productImages.set(imId, {
              id: imId,
              productId: id,
              url: im.url,
              altText: im.altText ?? '',
              sortOrder: im.sortOrder ?? idx
            });
          });
          delete item.images;
        }

        map.set(id, item);
        this.saveToDisk();
        const cloned = { ...item };
        return enrichFn ? enrichFn(cloned, args?.include) : cloned;
      },

      update: async (args?: any) => {
        const found = Array.from(map.values()).find((item) => this.filterItem(item, args?.where));
        if (!found) {
          throw new Error(`Record to update not found`);
        }
        const updated = {
          ...found,
          ...args?.data,
          updatedAt: new Date()
        };
        map.set(found.id, updated);
        this.saveToDisk();
        const cloned = { ...updated };
        return enrichFn ? enrichFn(cloned, args?.include) : cloned;
      },

      upsert: async (args?: any) => {
        const found = Array.from(map.values()).find((item) => this.filterItem(item, args?.where));
        if (found) {
          const updated = { ...found, ...args?.update, updatedAt: new Date() };
          map.set(found.id, updated);
          this.saveToDisk();
          const cloned = { ...updated };
          return enrichFn ? enrichFn(cloned, args?.include) : cloned;
        } else {
          const id = args?.create?.id || uid(idPrefix);
          const item = { id, createdAt: new Date(), updatedAt: new Date(), ...args?.create };
          map.set(id, item);
          this.saveToDisk();
          const cloned = { ...item };
          return enrichFn ? enrichFn(cloned, args?.include) : cloned;
        }
      },

      delete: async (args?: any) => {
        const found = Array.from(map.values()).find((item) => this.filterItem(item, args?.where));
        if (found) {
          if (idPrefix === 'prod') {
            const viewIds: string[] = [];
            for (const [vId, v] of Array.from(this.data.productViews.entries())) {
              if (v.productId === found.id) {
                viewIds.push(vId);
                this.data.productViews.delete(vId);
              }
            }
            for (const [paId, pa] of Array.from(this.data.printableAreas.entries())) {
              if (viewIds.includes(pa.productViewId)) {
                this.data.printableAreas.delete(paId);
              }
            }
            for (const [imgId, img] of Array.from(this.data.productImages.entries())) {
              if (img.productId === found.id) {
                this.data.productImages.delete(imgId);
              }
            }
            for (const [invId, inv] of Array.from(this.data.inventories.entries())) {
              if (inv.productId === found.id) {
                this.data.inventories.delete(invId);
              }
            }
            for (const [ciId, ci] of Array.from(this.data.cartItems.entries())) {
              if (ci.productId === found.id) {
                this.data.cartItems.delete(ciId);
              }
            }
          }
          map.delete(found.id);
          this.saveToDisk();
          return found;
        }
        return { count: 0 };
      },

      deleteMany: async (args?: any) => {
        let count = 0;
        for (const [id, item] of Array.from(map.entries())) {
          if (this.filterItem(item, args?.where)) {
            if (idPrefix === 'prod') {
              for (const [vId, v] of Array.from(this.data.productViews.entries())) {
                if (v.productId === id) this.data.productViews.delete(vId);
              }
              for (const [imgId, img] of Array.from(this.data.productImages.entries())) {
                if (img.productId === id) this.data.productImages.delete(imgId);
              }
              for (const [invId, inv] of Array.from(this.data.inventories.entries())) {
                if (inv.productId === id) this.data.inventories.delete(invId);
              }
              for (const [ciId, ci] of Array.from(this.data.cartItems.entries())) {
                if (ci.productId === id) this.data.cartItems.delete(ciId);
              }
            }
            map.delete(id);
            count++;
          }
        }
        if (count > 0) {
          this.saveToDisk();
        }
        return { count };
      },

      aggregate: async (args?: any) => {
        const items = Array.from(map.values()).filter((item) => this.filterItem(item, args?.where));
        const res: any = { _count: items.length };

        if (args?._sum) {
          res._sum = {};
          for (const key of Object.keys(args._sum)) {
            res._sum[key] = items.reduce((acc, curr) => acc + (Number(curr[key]) || 0), 0);
          }
        }
        if (args?._avg) {
          res._avg = {};
          for (const key of Object.keys(args._avg)) {
            const sum = items.reduce((acc, curr) => acc + (Number(curr[key]) || 0), 0);
            res._avg[key] = items.length > 0 ? sum / items.length : 0;
          }
        }
        return res;
      }
    };

    return handler;
  }

  private createGenericHandler() {
    const noOp = {
      findMany: async () => [],
      findFirst: async () => null,
      findUnique: async () => null,
      count: async () => 0,
      create: async (d: any) => ({ id: uid('gen'), ...d?.data }),
      update: async (d: any) => ({ ...d?.data }),
      upsert: async (d: any) => ({ id: uid('gen'), ...(d?.create || d?.update) }),
      delete: async () => ({}),
      deleteMany: async () => ({ count: 0 }),
      aggregate: async () => ({ _count: 0, _sum: {} })
    };
    return noOp;
  }
}

// Global singleton to preserve in-memory data across hot reloads and worker routes
const globalForMockDb = globalThis as unknown as { inMemoryDb?: InMemoryDatabase };
export const inMemoryDb = globalForMockDb.inMemoryDb ?? new InMemoryDatabase();
globalForMockDb.inMemoryDb = inMemoryDb;
