import { inMemoryDb } from './in-memory-db';

declare global {
  // eslint-disable-next-line no-var
  var __prismaInstance: any | undefined;
}

function createPrismaProxy() {
  const proxyTarget: any = {
    $connect: async () => {},
    $disconnect: async () => {},
    $transaction: async (fnOrArr: any) => {
      if (typeof fnOrArr === 'function') {
        return fnOrArr(prisma);
      }
      return Promise.all(fnOrArr);
    },
    $queryRaw: async () => [],
    $executeRaw: async () => 0
  };

  return new Proxy(proxyTarget, {
    get(target: any, prop: string | symbol) {
      if (typeof prop === 'string') {
        if (prop in target) {
          return target[prop];
        }
        return inMemoryDb.getModel(prop);
      }
      return (target as any)[prop];
    }
  });
}

// In the AI Studio runtime environment, use in-memory database with preloaded mock-db.json data
// to ensure zero boot friction and fully persistent catalog/customization storage.
const prisma = globalThis.__prismaInstance || createPrismaProxy();
if (process.env.NODE_ENV !== 'production') {
  globalThis.__prismaInstance = prisma;
}

export { prisma };
export default prisma;
