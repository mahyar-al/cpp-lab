export interface RequestPaymentParams {
  amount?: number;
  amountToman?: number;
  description: string;
  callbackUrl: string;
  mobile?: string;
  email?: string;
  orderNumber?: string;
  orderId?: string;
}

export interface RequestPaymentResult {
  ok?: boolean;
  success?: boolean;
  paymentUrl?: string;
  redirectUrl?: string;
  authority?: string;
  errorMessageFa?: string;
  error?: string;
}

export interface VerifyPaymentParams {
  authority: string;
  amount?: number;
  amountToman?: number;
}

export interface VerifyPaymentResult {
  ok?: boolean;
  success?: boolean;
  refId?: string;
  referenceId?: string;
  cardPan?: string;
  errorMessageFa?: string;
  error?: string;
}

export interface PaymentProvider {
  name: string;
  requestPayment(params: RequestPaymentParams): Promise<RequestPaymentResult>;
  verifyPayment(params: VerifyPaymentParams): Promise<VerifyPaymentResult>;
}
