import type { Metadata } from 'next';
import './globals.css';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { StorefrontShell } from '@/components/StorefrontShell';

export const metadata: Metadata = {
  title: 'Morico - Custom Print-on-Demand E-Commerce',
  description:
    'پلتفرم فروشگاهی فارسی/RTL برای چاپ و سفارشی‌سازی اختصاصی روی محصولات فیزیکی با ویرایشگر زنده و پنل مدیریت.',
  openGraph: {
    title: 'Morico - Custom Print-on-Demand E-Commerce',
    description:
      'پلتفرم فروشگاهی فارسی/RTL برای چاپ و سفارشی‌سازی اختصاصی روی محصولات فیزیکی با ویرایشگر زنده و پنل مدیریت.',
    type: 'website'
  }
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl">
      <body className="min-h-screen bg-[#FAF8F5] text-ink-900 flex flex-col font-sans">
        <StorefrontShell header={<Header />} footer={<Footer />}>
          {children}
        </StorefrontShell>
      </body>
    </html>
  );
}
