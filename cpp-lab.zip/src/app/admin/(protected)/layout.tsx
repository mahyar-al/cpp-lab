import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { MoricoLogo } from '@/components/MoricoLogo';
import { LogoutButton } from '@/components/LogoutButton';
import {
  Home,
  LayoutDashboard,
  ShoppingBag,
  Palette,
  Layers,
  FolderTree,
  Warehouse,
  Percent,
  Menu,
  Megaphone,
  FileText,
  Settings,
  ExternalLink
} from 'lucide-react';

const NAV = [
  { href: '/admin', label: 'داشبورد', icon: LayoutDashboard },
  { href: '/admin/orders', label: 'مدیریت سفارش‌ها', icon: ShoppingBag },
  { href: '/admin/customizations', label: 'طرح‌ها و فایل‌های کاربران', icon: Palette },
  { href: '/admin/products', label: 'محصولات', icon: Layers },
  { href: '/admin/categories', label: 'دسته‌بندی‌ها', icon: FolderTree },
  { href: '/admin/inventory', label: 'موجودی انبار', icon: Warehouse },
  { href: '/admin/discounts', label: 'کدهای تخفیف', icon: Percent },
  { href: '/admin/navigation', label: 'منوی بالای سایت (هدر)', icon: Menu },
  { href: '/admin/ads', label: 'تبلیغات و بنرها', icon: Megaphone },
  { href: '/admin/content', label: 'نوشته‌های سایت', icon: FileText },
  { href: '/admin/settings', label: 'تنظیمات فروشگاه', icon: Settings }
];

export default async function AdminProtectedLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'ADMIN') redirect('/admin/login');

  return (
    <div className="flex min-h-screen bg-powder-50">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 border-l border-ink-100 bg-white p-5 md:flex md:flex-col md:justify-between">
        <div>
          <div className="mb-6 flex items-center gap-3">
            <MoricoLogo className="h-9 w-9" />
            <div>
              <span className="font-serif text-sm font-bold tracking-widest text-ink-900">MORICO</span>
              <p className="text-[10px] text-ink-400">پنل مدیریت یکپارچه</p>
            </div>
          </div>

          {/* Quick link to Storefront */}
          <Link
            href="/"
            className="mb-5 flex items-center justify-center gap-2 rounded-xl bg-ink-900 px-3.5 py-2.5 text-xs font-bold text-cream shadow-xs transition hover:bg-ink-800"
          >
            <Home className="h-4 w-4" />
            <span>ورود به صفحه اصلی سایت</span>
          </Link>

          <nav className="space-y-1">
            {NAV.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className="flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold text-ink-600 transition hover:bg-powder-100 hover:text-ink-900"
                >
                  <Icon className="h-4 w-4 shrink-0 text-ink-400" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Footer info in sidebar */}
        <div className="border-t border-ink-100 pt-4 text-[11px] text-ink-400">
          <p>نسخه مدیریت موریکو ۲.۰</p>
          <p className="mt-0.5 truncate text-ink-600">{user.email}</p>
        </div>
      </aside>

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="flex h-16 items-center justify-between border-b border-ink-100 bg-white px-6">
          <div className="flex items-center gap-3">
            <span className="text-xs font-medium text-ink-700">
              مدیر ارشد: <strong className="font-bold text-ink-900">{user.name}</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* View Storefront Home button in Topbar */}
            <Link
              href="/"
              className="flex items-center gap-1.5 rounded-xl border border-ink-200 bg-powder-50 px-3 py-1.5 text-xs font-bold text-ink-800 transition hover:bg-powder-100"
              title="مشاهده صفحه اصلی فروشگاه"
            >
              <ExternalLink className="h-3.5 w-3.5 text-ink-600" />
              <span>مشاهده صفحه اصلی فروشگاه</span>
            </Link>

            <LogoutButton />
          </div>
        </header>

        <main className="p-6 flex-1">{children}</main>
      </div>
    </div>
  );
}
