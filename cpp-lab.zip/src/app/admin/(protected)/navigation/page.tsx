import { getSiteContent } from '@/lib/site-content';
import { getCurrentUser } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { NavigationManager } from '@/components/admin/NavigationManager';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminNavigationPage() {
  const user = await getCurrentUser();
  if (!user || user.role !== 'ADMIN') {
    redirect('/admin/login');
  }

  const content = await getSiteContent();
  const nav = content.navigation || [];

  return (
    <div className="space-y-6">
      <div className="border-b border-ink-100 pb-4">
        <h1 className="text-xl font-bold text-ink-900">منوی بالای سایت (هدر)</h1>
        <p className="mt-1 text-xs text-ink-500">
          پیوندهای ناوبری اصلی هدر فروشگاه را مدیریت، حذف و سازماندهی کنید. تغییرات بلافاصله در سایت اعمال خواهند شد.
        </p>
      </div>

      <NavigationManager initialNav={nav} />
    </div>
  );
}
