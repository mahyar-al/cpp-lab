import { prisma } from '@/lib/prisma';
import { toPersianDigits } from '@/lib/currency';
import { CustomizationInspector, type CustomizationRecord } from '@/components/admin/CustomizationInspector';

export default async function AdminCustomizationsPage() {
  const [customizations, designAssets, totalOrdersWithDesign, products] = await Promise.all([
    prisma.customization.findMany({
      orderBy: { createdAt: 'desc' },
      take: 60,
      include: {
        orderItem: {
          include: {
            order: {
              include: { user: true }
            }
          }
        },
        cartItem: {
          include: {
            cart: {
              include: { user: true }
            }
          }
        }
      }
    }),
    prisma.designAsset.findMany({
      orderBy: { createdAt: 'desc' },
      take: 60,
      include: {
        user: true
      }
    }),
    prisma.orderItem.count({
      where: { customizationId: { not: null } }
    }),
    prisma.product.findMany()
  ]);

  const productMap = new Map<string, any>((products as any[]).map((p: any) => [p.id, p]));

  const customizationRecords: CustomizationRecord[] = customizations.map((c: any) => {
    const prod: any = productMap.get(c.productId);
    let customerName = 'مشتری مهمان / ناشناس';
    let customerEmail: string | null = null;
    let customerPhone: string | null = null;
    let status: 'ordered' | 'in_cart' | 'draft' = 'draft';
    let orderNumber: string | null = null;
    let orderId: string | null = null;
    let orderStatus: string | null = null;

    if (c.orderItem?.order) {
      status = 'ordered';
      orderNumber = c.orderItem.order.orderNumber;
      orderId = c.orderItem.order.id;
      orderStatus = c.orderItem.order.status;
      customerName = c.orderItem.order.fullName || c.orderItem.order.user?.name || customerName;
      customerPhone = c.orderItem.order.mobile || c.orderItem.order.user?.phone;
      customerEmail = c.orderItem.order.email || c.orderItem.order.user?.email;
    } else if (c.cartItem?.cart?.user) {
      status = 'in_cart';
      customerName = c.cartItem.cart.user.name;
      customerEmail = c.cartItem.cart.user.email;
      customerPhone = c.cartItem.cart.user.phone;
    }

    const dateStr = new Date(c.createdAt).toLocaleDateString('fa-IR', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    return {
      id: c.id,
      productId: c.productId,
      productName: prod?.name || 'محصول سفارشی',
      productSlug: prod?.slug || '',
      previewUrl: c.previewUrl,
      viewsData: (typeof c.data === 'object' && c.data ? (c.data as any) : {}) || {},
      createdAt: dateStr,
      customerName,
      customerEmail,
      customerPhone,
      status,
      orderNumber,
      orderId,
      orderStatus
    };
  });

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-ink-100 pb-4">
        <div>
          <h1 className="text-xl font-bold text-ink-900">فرآیند طراحی و فایل‌های مشتریان 🎨</h1>
          <p className="mt-1 text-xs text-ink-500">
            مشاهده کامل طرح‌های ساخته‌شده توسط کاربران از لحظه آپلود عکس و انتخاب محصول تا ثبت سفارش نهایی.
          </p>
        </div>
      </div>

      {/* Top Stat Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="card p-5">
          <p className="text-xs font-semibold text-ink-500">کل طرح‌های ذخیره‌شده</p>
          <p className="mt-2 text-2xl font-black text-ink-900">{toPersianDigits(customizations.length)}</p>
          <p className="mt-1 text-[11px] text-ink-400">ساخته‌شده در استودیو آنلاین</p>
        </div>
        <div className="card p-5">
          <p className="text-xs font-semibold text-ink-500">طرح‌های تبدیل‌شده به سفارش چاپ</p>
          <p className="mt-2 text-2xl font-black text-emerald-600">{toPersianDigits(totalOrdersWithDesign)}</p>
          <p className="mt-1 text-[11px] text-emerald-700">دارای فاکتور خرید معتبر</p>
        </div>
        <div className="card p-5">
          <p className="text-xs font-semibold text-ink-500">فایل‌های آپلودشده کاربران</p>
          <p className="mt-2 text-2xl font-black text-powder-900">{toPersianDigits(designAssets.length)}</p>
          <p className="mt-1 text-[11px] text-powder-700">تصاویر، لوگوها و کات‌اوت‌ها</p>
        </div>
      </div>

      {/* Section 1: Customized Products & Layers Inspector */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-ink-900">طرح‌های موکاپ و شخصی‌سازی‌شده</h2>
          <span className="text-xs text-ink-500">
            {toPersianDigits(customizationRecords.length)} طرح اخیر
          </span>
        </div>

        <CustomizationInspector items={customizationRecords} />
      </div>

      {/* Section 2: Uploaded Design Assets Gallery */}
      <div className="card p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-ink-100 pb-3">
          <div>
            <h2 className="text-base font-bold text-ink-900">گالری فایل‌ها و تصاویر آپلودشده توسط کاربران</h2>
            <p className="text-xs text-ink-500 mt-0.5">
              فایل‌های خام، لوگوها و تصاویری که مشتریان برای چاپ روی محصولات بارگذاری کرده‌اند.
            </p>
          </div>
          <span className="text-xs font-semibold text-ink-500">
            {toPersianDigits(designAssets.length)} فایل
          </span>
        </div>

        {designAssets.length === 0 ? (
          <p className="text-center py-8 text-xs text-ink-400">هنوز فایلی توسط کاربران آپلود نشده است.</p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 md:grid-cols-6">
            {designAssets.map((asset: any) => {
              const kb = Math.round(asset.sizeBytes / 1024);
              const dateStr = new Date(asset.createdAt).toLocaleDateString('fa-IR', {
                month: 'short',
                day: 'numeric'
              });

              return (
                <div
                  key={asset.id}
                  className="group relative flex flex-col justify-between overflow-hidden rounded-xl border border-ink-100 bg-powder-50/50 p-2.5 transition hover:border-ink-300 hover:bg-white hover:shadow-xs"
                >
                  <div className="relative aspect-square w-full rounded-lg bg-white overflow-hidden flex items-center justify-center border border-ink-50">
                    <img
                      src={asset.url}
                      alt="asset"
                      className="h-full w-full object-contain p-1 transition group-hover:scale-105"
                    />
                    {asset.isRemovedBg && (
                      <span className="absolute top-1 right-1 rounded bg-black/75 px-1.5 py-0.5 text-[9px] font-bold text-white">
                        بدون پس‌زمینه
                      </span>
                    )}
                  </div>

                  <div className="mt-2 space-y-1 text-[11px]">
                    <p className="font-semibold text-ink-800 line-clamp-1">
                      {asset.user?.name || 'مشتری'}
                    </p>
                    <p className="text-[10px] text-ink-400 flex items-center justify-between" dir="ltr">
                      <span>{asset.width}×{asset.height}</span>
                      <span>{toPersianDigits(kb)} KB</span>
                    </p>
                    <div className="pt-1 flex items-center justify-between border-t border-ink-100/60">
                      <span className="text-[10px] text-ink-400">{dateStr}</span>
                      <a
                        href={asset.url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[10px] font-bold text-powder-900 hover:underline"
                      >
                        دانلود ↗
                      </a>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
