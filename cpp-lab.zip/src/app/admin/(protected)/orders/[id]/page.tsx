import { notFound, redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { OrderDetailClient } from './OrderDetailClient';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function OrderDetailPage({ params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user || user.role !== 'ADMIN') {
    redirect('/admin/login');
  }

  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: {
      items: {
        include: {
          product: true,
          customization: true
        }
      },
      user: true,
      payments: true
    }
  });

  if (!order) {
    notFound();
  }

  return <OrderDetailClient initialOrder={order} />;
}
