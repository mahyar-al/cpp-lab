'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowRight,
  Trash2,
  Package,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CreditCard,
  Printer,
  ExternalLink,
  CheckCircle2,
  Clock,
  Truck,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { formatToman, toPersianDigits } from '@/lib/currency';
import { clientFetch } from '@/lib/client-fetch';

const STATUS_OPTIONS = [
  { value: 'PENDING_PAYMENT', label: 'در انتظار پرداخت', color: 'bg-amber-100 text-amber-800' },
  { value: 'PAID', label: 'پرداخت شده (تایید شده)', color: 'bg-emerald-100 text-emerald-800' },
  { value: 'PROCESSING', label: 'در حال آماده‌سازی و برش', color: 'bg-blue-100 text-blue-800' },
  { value: 'PRINTING', label: 'در حال چاپ اختصاصی', color: 'bg-purple-100 text-purple-800' },
  { value: 'SHIPPED', label: 'تحویل پست / ارسال شده', color: 'bg-cyan-100 text-cyan-800' },
  { value: 'DELIVERED', label: 'تحویل داده شده به مشتری', color: 'bg-green-100 text-green-800' },
  { value: 'CANCELED', label: 'لغو شده', color: 'bg-red-100 text-red-800' }
];

export function OrderDetailClient({ initialOrder }: { initialOrder: any }) {
  const router = useRouter();
  const [order, setOrder] = useState(initialOrder);
  const [currentStatus, setCurrentStatus] = useState(order.status);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  async function handleStatusChange(newStatus: string) {
    if (newStatus === currentStatus) return;
    setUpdatingStatus(true);
    setStatusMessage(null);

    try {
      const res = await clientFetch(`/api/admin/orders/${order.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });

      if (res.ok) {
        setCurrentStatus(newStatus);
        setStatusMessage('وضعیت سفارش با موفقیت بروزرسانی شد.');
        setTimeout(() => setStatusMessage(null), 3000);
      } else {
        alert('خطا در تغییر وضعیت سفارش');
      }
    } catch {
      alert('خطای شبکه در بروزرسانی وضعیت');
    } finally {
      setUpdatingStatus(false);
    }
  }

  async function handleDeleteOrder() {
    setDeleting(true);
    try {
      const res = await clientFetch(`/api/admin/orders/${order.id}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        alert('سفارش موردنظر با موفقیت حذف شد.');
        router.push('/admin/orders');
        router.refresh();
      } else {
        const data = await res.json().catch(() => ({}));
        alert(data.error || 'خطا در حذف سفارش');
        setDeleting(false);
        setDeleteConfirmOpen(false);
      }
    } catch {
      alert('خطای ارتباط با سرور در حذف سفارش');
      setDeleting(false);
      setDeleteConfirmOpen(false);
    }
  }

  const activeStatusObj = STATUS_OPTIONS.find((s) => s.value === currentStatus) || {
    value: currentStatus,
    label: currentStatus,
    color: 'bg-gray-100 text-gray-800'
  };

  const createdDateFormatted = new Date(order.createdAt).toLocaleDateString('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className="space-y-6">
      {/* Top Navigation & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-ink-100 pb-4">
        <div className="flex items-center gap-3">
          <Link
            href="/admin/orders"
            className="flex items-center gap-1.5 rounded-xl border border-ink-200 bg-white px-3 py-1.5 text-xs font-bold text-ink-700 hover:bg-powder-100 transition"
          >
            <ArrowRight className="h-4 w-4" />
            <span>بازگشت به سفارش‌ها</span>
          </Link>
          <div>
            <h1 className="text-lg font-bold text-ink-900">
              سفارش شماره {toPersianDigits(order.orderNumber)}
            </h1>
            <p className="text-xs text-ink-400">ثبت در {createdDateFormatted}</p>
          </div>
        </div>

        {/* Delete & Status Actions */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Status Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-ink-500">وضعیت سفارش:</span>
            <select
              value={currentStatus}
              onChange={(e) => handleStatusChange(e.target.value)}
              disabled={updatingStatus}
              className="rounded-xl border border-ink-200 bg-white px-3 py-1.5 text-xs font-bold text-ink-800 shadow-xs focus:border-ink-900 focus:outline-none"
            >
              {STATUS_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {/* Delete Button */}
          <button
            type="button"
            onClick={() => setDeleteConfirmOpen(true)}
            className="flex items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-bold text-red-600 hover:bg-red-100 transition"
          >
            <Trash2 className="h-4 w-4" />
            <span>حذف سفارش</span>
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className="flex items-center gap-2 rounded-2xl bg-emerald-50 p-3 text-xs font-bold text-emerald-800 border border-emerald-100 animate-in fade-in">
          <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Main Grid: Customer info + Order details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Items & Customization */}
        <div className="lg:col-span-2 space-y-6">
          <div className="card p-6">
            <h2 className="text-sm font-bold text-ink-900 mb-4 flex items-center gap-2">
              <Package className="h-4 w-4 text-ink-600" />
              <span>اقلام سفارش داده شده ({order.items.length} قلم)</span>
            </h2>

            <div className="divide-y divide-ink-100">
              {order.items.map((item: any) => {
                const customization = item.customization;
                const hasDesign = !!customization;

                return (
                  <div key={item.id} className="py-4 first:pt-0 last:pb-0">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      {/* Product Preview */}
                      <div className="flex items-start gap-4">
                        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl border border-ink-100 bg-powder-50 flex items-center justify-center">
                          {customization?.previewUrl ? (
                            <img
                              src={customization.previewUrl}
                              alt={item.product?.name || 'محصول سفارشی'}
                              className="h-full w-full object-contain p-1"
                            />
                          ) : (
                            <Package className="h-8 w-8 text-ink-300" />
                          )}
                        </div>

                        <div>
                          <p className="font-bold text-sm text-ink-900">
                            {item.product?.name || 'محصول اختصاصی'}
                          </p>
                          <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-ink-500">
                            {item.size && (
                              <span>
                                سایز: <strong className="text-ink-800 font-mono">{item.size}</strong>
                              </span>
                            )}
                            {item.color && (
                              <span>
                                رنگ: <strong className="text-ink-800">{item.color}</strong>
                              </span>
                            )}
                            <span>
                              تعداد: <strong className="text-ink-800">{toPersianDigits(item.quantity)} عدد</strong>
                            </span>
                          </div>

                          <p className="mt-1.5 text-xs font-bold text-ink-900">
                            قیمت واحد: {formatToman(item.unitPrice)}
                          </p>
                        </div>
                      </div>

                      {/* Line Total */}
                      <div className="text-left sm:text-right">
                        <span className="text-[11px] text-ink-400 block">مبلغ کل این قلم:</span>
                        <span className="font-serif text-sm font-bold text-ink-900">
                          {formatToman(item.totalPrice)}
                        </span>
                      </div>
                    </div>

                    {/* Custom Design Assets & Print Details */}
                    {hasDesign && (
                      <div className="mt-3 rounded-2xl bg-powder-50 p-3.5 border border-ink-100/70">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <Printer className="h-4 w-4 text-purple-600 shrink-0" />
                            <span className="text-xs font-bold text-purple-900">
                              طراحی اختصاصی کاربر (فایل چاپ آماده):
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            {customization.previewUrl && (
                              <a
                                href={customization.previewUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center gap-1 rounded-lg bg-white px-2.5 py-1 text-[11px] font-bold text-ink-800 border border-ink-200 hover:bg-powder-100 transition"
                              >
                                <ExternalLink className="h-3 w-3" />
                                <span>مشاهده ماک‌آپ بزرگ</span>
                              </a>
                            )}
                            <Link
                              href="/admin/customizations"
                              className="rounded-lg bg-purple-100 px-2.5 py-1 text-[11px] font-bold text-purple-800 hover:bg-purple-200 transition"
                            >
                              بازرسی کامل طرح در استودیو 🎨
                            </Link>
                          </div>
                        </div>

                        {/* View Objects breakdown */}
                        {customization.data && typeof customization.data === 'object' && (
                          <div className="mt-2 text-[11px] text-ink-500">
                            زاویه‌های طراحی‌شده:{' '}
                            <span className="font-bold text-ink-700">
                              {Object.keys(customization.data).join('، ')}
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Customer Details & Financials */}
        <div className="space-y-6">
          {/* Customer Info Card */}
          <div className="card p-6 space-y-4">
            <h2 className="text-sm font-bold text-ink-900 border-b border-ink-100 pb-3 flex items-center gap-2">
              <User className="h-4 w-4 text-ink-600" />
              <span>مشخصات گیرنده و تحویل</span>
            </h2>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-ink-400 block text-[11px]">نام کامل تحویل‌گیرنده:</span>
                <span className="font-bold text-ink-900 text-sm">{order.fullName}</span>
              </div>

              <div>
                <span className="text-ink-400 block text-[11px]">شماره تماس / موبایل:</span>
                <span className="font-bold text-ink-900 font-mono" dir="ltr">
                  {order.mobile}
                </span>
              </div>

              {order.email && (
                <div>
                  <span className="text-ink-400 block text-[11px]">پست الکترونیکی:</span>
                  <span className="font-medium text-ink-800 font-mono" dir="ltr">
                    {order.email}
                  </span>
                </div>
              )}

              <div>
                <span className="text-ink-400 block text-[11px]">آدرس کامل پستی:</span>
                <p className="mt-0.5 font-medium text-ink-800 leading-relaxed bg-powder-50 p-2.5 rounded-xl border border-ink-100">
                  {order.city} - {order.address}
                </p>
              </div>

              {order.postalCode && (
                <div>
                  <span className="text-ink-400 block text-[11px]">کد پستی ۱۰ رقمی:</span>
                  <span className="font-bold text-ink-900 font-mono">{order.postalCode}</span>
                </div>
              )}

              {order.trackingCode && (
                <div className="rounded-xl bg-cyan-50 p-3 border border-cyan-100 text-cyan-900">
                  <span className="text-[11px] block font-semibold">کد رهگیری پستی:</span>
                  <span className="font-bold font-mono text-sm">{order.trackingCode}</span>
                </div>
              )}
            </div>
          </div>

          {/* Financial Breakdown Card */}
          <div className="card p-6 space-y-4">
            <h2 className="text-sm font-bold text-ink-900 border-b border-ink-100 pb-3 flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-ink-600" />
              <span>صورت‌حساب و وضعیت پرداخت</span>
            </h2>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between text-ink-600">
                <span>جمع اقلام:</span>
                <span className="font-medium">{formatToman(order.subtotal || order.totalAmount)}</span>
              </div>

              {order.shippingFee > 0 && (
                <div className="flex justify-between text-ink-600">
                  <span>هزینه بسته‌بندی و ارسال:</span>
                  <span className="font-medium">{formatToman(order.shippingFee)}</span>
                </div>
              )}

              {order.discountAmount > 0 && (
                <div className="flex justify-between text-red-600">
                  <span>تخفیف اعمال‌شده ({order.discountCode || 'کد'}):</span>
                  <span className="font-medium">- {formatToman(order.discountAmount)}</span>
                </div>
              )}

              <div className="border-t border-ink-100 pt-3 flex justify-between items-center text-sm font-bold text-ink-900">
                <span>مبلغ نهایی پرداخت‌شده:</span>
                <span className="font-serif text-base text-primary-700">
                  {formatToman(order.totalAmount)}
                </span>
              </div>
            </div>

            <div className="mt-4 rounded-xl p-3 bg-powder-50 border border-ink-100">
              <span className="text-[11px] text-ink-400 block">وضعیت فعلی:</span>
              <span className={`inline-block mt-1 px-3 py-1 rounded-lg text-xs font-bold ${activeStatusObj.color}`}>
                {activeStatusObj.label}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl border border-red-100">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-red-100">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-ink-900">حذف همیشگی سفارش</h3>
            </div>

            <p className="text-xs text-ink-600 leading-relaxed mb-6">
              آیا از حذف سفارش شماره{' '}
              <strong className="text-ink-900 font-bold">{toPersianDigits(order.orderNumber)}</strong> مربوط
              به «{order.fullName}» اطمینان دارید؟ تمام اقلام و سوابق این سفارش پاک خواهد شد و این عملیات
              غیرقابل بازگشت است.
            </p>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteConfirmOpen(false)}
                disabled={deleting}
                className="rounded-xl border border-ink-200 px-4 py-2 text-xs font-semibold text-ink-700 hover:bg-powder-100 transition"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleDeleteOrder}
                disabled={deleting}
                className="rounded-xl bg-red-600 px-5 py-2 text-xs font-bold text-white hover:bg-red-700 transition"
              >
                {deleting ? 'در حال حذف...' : 'بله، حذف قطعی'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
