import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { OrdersListManager } from '@/components/admin/OrdersListManager';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminOrdersPage() {
  const user = await getCurrentUser();
  if (!user || user.role !== 'ADMIN') {
    redirect('/admin/login');
  }

  const orders = await prisma.order.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      items: {
        include: {
          product: true,
          customization: true
        }
      }
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-ink-100 pb-4">
        <div>
          <h1 className="text-xl font-bold text-ink-900">مدیریت سفارش‌ها</h1>
          <p className="mt-1 text-xs text-ink-500">
            بررسی و نظارت بر سفارش‌های مشتریان، جزئیات طراحی، تغییر وضعیت فرآیند چاپ و ارسال، و حذف سفارش‌ها.
          </p>
        </div>
      </div>

      <OrdersListManager initialOrders={orders} />
    </div>
  );
}
