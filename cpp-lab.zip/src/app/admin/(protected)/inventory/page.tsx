import { prisma } from '@/lib/prisma';
import { toPersianDigits, formatPriceNumber } from '@/lib/currency';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function AdminInventoryPage() {
  const products = await prisma.product.findMany({
    where: { isArchived: false },
    orderBy: { createdAt: 'desc' },
    include: { inventory: true, category: true }
  });

  return (
    <div className="space-y-6">
      <div className="border-b border-ink-100 pb-4">
        <h1 className="text-xl font-bold text-ink-900">مدیریت موجودی انبار</h1>
        <p className="mt-1 text-xs text-ink-500">
          وضعیت موجودی فیزیکی محصولات فروشگاه را بررسی و نظارت کنید.
        </p>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-right text-xs">
          <thead className="bg-powder-50/70 border-b border-ink-100 font-semibold text-ink-700">
            <tr>
              <th className="p-3.5">نام محصول</th>
              <th className="p-3.5">دسته‌بندی</th>
              <th className="p-3.5">قیمت پایه</th>
              <th className="p-3.5">موجودی انبار</th>
              <th className="p-3.5">وضعیت</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-50">
            {products.map((p) => {
              const stock = p.inventory?.stock ?? 0;
              const isAvailable = p.isAvailable && stock > 0;
              return (
                <tr key={p.id} className="hover:bg-powder-50/40">
                  <td className="p-3.5 font-medium text-ink-900">{p.name}</td>
                  <td className="p-3.5 text-ink-600">{p.category?.name || '—'}</td>
                  <td className="p-3.5 font-mono">{formatPriceNumber(p.basePrice)} تومان</td>
                  <td className="p-3.5 font-mono font-bold">
                    {toPersianDigits(stock)} عدد
                  </td>
                  <td className="p-3.5">
                    <span
                      className={`badge ${
                        isAvailable ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                      }`}
                    >
                      {isAvailable ? 'موجود' : 'اتمام موجودی'}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
