'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { MoricoLogo } from '@/components/MoricoLogo';
import { clientFetch } from '@/lib/client-fetch';

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) return;
    setLoading(true);
    setError(null);

    try {
      const res = await clientFetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password })
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'ایمیل یا کلمه عبور نادرست است.');
        return;
      }

      if (data.user?.role !== 'ADMIN') {
        setError('دسترسی به این بخش صرفاً مخصوص مدیریت است.');
        return;
      }

      if (data.token && typeof window !== 'undefined') {
        localStorage.setItem('morico_token', data.token);
        document.cookie = `morico_session=${data.token}; path=/; max-age=2592000; SameSite=Lax`;
      }

      window.location.href = '/admin';
    } catch {
      setError('خطای شبکه در برقراری ارتباط');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-powder-50 px-4 py-12">
      <div className="w-full max-w-sm rounded-3xl border border-ink-100 bg-white p-8 shadow-card sm:p-10">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <MoricoLogo className="h-10 w-10" />
          </div>
          <h1 className="font-serif text-lg font-bold tracking-widest text-ink-900">
            MORICO
          </h1>
          <p className="mt-1 text-xs text-ink-400">
            درگاه ورود مدیریت
          </p>
        </div>

        {error && (
          <div className="mt-6 rounded-xl bg-red-50 p-3 text-center text-xs font-semibold text-red-600">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="mt-6 space-y-4">
          <div>
            <label className="label">پست الکترونیکی</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@morico.style"
              required
              dir="ltr"
              autoComplete="username"
              className="input text-xs"
            />
          </div>

          <div>
            <label className="label">کلمه عبور</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              dir="ltr"
              autoComplete="current-password"
              className="input text-xs"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full py-3 text-xs font-bold"
          >
            {loading ? 'در حال بررسی...' : 'ورود به سامانه'}
          </button>
        </form>
      </div>
    </div>
  );
}
