'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ArrowRight,
  ShieldCheck,
  CreditCard,
  Truck,
  CheckCircle2,
  Package,
  Sparkles,
  Ticket
} from 'lucide-react';
import { formatToman, formatPriceNumber, toPersianDigits } from '@/lib/currency';
import { clientFetch } from '@/lib/client-fetch';

export default function CheckoutPage() {
  const router = useRouter();
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [loadingCart, setLoadingCart] = useState(true);

  // Form Fields
  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [province, setProvince] = useState('تهران');
  const [city, setCity] = useState('تهران');
  const [address, setAddress] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [notes, setNotes] = useState('');
  const [discountCode, setDiscountCode] = useState('');
  const [discountAmount, setDiscountAmount] = useState(0);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [completedOrder, setCompletedOrder] = useState<any | null>(null);

  useEffect(() => {
    // 1. Fetch user if logged in to pre-fill
    clientFetch('/api/auth/me')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.user) {
          if (data.user.name) setFullName(data.user.name);
          if (data.user.email) setEmail(data.user.email);
        }
      })
      .catch(() => {});

    // 2. Fetch cart items
    clientFetch('/api/cart')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && Array.isArray(data.items)) {
          setCartItems(data.items);
        }
      })
      .catch(() => {})
      .finally(() => setLoadingCart(false));
  }, []);

  const subtotal = cartItems.reduce(
    (sum, item) => sum + (item.product?.unitPrice || item.product?.basePrice || 0) * (item.quantity || 1),
    0
  );
  const shippingFee = subtotal >= 500000 ? 0 : 39000;
  const totalAmount = Math.max(0, subtotal + shippingFee - discountAmount);

  async function handleApplyDiscount(e: React.FormEvent) {
    e.preventDefault();
    if (!discountCode.trim()) return;
    try {
      const res = await clientFetch('/api/checkout/discount', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: discountCode.trim(), subtotal })
      });
      const data = await res.json();
      if (res.ok && data.valid) {
        setDiscountAmount(data.discountAmount || 0);
        alert('کد تخفیف با موفقیت اعمال گردید.');
      } else {
        alert(data.error || 'کد تخفیف نامعتبر یا منقضی شده است.');
      }
    } catch {
      alert('خطا در بررسی کد تخفیف');
    }
  }

  async function handleSubmitOrder(e: React.FormEvent) {
    e.preventDefault();
    if (!fullName.trim() || !mobile.trim() || !address.trim() || !postalCode.trim()) {
      setError('لطفاً تمامی فیلدهای الزامی را پر نمایید.');
      return;
    }
    setSubmitting(true);
    setError(null);

    try {
      const res = await clientFetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: fullName.trim(),
          mobile: mobile.trim(),
          email: email.trim() || undefined,
          province: province.trim(),
          city: city.trim(),
          address: address.trim(),
          postalCode: postalCode.trim(),
          notes: notes.trim() || undefined,
          discountCode: discountCode.trim() || undefined
        })
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'خطا در ثبت نهایی سفارش.');
        setSubmitting(false);
        return;
      }

      if (data.paymentUrl) {
        window.location.href = data.paymentUrl;
        return;
      }

      // Order completed successfully in simulated/mock payment
      setCompletedOrder(data);
    } catch (err: any) {
      setError('خطای شبکه در ارتباط با سرور.');
    } finally {
      setSubmitting(false);
    }
  }

  // If order was placed successfully
  if (completedOrder) {
    return (
      <div className="container-morico py-12 max-w-xl mx-auto">
        <div className="card p-8 sm:p-10 text-center space-y-6 shadow-card border-emerald-100">
          <div className="h-16 w-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-xs">
            <CheckCircle2 className="h-10 w-10" />
          </div>

          <div className="space-y-2">
            <h1 className="text-xl font-bold text-ink-900">سفارش شما با موفقیت ثبت و تایید شد!</h1>
            <p className="text-xs text-ink-500">
              سفارش شما در فرآیند آماده‌سازی و چاپ قرار گرفت و به زودی به آدرس پستی ارسال خواهد شد.
            </p>
          </div>

          <div className="rounded-2xl bg-powder-50 p-4 border border-ink-100 text-xs space-y-2 text-right">
            <div className="flex justify-between items-center border-b border-ink-100/60 pb-2">
              <span className="text-ink-500">شماره سفارش:</span>
              <span className="font-bold text-ink-900 font-mono text-sm">
                {toPersianDigits(completedOrder.orderNumber)}
              </span>
            </div>
            <div className="flex justify-between items-center border-b border-ink-100/60 pb-2">
              <span className="text-ink-500">تحویل‌گیرنده:</span>
              <span className="font-bold text-ink-900">{fullName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-ink-500">وضعیت پرداخت:</span>
              <span className="font-bold text-emerald-700">پرداخت شده و تایید گردیده</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <Link
              href="/orders"
              className="btn-primary flex-1 !py-3 text-center text-xs font-bold shadow-soft"
            >
              پیگیری سفارش‌های من
            </Link>
            <Link
              href="/shop"
              className="btn-outline flex-1 !py-3 text-center text-xs font-bold"
            >
              ادامه خرید از فروشگاه
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-morico py-8 sm:py-12">
      <div className="mb-6 flex items-center justify-between border-b border-ink-100 pb-4">
        <div>
          <h1 className="text-xl font-bold text-ink-900">تکمیل سفارش و پرداخت</h1>
          <p className="mt-1 text-xs text-ink-500">
            اطلاعات گیرنده و آدرس پستی خود را با دقت وارد فرمایید.
          </p>
        </div>

        <Link
          href="/cart"
          className="flex items-center gap-1.5 text-xs font-bold text-ink-600 hover:text-ink-900 transition"
        >
          <ArrowRight className="h-4 w-4" />
          <span>بازگشت به سبد خرید</span>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Form Col */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmitOrder} className="card p-6 sm:p-8 space-y-5">
            <h2 className="text-sm font-bold text-ink-900 border-b border-ink-50 pb-3 flex items-center gap-2">
              <Truck className="h-4 w-4 text-ink-700" />
              <span>مشخصات گیرنده و مقصد ارسال</span>
            </h2>

            {error && (
              <div className="rounded-xl bg-red-50 p-3 text-xs font-bold text-red-600 border border-red-100">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="label">نام و نام خانوادگی تحویل‌گیرنده *</label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="علی رضایی"
                  required
                  className="input text-xs"
                />
              </div>

              <div>
                <label className="label">شماره همراه (جهت هماهنگی ارسال) *</label>
                <input
                  type="tel"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                  required
                  dir="ltr"
                  className="input text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="label">استان *</label>
                <input
                  type="text"
                  value={province}
                  onChange={(e) => setProvince(e.target.value)}
                  placeholder="تهران"
                  required
                  className="input text-xs"
                />
              </div>

              <div>
                <label className="label">شهرستان / شهر *</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="تهران"
                  required
                  className="input text-xs"
                />
              </div>
            </div>

            <div>
              <label className="label">آدرس دقیق پستی (خیابان، کوچه، پلاک، واحد) *</label>
              <textarea
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="خیابان، کوچه، پلاک، زنگ یا واحد"
                required
                rows={2}
                className="input text-xs leading-relaxed"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="label">کد پستی ۱۰ رقمی *</label>
                <input
                  type="text"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  placeholder="۱۲۳۴۵۶۷۸۹۰"
                  required
                  dir="ltr"
                  className="input text-xs font-mono"
                />
              </div>

              <div>
                <label className="label">پست الکترونیکی (اختیاری برای ارسال فاکتور)</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  dir="ltr"
                  className="input text-xs"
                />
              </div>
            </div>

            <div>
              <label className="label">یادداشت سفارش (اختیاری)</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="توضیحات خاص برای چاپ، زمان تحویل یا بسته‌بندی کادو..."
                className="input text-xs"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={submitting || cartItems.length === 0}
                className="btn-primary w-full !py-3.5 text-center text-sm font-bold shadow-soft flex items-center justify-center gap-2"
              >
                <CreditCard className="h-4 w-4" />
                <span>{submitting ? 'در حال ثبت و نهایی‌سازی...' : 'پرداخت و ثبت نهایی سفارش'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Summary Col */}
        <div className="space-y-6">
          <div className="card p-6 space-y-4">
            <h3 className="text-sm font-bold text-ink-900 border-b border-ink-50 pb-3">خلاصه فاکتور خرید</h3>

            {/* Items review */}
            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {cartItems.map((item) => (
                <div key={item.id} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-ink-900">{item.product?.name}</span>
                    <span className="text-ink-400 font-mono">×{toPersianDigits(item.quantity)}</span>
                  </div>
                  <span className="font-mono text-ink-700">
                    {formatToman((item.product?.unitPrice || item.product?.basePrice || 0) * (item.quantity || 1))}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t border-ink-100 pt-3 space-y-2.5 text-xs text-ink-600">
              <div className="flex justify-between">
                <span>جمع اقلام:</span>
                <span className="font-mono font-bold text-ink-900">{formatToman(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>هزینه ارسال:</span>
                <span className="font-mono font-medium">
                  {shippingFee === 0 ? <strong className="text-emerald-700">رایگان</strong> : formatToman(shippingFee)}
                </span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-red-600 font-bold">
                  <span>تخفیف:</span>
                  <span className="font-mono">- {formatToman(discountAmount)}</span>
                </div>
              )}
            </div>

            <div className="border-t border-ink-100 pt-4 flex justify-between items-baseline text-sm font-bold text-ink-900">
              <span>مبلغ نهایی:</span>
              <span className="font-serif text-lg text-primary-700">
                {formatToman(totalAmount)}
              </span>
            </div>

            <div className="rounded-xl bg-powder-50 p-3 text-[11px] text-ink-500 space-y-1">
              <div className="flex items-center gap-1.5 text-ink-700 font-bold">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
                <span>ضمانت اصالت و کیفیت چاپ موریکو</span>
              </div>
              <p>تحویل سریع و امکان بازگشت وجه در صورت هرگونه نقص در چاپ یا پارچه.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
