import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    const order = await prisma.order.findUnique({
      where: { id: params.id },
      include: {
        items: {
          include: {
            product: true,
            customization: true
          }
        },
        user: true,
        payments: true
      }
    });

    if (!order) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ order });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در دریافت سفارش' }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    const body = await req.json();
    const { status } = body;

    const updated = await prisma.order.update({
      where: { id: params.id },
      data: {
        ...(status ? { status } : {}),
        updatedAt: new Date()
      }
    });

    return NextResponse.json({ order: updated, success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در بروزرسانی سفارش' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    // Delete associated order items first if needed
    try {
      await prisma.orderItem.deleteMany({
        where: { orderId: params.id }
      });
    } catch {
      // ignore if cascade
    }

    // Delete associated payments
    try {
      await prisma.payment.deleteMany({
        where: { orderId: params.id }
      });
    } catch {
      // ignore
    }

    // Delete order
    await prisma.order.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true, message: 'سفارش با موفقیت حذف گردید.' });
  } catch (err: any) {
    console.error('Delete order error:', err);
    return NextResponse.json({ error: err.message || 'خطا در حذف سفارش' }, { status: 500 });
  }
}
