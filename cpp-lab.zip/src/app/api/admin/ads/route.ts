import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const ads = await prisma.advertisement.findMany({
      orderBy: [{ placement: 'asc' }, { sortOrder: 'asc' }]
    });
    return NextResponse.json({ ads });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const ad = await prisma.advertisement.create({
      data: {
        title: body.title,
        description: body.description || '',
        imageUrl: body.imageUrl || null,
        linkUrl: body.linkUrl || null,
        placement: body.placement || 'home',
        isActive: body.isActive ?? true,
        sortOrder: 0
      }
    });
    return NextResponse.json(ad);
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در ثبت بنر' }, { status: 500 });
  }
}
