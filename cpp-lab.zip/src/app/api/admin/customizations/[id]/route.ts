import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    const customization = await prisma.customization.findUnique({
      where: { id: params.id }
    });

    if (!customization) {
      return NextResponse.json({ error: 'طرح یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ customization });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    // Unlink or clean up references if needed
    try {
      await prisma.orderItem.updateMany({
        where: { customizationId: params.id },
        data: { customizationId: null }
      });
    } catch {
      // ignore
    }

    try {
      await prisma.cartItem.updateMany({
        where: { customizationId: params.id },
        data: { customizationId: null }
      });
    } catch {
      // ignore
    }

    await prisma.customization.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true, message: 'طرح کاربر با موفقیت حذف شد.' });
  } catch (err: any) {
    console.error('Delete customization error:', err);
    return NextResponse.json({ error: err.message || 'خطا در حذف طرح' }, { status: 500 });
  }
}
