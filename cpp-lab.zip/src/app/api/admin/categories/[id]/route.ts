import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    const category = await prisma.category.findUnique({
      where: { id: params.id }
    });

    if (!category) {
      return NextResponse.json({ error: 'دسته‌بندی یافت نشد.' }, { status: 404 });
    }

    // Unlink products belonging to this category
    try {
      await prisma.product.updateMany({
        where: { categoryId: params.id },
        data: { categoryId: null }
      });
    } catch {
      // ignore
    }

    await prisma.category.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true, message: 'دسته‌بندی با موفقیت حذف شد.' });
  } catch (err: any) {
    console.error('Delete category error:', err);
    return NextResponse.json({ error: err.message || 'خطا در حذف دسته‌بندی' }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    const body = await req.json();
    const updated = await prisma.category.update({
      where: { id: params.id },
      data: body
    });

    return NextResponse.json(updated);
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در بروزرسانی دسته‌بندی' }, { status: 500 });
  }
}
