import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      orderBy: { sortOrder: 'asc' }
    });
    return NextResponse.json({ categories });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const { name, slug } = await req.json();
    if (!name || !slug) {
      return NextResponse.json({ error: 'نام و شناسه دسته الزامی است.' }, { status: 400 });
    }

    const created = await prisma.category.create({
      data: {
        name,
        slug: slug.toLowerCase().replace(/\s+/g, '-'),
        isActive: true,
        sortOrder: 10
      }
    });

    return NextResponse.json(created);
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در ثبت دسته' }, { status: 500 });
  }
}
