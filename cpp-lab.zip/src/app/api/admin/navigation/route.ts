import { NextResponse } from 'next/server';
import { getSiteContent, updateSiteContent, SiteNavItem } from '@/lib/site-content';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  try {
    const content = await getSiteContent();
    return NextResponse.json({ navigation: content.navigation || [] });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در دریافت منو' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    const { label, href, isHighlight } = await req.json();
    if (!label || !href) {
      return NextResponse.json({ error: 'عنوان و لینک الزامی هستند.' }, { status: 400 });
    }

    const content = await getSiteContent();
    const currentNav = content.navigation || [];

    const newItem: SiteNavItem = {
      id: `nav_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      label: label.trim(),
      href: href.trim(),
      isHighlight: !!isHighlight,
      isActive: true,
      sortOrder: currentNav.length
    };

    const updatedNav = [...currentNav, newItem];
    const updatedContent = await updateSiteContent({ navigation: updatedNav });

    return NextResponse.json({ item: newItem, navigation: updatedContent.navigation, success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در ثبت آیتم منو' }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    const url = new URL(req.url);
    const id = url.searchParams.get('id') || (await req.json().catch(() => ({}))).id;

    if (!id) {
      return NextResponse.json({ error: 'شناسه آیتم جهت حذف الزامی است.' }, { status: 400 });
    }

    const content = await getSiteContent();
    const currentNav = content.navigation || [];
    const filteredNav = currentNav.filter((it) => it.id !== id);

    const updatedContent = await updateSiteContent({ navigation: filteredNav });

    return NextResponse.json({ navigation: updatedContent.navigation, success: true, message: 'آیتم منو با موفقیت حذف شد.' });
  } catch (err: any) {
    console.error('Delete nav item error:', err);
    return NextResponse.json({ error: err.message || 'خطا در حذف آیتم منو' }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    const { id, isActive, label, href, isHighlight } = await req.json();
    if (!id) {
      return NextResponse.json({ error: 'شناسه آیتم الزامی است.' }, { status: 400 });
    }

    const content = await getSiteContent();
    const currentNav = content.navigation || [];
    const updatedNav = currentNav.map((it) => {
      if (it.id === id) {
        return {
          ...it,
          ...(isActive !== undefined ? { isActive } : {}),
          ...(label !== undefined ? { label } : {}),
          ...(href !== undefined ? { href } : {}),
          ...(isHighlight !== undefined ? { isHighlight } : {})
        };
      }
      return it;
    });

    const updatedContent = await updateSiteContent({ navigation: updatedNav });
    return NextResponse.json({ navigation: updatedContent.navigation, success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در بروزرسانی منو' }, { status: 500 });
  }
}
