import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const discounts = await prisma.discount.findMany({
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json({ discounts });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const { code, percent, maxUses } = await req.json();
    if (!code) {
      return NextResponse.json({ error: 'کد تخفیف الزامی است.' }, { status: 400 });
    }

    const discount = await prisma.discount.create({
      data: {
        code: code.toUpperCase().trim(),
        percent: Number(percent) || 10,
        maxUses: Number(maxUses) || 100,
        usesCount: 0,
        isActive: true
      }
    });

    return NextResponse.json(discount);
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در ثبت کد تخفیف' }, { status: 500 });
  }
}
