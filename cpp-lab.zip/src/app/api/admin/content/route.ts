import { NextResponse } from 'next/server';
import { getSiteContent, updateSiteContent } from '@/lib/site-content';

export async function GET() {
  try {
    const content = await getSiteContent();
    return NextResponse.json({ content });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در خواندن محتوا' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const content = await updateSiteContent(body.content || {});
    return NextResponse.json({ content, success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در ذخیره محتوا' }, { status: 500 });
  }
}
