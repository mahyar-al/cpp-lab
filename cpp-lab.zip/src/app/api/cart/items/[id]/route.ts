import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const { quantity } = await req.json();
    if (!quantity || quantity < 1) {
      return NextResponse.json({ error: 'تعداد نامعتبر است.' }, { status: 400 });
    }

    const updated = await prisma.cartItem.update({
      where: { id: params.id },
      data: { quantity: Number(quantity) }
    });

    return NextResponse.json({ success: true, item: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در بروزرسانی' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    await prisma.cartItem.delete({
      where: { id: params.id }
    });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در حذف' }, { status: 500 });
  }
}
