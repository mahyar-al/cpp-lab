import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { applyDiscount } from '@/lib/currency';

async function getOrCreateCart(userId: string) {
  let cart = await prisma.cart.findFirst({
    where: { userId },
    include: {
      items: {
        include: {
          product: { include: { images: true, views: true } },
          customization: true
        }
      }
    }
  });

  if (!cart) {
    cart = await prisma.cart.create({
      data: { userId }
    });
    cart.items = [];
  }

  return cart;
}

export async function GET() {
  try {
    const user = await getCurrentUser();
    const userId = user?.id || 'usr_customer_1'; // fallback to demo customer
    const cart = await getOrCreateCart(userId);

    const items = (cart.items || []).map((ci: any) => {
      const p = ci.product;
      const unitPrice = p ? applyDiscount(p.basePrice, p.discountPercent) : 0;
      const image = p?.images?.[0]?.url || p?.views?.[0]?.imageUrl || '/brand/morico-logo.jpg';

      return {
        id: ci.id,
        quantity: ci.quantity,
        product: p
          ? {
              id: p.id,
              name: p.name,
              slug: p.slug,
              image,
              unitPrice
            }
          : { id: ci.productId, name: 'محصول سفارشی', slug: '', image: null, unitPrice: 0 },
        customization: ci.customization
          ? {
              id: ci.customization.id,
              previewUrl: ci.customization.previewUrl || null
            }
          : null
      };
    });

    return NextResponse.json({ items });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در دریافت سبد' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    const userId = user?.id || 'usr_customer_1';
    const cart = await getOrCreateCart(userId);

    const body = await req.json();
    const { productId, quantity = 1, customizationId } = body;

    if (!productId) {
      return NextResponse.json({ error: 'شناسه محصول الزامی است.' }, { status: 400 });
    }

    const item = await prisma.cartItem.create({
      data: {
        cartId: cart.id,
        productId,
        quantity: Math.max(1, Number(quantity) || 1),
        customizationId: customizationId || null
      }
    });

    return NextResponse.json({ success: true, item });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در افزودن به سبد' }, { status: 500 });
  }
}
