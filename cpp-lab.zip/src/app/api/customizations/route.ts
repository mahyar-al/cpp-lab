import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    const userId = user?.id || 'usr_customer_1';

    const { productId, views, previewUrl } = await req.json();

    const customization = await prisma.customization.create({
      data: {
        userId,
        productId,
        canvasJson: JSON.stringify(views || {}),
        previewUrl: previewUrl || null
      }
    });

    return NextResponse.json({ id: customization.id, success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'خطا در ذخیره طرح' }, { status: 500 });
  }
}
