import { NextResponse } from 'next/server';
import { getSiteContent } from '@/lib/site-content';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET() {
  try {
    const content = await getSiteContent();
    const navigation = (content.navigation || []).filter((item) => item.isActive !== false);
    return NextResponse.json({ navigation });
  } catch (err: any) {
    return NextResponse.json({ navigation: [] }, { status: 500 });
  }
}
