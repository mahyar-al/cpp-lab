import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const { imageUrl } = body;

    // In preview without rembg server, fallback gracefully to original imageUrl
    return NextResponse.json({
      url: imageUrl || '/brand/morico-mark.jpg',
      processed: false,
      message: 'Background removal preview fallback'
    });
  } catch {
    return NextResponse.json({ error: 'خطا در پردازش تصویر' }, { status: 500 });
  }
}
