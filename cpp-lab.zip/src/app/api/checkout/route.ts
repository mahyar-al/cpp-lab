import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { withApiErrorHandling } from '@/lib/api-response';
import { checkoutSchema } from '@/lib/validation';
import { priceCartForUser } from '@/server/pricing';
import { getActivePaymentProvider, getActivePaymentProviderName, isPaymentGatewayConfigured } from '@/server/payments/registry';

function generateOrderNumber(): string {
  const stamp = Date.now().toString().slice(-6);
  const rand = Math.floor(Math.random() * 900 + 100);
  return `MRC-${stamp}${rand}`;
}

export const POST = withApiErrorHandling(async (req: Request) => {
  let user = await getCurrentUser();
  const body = await req.json();
  const data = checkoutSchema.parse(body);

  if (!user) {
    const cleanEmail = (data.email?.toLowerCase().trim()) || `${data.mobile}@guest.morico.style`;
    let existingUser = await prisma.user.findUnique({ where: { email: cleanEmail } });
    if (!existingUser) {
      existingUser = await prisma.user.create({
        data: {
          name: data.fullName,
          email: cleanEmail,
          phone: data.mobile,
          role: 'CUSTOMER',
          passwordHash: ''
        }
      });
    }
    user = existingUser;
  }

  // Calculate pricing
  const priced = await priceCartForUser(user.id, data.discountCode);

  const order = await prisma.order.create({
    data: {
      orderNumber: generateOrderNumber(),
      userId: user.id,
      status: 'PAID', // mark as PAID in testing/simulation
      fullName: data.fullName,
      mobile: data.mobile,
      email: data.email || null,
      province: data.province,
      city: data.city,
      address: data.address,
      postalCode: data.postalCode,
      notes: data.notes || null,
      subtotal: priced.subtotal,
      discountAmount: priced.discountAmount,
      discountCode: priced.appliedDiscountCode,
      shippingAmount: priced.shippingAmount,
      totalAmount: priced.totalAmount,
      items: {
        create: priced.items.map((item) => ({
          productId: item.productId,
          productNameSnapshot: item.name,
          unitPriceSnapshot: item.unitPrice,
          quantity: item.quantity,
          customizationId: item.customizationId ?? undefined
        }))
      }
    }
  });

  const providerName = getActivePaymentProviderName();
  const isConfigured = isPaymentGatewayConfigured();

  if (isConfigured) {
    const provider = getActivePaymentProvider();
    const callbackUrl = `${process.env.APP_URL ?? new URL(req.url).origin}/api/payment/${providerName}/callback`;
    const paymentRequest = await provider.requestPayment({
      amountToman: priced.totalAmount,
      description: `پرداخت سفارش ${order.orderNumber} - موریکو`,
      callbackUrl,
      orderId: order.id,
      mobile: data.mobile,
      email: data.email || undefined
    });

    if (paymentRequest.ok && paymentRequest.paymentUrl) {
      return NextResponse.json({
        success: true,
        orderId: order.id,
        orderNumber: order.orderNumber,
        paymentUrl: paymentRequest.paymentUrl
      });
    }
  }

  // Clear cart upon successful order creation
  try {
    const cart = await prisma.cart.findFirst({
      where: { userId: user.id }
    });
    if (cart) {
      await prisma.cartItem.deleteMany({
        where: { cartId: cart.id }
      });
    }
  } catch {
    // ignore
  }

  return NextResponse.json({
    success: true,
    orderId: order.id,
    orderNumber: order.orderNumber,
    status: 'PAID',
    message: 'سفارش شما با موفقیت ثبت و تایید گردید.'
  });
});
