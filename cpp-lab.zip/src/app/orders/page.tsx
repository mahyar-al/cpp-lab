import { prisma } from '@/lib/prisma';
import { toPersianDigits, formatPriceNumber } from '@/lib/currency';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata = {
  title: 'پیگیری سفارش | MORICO'
};

export default async function OrdersPage() {
  const orders = await prisma.order.findMany({
    orderBy: { createdAt: 'desc' },
    include: { items: true }
  });

  return (
    <div className="container-morico py-8 sm:py-12">
      <div className="mb-6 border-b border-ink-100 pb-4">
        <h1 className="text-2xl font-bold text-ink-900">سفارش‌های شما</h1>
        <p className="mt-1 text-xs text-ink-500">
          وضعیت سفارش‌ها و جزئیات بسته‌های ارسالی خود را در این بخش مشاهده کنید.
        </p>
      </div>

      <div className="space-y-4">
        {orders.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-ink-200 p-12 text-center">
            <span className="text-3xl">📦</span>
            <p className="mt-3 text-sm font-semibold text-ink-800">هنوز سفارشی ثبت نکرده‌اید.</p>
          </div>
        ) : (
          orders.map((o: any) => (
            <div key={o.id} className="card p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-50 pb-3 text-xs">
                <div>
                  <span className="font-semibold text-ink-900">شماره سفارش: </span>
                  <span className="font-mono font-bold">{o.orderNumber}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="badge bg-powder-200 text-ink-800">
                    {o.status === 'PENDING_PAYMENT' ? 'در انتظار پرداخت' : 'تکمیل‌شده'}
                  </span>
                  <span className="font-mono font-bold text-ink-900">
                    {formatPriceNumber(o.totalAmount)} تومان
                  </span>
                </div>
              </div>

              <div className="text-xs text-ink-600 space-y-1">
                <p>تحویل‌گیرنده: {o.fullName} ({o.mobile})</p>
                <p>آدرس: {o.province}، {o.city}، {o.address}</p>
              </div>

              {o.items && o.items.length > 0 && (
                <div className="rounded-xl bg-powder-50/60 p-3 text-xs">
                  <p className="font-bold text-ink-800 mb-2">اقلام سفارش:</p>
                  <ul className="space-y-1 text-ink-600">
                    {o.items.map((it: any) => (
                      <li key={it.id} className="flex justify-between">
                        <span>{it.productNameSnapshot} × {toPersianDigits(it.quantity)}</span>
                        <span className="font-mono">{formatPriceNumber(it.unitPriceSnapshot * it.quantity)} تومان</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
