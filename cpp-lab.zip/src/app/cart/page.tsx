import { CartView } from '@/components/CartView';

export const metadata = {
  title: 'سبد خرید | MORICO'
};

export default function CartPage() {
  return (
    <div className="container-morico py-8 sm:py-12">
      <div className="mb-6 border-b border-ink-100 pb-4">
        <h1 className="text-2xl font-bold text-ink-900">سبد خرید شما</h1>
        <p className="mt-1 text-xs text-ink-500">
          محصولات انتخابی و طرح‌های سفارشی خود را بازبینی و نهایی کنید.
        </p>
      </div>

      <CartView />
    </div>
  );
}
