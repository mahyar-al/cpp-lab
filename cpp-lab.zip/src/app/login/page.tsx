'use client';

import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
  User,
  Mail,
  Lock,
  Phone,
  LogIn,
  UserPlus,
  Eye,
  EyeOff,
  ArrowRight,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { MoricoLogo } from '@/components/MoricoLogo';
import { clientFetch } from '@/lib/client-fetch';

function AuthContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialMode = searchParams.get('mode') === 'register' ? 'register' : 'login';
  const callbackUrl = searchParams.get('callbackUrl') || '/';

  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register form state
  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPhone, setRegisterPhone] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!loginEmail || !loginPassword) return;
    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const res = await clientFetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail.trim(), password: loginPassword })
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'ایمیل یا کلمه عبور نادرست است.');
        return;
      }

      if (data.token && typeof window !== 'undefined') {
        localStorage.setItem('morico_token', data.token);
        document.cookie = `morico_session=${data.token}; path=/; max-age=2592000; SameSite=Lax`;
      }

      if (data.user?.role === 'ADMIN') {
        setSuccessMessage('خوش آمدید مدیر گرامی! در حال انتقال به پنل مدیریت...');
        setTimeout(() => {
          window.location.href = '/admin';
        }, 500);
      } else {
        setSuccessMessage('با موفقیت وارد شدید! در حال بازگشت به فروشگاه...');
        setTimeout(() => {
          window.location.href = callbackUrl || '/';
        }, 500);
      }
    } catch {
      setError('خطای شبکه در برقراری ارتباط');
    } finally {
      setLoading(false);
    }
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    if (!registerName || !registerEmail || !registerPassword) return;
    if (registerPassword.length < 6) {
      setError('رمز عبور باید حداقل ۶ نویسه (کاراکتر) باشد.');
      return;
    }
    setLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const res = await clientFetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: registerName.trim(),
          email: registerEmail.trim(),
          phone: registerPhone.trim() || undefined,
          password: registerPassword
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'خطا در ثبت‌نام کاربر.');
        return;
      }

      if (data.token && typeof window !== 'undefined') {
        localStorage.setItem('morico_token', data.token);
        document.cookie = `morico_session=${data.token}; path=/; max-age=2592000; SameSite=Lax`;
      }

      setSuccessMessage('حساب کاربری شما با موفقیت ساخته شد! در حال انتقال...');
      setTimeout(() => {
        window.location.href = callbackUrl || '/';
      }, 500);
    } catch {
      setError('خطای شبکه در برقراری ارتباط');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-[85vh] flex flex-col justify-center items-center py-12 px-4 sm:px-6">
      <div className="w-full max-w-md">
        {/* Back Link */}
        <div className="mb-6 flex justify-between items-center">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-ink-500 hover:text-ink-900 transition"
          >
            <ArrowRight className="h-3.5 w-3.5" />
            <span>بازگشت به فروشگاه موریکو</span>
          </Link>

          <span className="text-[11px] text-ink-400 flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-amber-500" />
            <span>پلتفرم طراحی و چاپ اختصاصی</span>
          </span>
        </div>

        {/* Card */}
        <div className="rounded-3xl border border-ink-100 bg-white p-6 sm:p-9 shadow-card">
          {/* Header */}
          <div className="text-center mb-6">
            <Link href="/" className="inline-flex justify-center mb-3">
              <MoricoLogo className="h-11 w-11" />
            </Link>
            <h1 className="font-serif text-xl font-bold tracking-widest text-ink-900">
              MORICO
            </h1>
            <p className="mt-1.5 text-xs text-ink-500">
              {mode === 'login'
                ? 'ورود به حساب کاربری مشتریان'
                : 'عضویت و ایجاد حساب کاربری جدید'}
            </p>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex rounded-2xl bg-powder-100/80 p-1 mb-6">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
                setSuccessMessage(null);
              }}
              className={`flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-bold transition ${
                mode === 'login'
                  ? 'bg-white text-ink-900 shadow-sm'
                  : 'text-ink-500 hover:text-ink-800'
              }`}
            >
              <LogIn className="h-4 w-4" />
              <span>ورود به حساب</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError(null);
                setSuccessMessage(null);
              }}
              className={`flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-bold transition ${
                mode === 'register'
                  ? 'bg-white text-ink-900 shadow-sm'
                  : 'text-ink-500 hover:text-ink-800'
              }`}
            >
              <UserPlus className="h-4 w-4" />
              <span>ثبت‌نام جدید</span>
            </button>
          </div>

          {/* Alerts */}
          {error && (
            <div className="mb-5 rounded-2xl bg-red-50 p-3.5 text-center text-xs font-semibold text-red-600 border border-red-100">
              {error}
            </div>
          )}

          {successMessage && (
            <div className="mb-5 flex items-center justify-center gap-2 rounded-2xl bg-emerald-50 p-3.5 text-center text-xs font-semibold text-emerald-700 border border-emerald-100">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          {mode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="label">پست الکترونیکی (ایمیل)</label>
                <div className="relative">
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="name@example.com"
                    required
                    dir="ltr"
                    autoComplete="username"
                    className="input pl-10 text-xs"
                  />
                  <Mail className="absolute left-3.5 top-3.5 h-4 w-4 text-ink-400" />
                </div>
              </div>

              <div>
                <label className="label">کلمه عبور</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    dir="ltr"
                    autoComplete="current-password"
                    className="input pl-20 text-xs"
                  />
                  <div className="absolute left-3.5 top-3.5 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-ink-400 hover:text-ink-700 transition"
                      title={showPassword ? 'مخفی کردن' : 'نمایش'}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                    <Lock className="h-4 w-4 text-ink-400" />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-3 text-xs font-bold mt-2 shadow-sm"
              >
                {loading ? 'در حال بررسی...' : 'ورود به حساب کاربری'}
              </button>

              <div className="pt-2 text-center text-xs text-ink-500">
                حساب کاربری ندارید؟{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setError(null);
                    setSuccessMessage(null);
                  }}
                  className="font-bold text-ink-900 underline hover:text-primary-700"
                >
                  ثبت‌نام رایگان در موریکو
                </button>
              </div>
            </form>
          ) : (
            /* REGISTER FORM */
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div>
                <label className="label">نام و نام خانوادگی</label>
                <div className="relative">
                  <input
                    type="text"
                    value={registerName}
                    onChange={(e) => setRegisterName(e.target.value)}
                    placeholder="مثال: علی رضایی"
                    required
                    autoComplete="name"
                    className="input pl-10 text-xs"
                  />
                  <User className="absolute left-3.5 top-3.5 h-4 w-4 text-ink-400" />
                </div>
              </div>

              <div>
                <label className="label">پست الکترونیکی (ایمیل)</label>
                <div className="relative">
                  <input
                    type="email"
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    placeholder="name@example.com"
                    required
                    dir="ltr"
                    autoComplete="email"
                    className="input pl-10 text-xs"
                  />
                  <Mail className="absolute left-3.5 top-3.5 h-4 w-4 text-ink-400" />
                </div>
              </div>

              <div>
                <label className="label">شماره موبایل (اختیاری برای هماهنگی ارسال)</label>
                <div className="relative">
                  <input
                    type="tel"
                    value={registerPhone}
                    onChange={(e) => setRegisterPhone(e.target.value)}
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    dir="ltr"
                    autoComplete="tel"
                    className="input pl-10 text-xs"
                  />
                  <Phone className="absolute left-3.5 top-3.5 h-4 w-4 text-ink-400" />
                </div>
              </div>

              <div>
                <label className="label">کلمه عبور (حداقل ۶ نویسه)</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    dir="ltr"
                    minLength={6}
                    autoComplete="new-password"
                    className="input pl-20 text-xs"
                  />
                  <div className="absolute left-3.5 top-3.5 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-ink-400 hover:text-ink-700 transition"
                      title={showPassword ? 'مخفی کردن' : 'نمایش'}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                    <Lock className="h-4 w-4 text-ink-400" />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-3 text-xs font-bold mt-2 shadow-sm"
              >
                {loading ? 'در حال ایجاد حساب...' : 'تکمیل ثبت‌نام و عضویت'}
              </button>

              <div className="pt-2 text-center text-xs text-ink-500">
                قبلاً عضو شده‌اید؟{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setError(null);
                    setSuccessMessage(null);
                  }}
                  className="font-bold text-ink-900 underline hover:text-primary-700"
                >
                  ورود به حساب کاربری
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-ink-900 border-t-transparent" />
        </div>
      }
    >
      <AuthContent />
    </Suspense>
  );
}
