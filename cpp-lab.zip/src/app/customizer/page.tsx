import { notFound } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { Customizer } from '@/components/Customizer/Customizer';
import { CANVAS_SIZE, ProductViewData } from '@/components/Customizer/types';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function CustomizerPage({
  searchParams
}: {
  searchParams: { productId?: string };
}) {
  let product = null;

  if (searchParams.productId) {
    product = await prisma.product.findUnique({
      where: { id: searchParams.productId },
      include: {
        views: { orderBy: { sortOrder: 'asc' }, include: { printableArea: true } }
      }
    });
  }

  if (!product) {
    // Pick the first customizable product
    product = await prisma.product.findFirst({
      where: { isArchived: false, customizationEnabled: true },
      include: {
        views: { orderBy: { sortOrder: 'asc' }, include: { printableArea: true } }
      }
    });
  }

  if (!product) {
    notFound();
  }

  const defaultArea = {
    x: 150,
    y: 150,
    width: 300,
    height: 300,
    minDesignWidth: 40,
    maxDesignWidth: 300,
    minDesignHeight: 40,
    maxDesignHeight: 300
  };

  const rawViews = product.views || [];
  const views: ProductViewData[] =
    rawViews.length > 0
      ? rawViews.map((v: any) => ({
          id: v.id,
          name: v.name || 'نمای اصلی',
          imageUrl: v.imageUrl || '/brand/morico-logo.jpg',
          printableArea: v.printableArea
            ? {
                x: v.printableArea.x,
                y: v.printableArea.y,
                width: v.printableArea.width,
                height: v.printableArea.height,
                minDesignWidth: v.printableArea.minDesignWidth || 40,
                maxDesignWidth: v.printableArea.maxDesignWidth || v.printableArea.width,
                minDesignHeight: v.printableArea.minDesignHeight || 40,
                maxDesignHeight: v.printableArea.maxDesignHeight || v.printableArea.height
              }
            : defaultArea
        }))
      : [
          {
            id: 'default_view',
            name: 'نمای روبرو',
            imageUrl: '/brand/morico-logo.jpg',
            printableArea: defaultArea
          }
        ];

  return <Customizer productId={product.id} productName={product.name} views={views} />;
}
