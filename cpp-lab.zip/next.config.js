/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: 'standalone',
  eslint: {
    ignoreDuringBuilds: true
  },
  images: {
    remotePatterns: [
      { protocol: 'http', hostname: 'localhost' },
      { protocol: 'https', hostname: '**' }
    ]
  },
  experimental: {
    // Keep the dev build light for low-RAM machines
    workerThreads: false,
    cpus: 1
  }
};

module.exports = nextConfig;
