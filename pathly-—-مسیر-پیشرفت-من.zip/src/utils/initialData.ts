import {
  UserProfile,
  SchoolSubject,
  SubjectGrade,
  WeeklyTimetableCell,
  SchoolHomework,
  SchoolExamItem,
  DaySpecificData,
  StudySession,
  Skill,
  Project,
  Competition,
  Goal,
  WeeklyReview,
  CalendarEvent,
  Note,
  ActivityLogItem,
  ReminderNotification,
} from '../types';

export const initialProfile: UserProfile = {
  name: 'کاربر Pathly',
  gradeOrField: 'دانش‌آموز / دانش‌پژوه',
  avatarSeed: 'pathly-user',
  theme: 'light',
  enableBrowserNotifications: true,
  bellTimes: [
    { period: 1, title: 'زنگ اول', startTime: '07:30', endTime: '09:00' },
    { period: 2, title: 'زنگ دوم', startTime: '09:15', endTime: '10:45' },
    { period: 3, title: 'زنگ سوم', startTime: '11:00', endTime: '12:30' },
    { period: 4, title: 'زنگ چهارم', startTime: '13:00', endTime: '14:15' },
    { period: 5, title: 'زنگ پنجم', startTime: '14:30', endTime: '15:30' },
  ],
};

// Clean empty collections - user records their own real data
export const initialSubjects: SchoolSubject[] = [];

export const initialGrades: SubjectGrade[] = [];

// Clean 25 cells for 5 days (شنبه تا چهارشنبه) and 5 periods (زنگ ۱ تا ۵)
export const initialTimetable: WeeklyTimetableCell[] = [];
export const initialWeeklyCells: WeeklyTimetableCell[] = [];

export const initialHomework: SchoolHomework[] = [];
export const initialHomeworks: SchoolHomework[] = [];

export const initialExams: SchoolExamItem[] = [];

// Empty initial day-specific data for 5 days of school (0: شنبه, 1: یکشنبه, 2: دوشنبه, 3: سه‌شنبه, 4: چهارشنبه)
export const initialDaySpecificData: DaySpecificData[] = [
  { dayIndex: 0, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
  { dayIndex: 1, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
  { dayIndex: 2, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
  { dayIndex: 3, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
  { dayIndex: 4, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
];

export const initialDayDataMap: Record<number, DaySpecificData> = {
  0: { dayIndex: 0, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
  1: { dayIndex: 1, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
  2: { dayIndex: 2, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
  3: { dayIndex: 3, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
  4: { dayIndex: 4, overallRating: null, preSchoolTasks: [], postSchoolTasks: [], notes: '', reflectionReport: '' },
};

export const initialStudySessions: StudySession[] = [];

export const initialSkills: Skill[] = [];

export const initialProjects: Project[] = [];

export const initialCompetitions: Competition[] = [];

export const initialGoals: Goal[] = [];

export const initialWeeklyReviews: WeeklyReview[] = [];

export const initialCalendarEvents: CalendarEvent[] = [];

export const initialNotes: Note[] = [];

export const initialActivityLogs: ActivityLogItem[] = [];

export const initialNotifications: ReminderNotification[] = [];
