export type Priority = 'low' | 'medium' | 'high';
export type TaskStatus = 'todo' | 'in_progress' | 'completed' | 'overdue';
export type SectionType = 'school' | 'skill' | 'project' | 'competition' | 'general';
export type DayRating = 'excellent' | 'normal' | 'needs_makeup' | null;

export interface SchoolBellTime {
  period: number; // 1 to 5
  title: string; // e.g. "زنگ اول"
  startTime: string; // "07:30"
  endTime: string; // "09:00"
}

export interface SchoolSubject {
  id: string;
  name: string;
  teacher?: string;
  room?: string;
  color: string; // hex or tailwind identifier
  notes?: string;
  studyRange?: string; // e.g. "فصل ۱ تا ۳ (صفحه ۱۰ تا ۴۵)"
  reviewSchedule?: string; // e.g. "شنبه‌ها و سه‌شنبه‌ها"
}

export interface SubjectGrade {
  id: string;
  subjectId: string;
  title: string; // e.g. "میان‌ترم اول"
  score: number; // e.g. 19.5
  maxScore: number; // e.g. 20
  date: string; // YYYY-MM-DD
  weight?: number; // e.g. 1
  notes?: string;
}

export interface WeeklyTimetableCell {
  dayIndex: number; // 0: شنبه, 1: یکشنبه, 2: دوشنبه, 3: سه‌شنبه, 4: چهارشنبه
  period: number; // 1 to 5
  subjectId: string;
  customSubjectName?: string;
  room?: string;
  teacher?: string;
  color?: string;
  notes?: string;
}

export interface TaskItem {
  id: string;
  title: string;
  completed: boolean;
  priority: Priority;
  dueTime?: string;
  notes?: string;
}

export interface SchoolHomework {
  id: string;
  dayIndex: number; // 0 to 4
  subjectId: string;
  subjectName: string;
  title: string;
  description?: string;
  completed: boolean;
  dueDate: string; // YYYY-MM-DD
  priority: Priority;
  estimatedMinutes?: number;
}

export interface SchoolExamItem {
  id: string;
  dayIndex?: number;
  subjectId: string;
  subjectName: string;
  title: string;
  type: 'exam' | 'quiz' | 'submission'; // امتحان | پرسش کلاسی | تحویل پروژه
  date: string;
  time?: string;
  chapters?: string;
  completed: boolean;
  priority: Priority;
  notes?: string;
}

export interface DaySpecificData {
  dayIndex: number; // 0 to 4
  overallRating: DayRating;
  preSchoolTasks: TaskItem[];
  postSchoolTasks: TaskItem[];
  notes: string;
  reflectionReport: string; // گزارش پایان روز
}

export interface StudySession {
  id: string;
  subjectName: string;
  subjectId?: string;
  topic: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  expectedDurationMin: number;
  actualDurationMin: number;
  focusScore: number; // 1 to 5
  outcomeNotes: string;
  type?: 'school' | 'skill' | 'competition' | 'general';
}

export interface SkillRoadmapStep {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  order: number;
}

export interface SkillResource {
  id: string;
  title: string;
  type: 'course' | 'book' | 'article' | 'video';
  url?: string;
  completed: boolean;
}

export interface SkillExercise {
  id: string;
  title: string;
  completed: boolean;
  dueDate?: string;
  notes?: string;
}

export interface SkillPracticeLog {
  id: string;
  date: string;
  minutes: number;
  notes: string;
}

export interface Skill {
  id: string;
  name: string;
  category: 'programming' | 'ai' | 'language' | 'security' | 'tools' | 'other';
  currentLevel: 'مقدماتی' | 'متوسط' | 'پیشرفته' | 'تخصصی';
  targetLevel: 'متوسط' | 'پیشرفته' | 'تخصصی' | 'تسلط کامل';
  dailyTargetMin: number;
  weeklyTargetMin: number;
  roadmap: SkillRoadmapStep[];
  resources: SkillResource[];
  exercises: SkillExercise[];
  practiceLogs: SkillPracticeLog[];
  notes: string;
  weaknesses: string[];
  relatedProjectIds: string[];
  targetDate: string;
  status: 'active' | 'paused' | 'completed';
  streak: number;
  activeDates: string[]; // List of YYYY-MM-DD dates practiced
}

export type ProjectStatus = 'ideas' | 'todo' | 'in_progress' | 'waiting' | 'completed';

export interface ProjectSubtask {
  id: string;
  title: string;
  done: boolean;
}

export interface ProjectTask {
  id: string;
  title: string;
  description?: string;
  status: ProjectStatus;
  priority: Priority;
  dueDate?: string;
  estimatedHours?: number;
  actualHours?: number;
  notes?: string;
  subtasks: ProjectSubtask[];
}

export interface ProjectBug {
  id: string;
  title: string;
  resolved: boolean;
  severity: Priority;
  notes?: string;
}

export interface ProjectActivityLog {
  id: string;
  timestamp: string;
  action: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  startDate: string;
  deadline: string;
  status: ProjectStatus;
  priority: Priority;
  targetsAndDeliverables: string;
  progressPercentage: number;
  techStack: string[];
  githubUrl?: string;
  demoUrl?: string;
  techNotes: string;
  knownBugs: ProjectBug[];
  tasks: ProjectTask[];
  activityLogs: ProjectActivityLog[];
}

export interface CompetitionStage {
  id: string;
  name: string;
  date: string;
  completed: boolean;
  notes?: string;
}

export interface CompetitionPrepTopic {
  id: string;
  title: string;
  mastered: boolean;
}

export interface CompetitionMockExam {
  id: string;
  title: string;
  score: number;
  maxScore: number;
  date: string;
  notes?: string;
}

export interface Competition {
  id: string;
  title: string;
  organizer: string;
  domain: string;
  description: string;
  officialUrl?: string;
  currentStage: string;
  registrationDate: string;
  registrationDeadline: string;
  stages: CompetitionStage[];
  resultDate?: string;
  syllabusAndResources: string;
  readinessStatus: 'preparing' | 'ready' | 'registered' | 'completed';
  readinessPercentage: number;
  notes: string;
  finalResult?: string;
  prepTopics: CompetitionPrepTopic[];
  mockExams: CompetitionMockExam[];
  solvedProblemsCount: number;
  weaknesses: string[];
}

export interface GoalMilestone {
  id: string;
  title: string;
  done: boolean;
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  level: 'long_term' | 'monthly' | 'weekly';
  category: SectionType;
  startDate: string;
  deadline: string;
  priority: Priority;
  measurementMetric: string;
  status: 'todo' | 'in_progress' | 'completed';
  progressPercentage: number;
  milestones: GoalMilestone[];
  linkedEntityId?: string;
}

export interface WeeklyReview {
  id: string;
  weekStartDate: string;
  weekEndDate: string;
  completedTasksSummary: string;
  unfinishedTasksSummary: string;
  totalStudyHours: number;
  biggestWin: string;
  nextWeekPriorities: string;
  createdAt: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  date: string; // YYYY-MM-DD
  startTime?: string; // HH:mm
  endTime?: string; // HH:mm
  section: SectionType;
  priority: Priority;
  reminderMinutesBefore?: number;
  completed?: boolean;
  linkedId?: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  category: SectionType;
  tags: string[];
  pinned: boolean;
  linkedId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ActivityLogItem {
  id: string;
  timestamp: string;
  section: SectionType;
  description: string;
}

export interface ReminderNotification {
  id: string;
  title: string;
  message: string;
  targetTime: string;
  isRead: boolean;
  section: SectionType;
}

export interface UserProfile {
  name: string;
  gradeOrField: string;
  avatarSeed: string;
  theme: 'light' | 'dark';
  enableBrowserNotifications: boolean;
  bellTimes: SchoolBellTime[];
}
