import React from 'react';
import {
  Calendar as CalendarIcon,
  CheckCircle2,
  Clock,
  GraduationCap,
  Sparkles,
  FolderGit2,
  Trophy,
  Target,
  ChevronLeft,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  formatJalaliFull,
  formatJalaliShort,
  getIranianDayOfWeek,
  getIranianDayName,
  toPersianDigits,
  getRelativeTimeString,
  toJalali,
  getJalaliMonthDays,
  getPersianMonthName,
} from '../../utils/jalali';
import { NavTab } from '../layout/Sidebar';

interface DashboardViewProps {
  onNavigate: (tab: NavTab) => void;
  onOpenQuickAdd: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate, onOpenQuickAdd }) => {
  const {
    profile,
    subjects,
    weeklyCells,
    dayData,
    homeworks,
    toggleHomework,
    studySessions,
    skills,
    projects,
    competitions,
    goals,
  } = useApp();

  const today = new Date();
  const currentIranianDayIdx = getIranianDayOfWeek(today);
  const isSchoolDay = currentIranianDayIdx >= 0 && currentIranianDayIdx <= 4;

  const todayBells = isSchoolDay
    ? [1, 2, 3, 4, 5].map((period) => {
        const cell = weeklyCells.find((c) => c.dayIndex === currentIranianDayIdx && c.period === period);
        const sub = subjects.find((s) => s.id === cell?.subjectId);
        const bellTime = profile.bellTimes.find((b) => b.period === period);
        return {
          period,
          bellTime: bellTime || { startTime: '08:00', endTime: '09:00', title: `زنگ ${period}` },
          subject: sub,
          subjectName: cell?.customSubjectName || sub?.name,
          room: cell?.room || sub?.room,
          color: cell?.color || sub?.color || '#6366f1',
          notes: cell?.notes,
        };
      })
    : [];

  const todayIso = today.toISOString().slice(0, 10);
  const overdueHomeworks = homeworks.filter((h) => !h.completed && h.dueDate < todayIso);
  const pendingHomeworks = homeworks.filter((h) => !h.completed);

  const weeklyGoals = goals.filter((g) => g.level === 'weekly');
  const completedWeeklyGoals = weeklyGoals.filter((g) => g.status === 'completed').length;
  const weeklyGoalsPercent = weeklyGoals.length > 0 ? Math.round((completedWeeklyGoals / weeklyGoals.length) * 100) : 0;

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const recentSessions = studySessions.filter((s) => new Date(s.date) >= sevenDaysAgo);
  const totalRecentMinutes = recentSessions.reduce((acc, s) => acc + (s.actualDurationMin || 0), 0);
  const totalRecentHours = (totalRecentMinutes / 60).toFixed(1);

  const last7DaysChart = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const iso = d.toISOString().slice(0, 10);
    const dayName = getIranianDayName(d);
    const mins = studySessions.filter((s) => s.date === iso).reduce((acc, s) => acc + s.actualDurationMin, 0);
    return {
      dayName,
      date: iso,
      hours: +(mins / 60).toFixed(1),
      mins,
    };
  });
  const maxChartHours = Math.max(1, ...last7DaysChart.map((d) => d.hours));

  const nextCompetition = competitions.slice().sort((a, b) => new Date(a.registrationDeadline).getTime() - new Date(b.registrationDeadline).getTime())[0];
  const daysToNextCompetition = nextCompetition
    ? Math.max(0, Math.ceil((new Date(nextCompetition.registrationDeadline).getTime() - today.getTime()) / (1000 * 60 * 60 * 24)))
    : null;

  const todayJalali = toJalali(today);
  const daysInCurrentJalaliMonth = getJalaliMonthDays(todayJalali.jy, todayJalali.jm);
  const monthName = getPersianMonthName(todayJalali.jm);

  const hour = today.getHours();
  const greeting = hour < 12 ? 'صبح بخیر' : hour < 17 ? 'بعدازظهر بخیر' : 'عصر بخیر';

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden bg-gradient-to-l from-indigo-900 via-slate-900 to-slate-900 text-white rounded-2xl p-6 border border-indigo-950/40 shadow-sm">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5 text-xs text-indigo-300 font-medium">
              <CalendarIcon className="w-3.5 h-3.5" />
              <span>{formatJalaliFull(today)}</span>
              <span>·</span>
              <span>روز {getIranianDayName(today)}</span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight">
              {greeting}، {profile.name}
            </h2>
            <p className="mt-1 text-xs md:text-sm text-slate-300 max-w-xl leading-relaxed">
              برنامه تحصیلی و مهارتی شما آماده است؛ {toPersianDigits(pendingHomeworks.length)} تکلیف فعال،{' '}
              {toPersianDigits(overdueHomeworks.length)} کار نیازمند پیگیری و{' '}
              {toPersianDigits(weeklyGoals.length)} هدف هفتگی در حال پیشرفت دارید.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onOpenQuickAdd}
              className="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 active:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
            >
              + ثبت سریع
            </button>
            <button
              onClick={() => onNavigate('school')}
              className="px-4 py-2 bg-white/10 hover:bg-white/15 text-white text-xs font-medium rounded-xl border border-white/10 transition-all"
            >
              برنامه مدرسه
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigate('school')}
          className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span>تکالیف در دست انجام</span>
            <GraduationCap className="w-4 h-4 text-blue-500" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {toPersianDigits(pendingHomeworks.length)}
            </span>
            <span className="text-[11px] text-blue-600 dark:text-blue-400 flex items-center group-hover:translate-x-[-2px] transition-transform">
              مشاهده <ChevronLeft className="w-3 h-3" />
            </span>
          </div>
          <p className="mt-1 text-[11px] text-slate-400">
            {overdueHomeworks.length > 0 ? (
              <span className="text-rose-500 font-medium">
                {toPersianDigits(overdueHomeworks.length)} کار عقب‌افتاده
              </span>
            ) : (
              'بدون کار عقب‌افتاده'
            )}
          </p>
        </div>

        <div
          onClick={() => onNavigate('goals')}
          className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span>تحقق اهداف هفتگی</span>
            <Target className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {toPersianDigits(weeklyGoalsPercent)}٪
            </span>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center group-hover:translate-x-[-2px] transition-transform">
              اهداف <ChevronLeft className="w-3 h-3" />
            </span>
          </div>
          <p className="mt-1 text-[11px] text-slate-400">
            {toPersianDigits(completedWeeklyGoals)} از {toPersianDigits(weeklyGoals.length)} هدف کامل شده
          </p>
        </div>

        <div
          onClick={() => onNavigate('school')}
          className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span>مطالعه ۷ روز اخیر</span>
            <Clock className="w-4 h-4 text-purple-500" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {toPersianDigits(totalRecentHours)} <span className="text-xs font-normal">ساعت</span>
            </span>
            <span className="text-[11px] text-purple-600 dark:text-purple-400 flex items-center group-hover:translate-x-[-2px] transition-transform">
              پومودورو <ChevronLeft className="w-3 h-3" />
            </span>
          </div>
          <p className="mt-1 text-[11px] text-slate-400">
            در {toPersianDigits(recentSessions.length)} جلسه تمرکزی
          </p>
        </div>

        <div
          onClick={() => onNavigate('competitions')}
          className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span>موعد مسابقه بعدی</span>
            <Trophy className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {daysToNextCompetition !== null ? `${toPersianDigits(daysToNextCompetition)} روز` : '—'}
            </span>
            <span className="text-[11px] text-amber-600 dark:text-amber-400 flex items-center group-hover:translate-x-[-2px] transition-transform">
              مسابقات <ChevronLeft className="w-3 h-3" />
            </span>
          </div>
          <p className="mt-1 text-[11px] text-slate-400 truncate">
            {nextCompetition ? nextCompetition.title : 'مسابقه‌ای ثبت نشده'}
          </p>
        </div>
      </div>

      {/* Main Grid: Today's Schedule & Homework */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Bells Bar */}
          <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  برنامه زنگ‌های درسی امروز ({getIranianDayName(today)})
                </h3>
              </div>
              <button
                onClick={() => onNavigate('school')}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5"
              >
                جدول کامل هفتگی <ChevronLeft className="w-3.5 h-3.5" />
              </button>
            </div>

            {isSchoolDay ? (
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5">
                {todayBells.map((bell) => (
                  <div
                    key={bell.period}
                    className="p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                        <span>زنگ {toPersianDigits(bell.period)}</span>
                        <span className="font-mono text-[10px]">{toPersianDigits(bell.bellTime.startTime)}</span>
                      </div>
                      <div className="font-bold text-xs text-slate-800 dark:text-slate-100 truncate">
                        {bell.subjectName || '— بدون درس —'}
                      </div>
                    </div>
                    <div className="mt-2 pt-2 border-t border-slate-200/50 dark:border-slate-700/50 flex items-center justify-between text-[10px] text-slate-500">
                      <span>{bell.room || 'کلاس'}</span>
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: bell.color }} />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-6 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/30 rounded-lg">
                امروز روز تعطیل است. می‌توانید از بخش مطالعه یا پروژه‌ها برای رشد شخصی استفاده کنید.
              </div>
            )}
          </div>

          {/* Pending Tasks & Homeworks */}
          <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  تکالیف و کارهای اولویت‌دار
                </h3>
              </div>
              <button
                onClick={() => onNavigate('school')}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                مدیریت تکالیف
              </button>
            </div>

            <div className="space-y-2">
              {homeworks.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-400">
                  هنوز تکلیفی ثبت نشده است. از دکمه «+ ثبت سریع» یا بخش مدرسه تکالیف خود را اضافه کنید.
                </div>
              ) : (
                homeworks.slice(0, 5).map((hw) => {
                const isOverdue = !hw.completed && hw.dueDate < todayIso;
                return (
                  <div
                    key={hw.id}
                    className={`flex items-center justify-between p-3 rounded-lg border transition-all ${
                      hw.completed
                        ? 'bg-slate-50/50 dark:bg-slate-800/20 border-slate-200/60 dark:border-slate-800/60 opacity-60'
                        : isOverdue
                        ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50'
                        : 'bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <input
                        type="checkbox"
                        checked={hw.completed}
                        onChange={() => toggleHomework(hw.id)}
                        className="w-4 h-4 text-indigo-600 rounded border-slate-300 dark:border-slate-700 cursor-pointer"
                      />
                      <div className="min-w-0">
                        <p
                          className={`text-xs font-semibold truncate ${
                            hw.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-100'
                          }`}
                        >
                          {hw.title}
                        </p>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                          <span>{hw.subjectName}</span>
                          <span>·</span>
                          <span className={isOverdue ? 'text-rose-600 dark:text-rose-400 font-medium' : 'text-slate-500 dark:text-slate-400'}>
                            موعد: {getRelativeTimeString(hw.dueDate)} ({formatJalaliShort(hw.dueDate)})
                          </span>
                        </div>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-medium shrink-0 ${
                        hw.completed
                          ? 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                          : isOverdue
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/60 dark:text-rose-300'
                          : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      }`}
                    >
                      {hw.completed ? 'انجام‌شده' : isOverdue ? 'عقب‌افتاده' : 'در حال انجام'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Weekly Study Hours Graph */}
          <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  روند ساعت مطالعه در ۷ روز اخیر
                </h3>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                مجموع: {toPersianDigits(totalRecentHours)} ساعت
              </span>
            </div>

            <div className="flex items-end justify-between gap-2 h-36 pt-4 px-2">
              {last7DaysChart.map((d, idx) => {
                const heightPercent = Math.round((d.hours / maxChartHours) * 100);
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    <span className="text-[10px] font-mono text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                      {toPersianDigits(d.hours)}h
                    </span>
                    <div className="w-full max-w-[32px] bg-slate-100 dark:bg-slate-800 rounded-t-lg overflow-hidden flex items-end h-24">
                      <div
                        className="w-full bg-indigo-500 hover:bg-indigo-600 transition-all rounded-t-lg"
                        style={{ height: `${Math.max(6, heightPercent)}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-full">
                      {d.dayName.slice(0, 3)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Col: Mini Calendar, Skills, Projects */}
        <div className="space-y-6">
          {/* Mini Shamsi Calendar */}
          <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                تقویم {monthName} {toPersianDigits(todayJalali.jy)}
              </span>
              <button
                onClick={() => onNavigate('calendar')}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                نمای تقویم کامل
              </button>
            </div>

            <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-semibold text-slate-400 mb-2">
              <span>ش</span>
              <span>ی</span>
              <span>د</span>
              <span>س</span>
              <span>چ</span>
              <span>پ</span>
              <span>ج</span>
            </div>

            <div className="grid grid-cols-7 gap-1 text-center text-xs">
              {Array.from({ length: daysInCurrentJalaliMonth }).map((_, i) => {
                const dayNum = i + 1;
                const isCurrent = dayNum === todayJalali.jd;
                return (
                  <div
                    key={dayNum}
                    className={`h-7 flex items-center justify-center rounded-lg font-mono text-[11px] transition-colors ${
                      isCurrent
                        ? 'bg-indigo-600 text-white font-bold shadow-xs'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {toPersianDigits(dayNum)}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active Skills Snapshot */}
          <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  مسیر یادگیری مهارت‌ها
                </span>
              </div>
              <button
                onClick={() => onNavigate('skills')}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                تمام مهارت‌ها
              </button>
            </div>

            <div className="space-y-3">
              {skills.length === 0 ? (
                <div className="py-4 text-center text-xs text-slate-400">
                  هنوز مهارتی تعریف نشده است.
                </div>
              ) : (
                skills.map((skill) => {
                  const totalSteps = skill.roadmap.length;
                  const doneSteps = skill.roadmap.filter((r) => r.completed).length;
                  const percent = totalSteps > 0 ? Math.round((doneSteps / totalSteps) * 100) : 0;
                  return (
                    <div key={skill.id} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                          {skill.name}
                        </span>
                        <span className="font-mono text-slate-500 text-[11px]">
                          {toPersianDigits(percent)}٪
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Active Projects Snapshot */}
          <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1.5">
                <FolderGit2 className="w-4 h-4 text-purple-500" />
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  وضعیت پروژه‌های فعال
                </span>
              </div>
              <button
                onClick={() => onNavigate('projects')}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                برد کانبان
              </button>
            </div>

            <div className="space-y-3">
              {projects.length === 0 ? (
                <div className="py-4 text-center text-xs text-slate-400">
                  هنوز پروژه‌ای ثبت نشده است.
                </div>
              ) : (
                projects.map((proj) => (
                  <div
                    key={proj.id}
                    onClick={() => onNavigate('projects')}
                    className="p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-slate-200 cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
                        {proj.title}
                      </span>
                      <span className="text-[10px] font-mono text-purple-600 dark:text-purple-400 font-bold">
                        {toPersianDigits(proj.progressPercentage)}٪
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-purple-600 h-full rounded-full"
                        style={{ width: `${proj.progressPercentage}%` }}
                      />
                    </div>
                    <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                      <span>{toPersianDigits(proj.tasks.length)} وظیفه</span>
                      <span>موعد: {getRelativeTimeString(proj.deadline)}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
