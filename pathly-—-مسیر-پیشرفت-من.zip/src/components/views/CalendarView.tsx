import React, { useState } from 'react';
import {
  CalendarDays,
  ChevronRight,
  ChevronLeft,
  Plus,
  Trash2,
  Clock,
  Filter,
  CheckCircle2,
  X,
  BookOpen,
  Sparkles,
  FolderGit2,
  Trophy,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  toJalali,
  toGregorian,
  getJalaliMonthDays,
  getPersianMonthName,
  toPersianDigits,
  formatJalaliFull,
  formatJalaliShort,
} from '../../utils/jalali';
import { CalendarEvent, Priority, SectionType } from '../../types';

export const CalendarView: React.FC = () => {
  const {
    calendarEvents,
    addCalendarEvent,
    deleteCalendarEvent,
    toggleCalendarEventCompleted,
  } = useApp();

  const today = new Date();
  const currentJalali = toJalali(today);

  const [viewYear, setViewYear] = useState<number>(currentJalali.jy);
  const [viewMonth, setViewMonth] = useState<number>(currentJalali.jm);
  const [selectedDateStr, setSelectedDateStr] = useState<string>(
    `${currentJalali.jy}/${String(currentJalali.jm).padStart(2, '0')}/${String(currentJalali.jd).padStart(2, '0')}`
  );
  const [sectionFilter, setSectionFilter] = useState<SectionType | 'all'>('all');

  // Add Event modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [eventTitle, setEventTitle] = useState('');
  const [eventDate, setEventDate] = useState(today.toISOString().slice(0, 10));
  const [eventTime, setEventTime] = useState('16:00');
  const [eventSection, setEventSection] = useState<SectionType>('school');
  const [eventPriority, setEventPriority] = useState<Priority>('medium');
  const [eventDesc, setEventDesc] = useState('');

  const nextMonth = () => {
    if (viewMonth === 12) {
      setViewYear((y) => y + 1);
      setViewMonth(1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  const prevMonth = () => {
    if (viewMonth === 1) {
      setViewYear((y) => y - 1);
      setViewMonth(12);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const daysInMonth = getJalaliMonthDays(viewYear, viewMonth);
  // Calculate day of week for 1st day of Jalali month:
  const firstDayGreg = toGregorian(viewYear, viewMonth, 1);
  const firstDayObj = new Date(firstDayGreg.gy, firstDayGreg.gm - 1, firstDayGreg.gd);
  // Day of week: in Gregorian 6 is Saturday (in Iranian calendar Saturday is 0)
  const firstDayIranian = (firstDayObj.getDay() + 1) % 7;

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventTitle.trim()) return;

    addCalendarEvent({
      title: eventTitle.trim(),
      date: eventDate,
      startTime: eventTime,
      section: eventSection,
      priority: eventPriority,
      description: eventDesc.trim() || undefined,
      completed: false,
    });

    setEventTitle('');
    setEventDesc('');
    setShowAddModal(false);
  };

  const filteredEvents = calendarEvents.filter((ev) => {
    if (sectionFilter !== 'all' && ev.section !== sectionFilter) return false;
    return true;
  });

  const getSectionBadge = (section: SectionType) => {
    switch (section) {
      case 'school':
        return { label: 'مدرسه', icon: BookOpen, color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300' };
      case 'skill':
        return { label: 'مهارت', icon: Sparkles, color: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300' };
      case 'project':
        return { label: 'پروژه', icon: FolderGit2, color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' };
      case 'competition':
        return { label: 'مسابقه', icon: Trophy, color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300' };
      default:
        return { label: 'عمومی', icon: CalendarDays, color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <span className="p-2 rounded-xl bg-teal-100 dark:bg-teal-900/40 text-teal-600 dark:text-teal-400">
              <CalendarDays className="w-6 h-6" />
            </span>
            تقویم جامع رویدادها و ددلاین‌ها
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            یکپارچه‌سازی تاریخ امتحانات، جلسات تمرین، تحویل پروژه‌ها و مهلت مسابقات
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-medium rounded-xl shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            رویداد جدید
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-bold text-slate-400 pl-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> فیلتر بخش:
          </span>
          {[
            { id: 'all', label: 'همه رویدادها' },
            { id: 'school', label: 'مدرسه و امتحانات' },
            { id: 'skill', label: 'مهارت‌ها' },
            { id: 'project', label: 'پروژه‌ها' },
            { id: 'competition', label: 'مسابقات' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setSectionFilter(item.id as typeof sectionFilter)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors ${
                sectionFilter === item.id
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Month Navigation */}
        <div className="flex items-center gap-3">
          <button
            onClick={prevMonth}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <span className="text-sm font-black text-slate-800 dark:text-slate-200 min-w-[120px] text-center">
            {getPersianMonthName(viewMonth)} {toPersianDigits(viewYear)}
          </span>
          <button
            onClick={nextMonth}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Calendar Matrix (8 cols on large screens) */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          {/* Weekday headers */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-2">
            <div>ش</div>
            <div>ی</div>
            <div>د</div>
            <div>س</div>
            <div>چ</div>
            <div>پ</div>
            <div className="text-red-500">ج</div>
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Empty cells before month start */}
            {Array.from({ length: firstDayIranian }).map((_, i) => (
              <div key={`empty-${i}`} className="h-20 sm:h-24 p-1 rounded-xl bg-slate-50/40 dark:bg-slate-800/20 opacity-40" />
            ))}

            {/* Days in Month */}
            {Array.from({ length: daysInMonth }).map((_, idx) => {
              const dayNum = idx + 1;
              const isToday =
                currentJalali.jy === viewYear &&
                currentJalali.jm === viewMonth &&
                currentJalali.jd === dayNum;

              // Find Gregorian date for matching events
              const gDate = toGregorian(viewYear, viewMonth, dayNum);
              const gDateStr = `${gDate.gy}-${String(gDate.gm).padStart(2, '0')}-${String(gDate.gd).padStart(2, '0')}`;
              const dayEvents = filteredEvents.filter((ev) => ev.date === gDateStr);

              return (
                <div
                  key={dayNum}
                  onClick={() => setSelectedDateStr(`${viewYear}/${String(viewMonth).padStart(2, '0')}/${String(dayNum).padStart(2, '0')}`)}
                  className={`h-20 sm:h-24 p-1.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isToday
                      ? 'border-teal-500 bg-teal-50/40 dark:bg-teal-950/20'
                      : 'border-slate-100 dark:border-slate-800/80 bg-white dark:bg-slate-900/60 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-bold ${
                      isToday
                        ? 'w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center'
                        : 'text-slate-700 dark:text-slate-300'
                    }`}>
                      {toPersianDigits(dayNum)}
                    </span>
                    {dayEvents.length > 0 && (
                      <span className="text-[10px] px-1 rounded-full bg-teal-100 dark:bg-teal-900/60 text-teal-700 font-bold">
                        {toPersianDigits(dayEvents.length)}
                      </span>
                    )}
                  </div>

                  <div className="space-y-1 overflow-hidden">
                    {dayEvents.slice(0, 2).map((ev) => {
                      const badge = getSectionBadge(ev.section);
                      return (
                        <div
                          key={ev.id}
                          className={`text-[10px] px-1 py-0.5 rounded truncate font-medium ${badge.color}`}
                          title={ev.title}
                        >
                          {ev.title}
                        </div>
                      );
                    })}
                    {dayEvents.length > 2 && (
                      <span className="text-[9px] text-slate-400 block text-center">
                        +{toPersianDigits(dayEvents.length - 2)} مورد دیگر
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Day Agenda (4 cols) */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                برنامه و رویدادهای پیش‌رو
              </h2>
              <span className="text-xs text-slate-400">
                مجموع: {toPersianDigits(filteredEvents.length)} رویداد
              </span>
            </div>
            <button
              onClick={() => setShowAddModal(true)}
              className="p-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-600 hover:bg-teal-100"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {filteredEvents.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">
                هیچ رویدادی در این بخش یافت نشد.
              </p>
            ) : (
              filteredEvents.map((ev) => {
                const badge = getSectionBadge(ev.section);
                const BadgeIcon = badge.icon;

                return (
                  <div
                    key={ev.id}
                    className={`p-3.5 rounded-xl border transition-all space-y-2 text-xs ${
                      ev.completed
                        ? 'bg-emerald-50/40 dark:bg-emerald-950/10 border-emerald-200 dark:border-emerald-900/30 line-through text-slate-400'
                        : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => toggleCalendarEventCompleted(ev.id)}
                          className={`w-4 h-4 rounded border flex items-center justify-center ${
                            ev.completed ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-400'
                          }`}
                        >
                          {ev.completed && <CheckCircle2 className="w-3 h-3" />}
                        </button>
                        <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                          {ev.title}
                        </span>
                      </div>
                      <button
                        onClick={() => deleteCalendarEvent(ev.id)}
                        className="text-slate-400 hover:text-red-500"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {ev.description && (
                      <p className="text-slate-500 pr-6 leading-relaxed">
                        {ev.description}
                      </p>
                    )}

                    <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
                      <span className={`px-2 py-0.5 rounded-md font-semibold flex items-center gap-1 ${badge.color}`}>
                        <BadgeIcon className="w-3 h-3" />
                        {badge.label}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatJalaliShort(ev.date)} {ev.startTime ? `- ${ev.startTime}` : ''}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Add Event Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-lg text-slate-900 dark:text-white flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-teal-600" />
                ثبت رویداد جدید در تقویم
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  عنوان رویداد:
                </label>
                <input
                  type="text"
                  required
                  value={eventTitle}
                  onChange={(e) => setEventTitle(e.target.value)}
                  placeholder="مثلاً: جلسه ارائه پروژه یا آزمون فیزیک"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">تاریخ:</label>
                  <input
                    type="date"
                    required
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">ساعت:</label>
                  <input
                    type="time"
                    value={eventTime}
                    onChange={(e) => setEventTime(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">بخش مربوطه:</label>
                  <select
                    value={eventSection}
                    onChange={(e) => setEventSection(e.target.value as SectionType)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  >
                    <option value="school">مدرسه</option>
                    <option value="skill">مهارت‌ها</option>
                    <option value="project">پروژه</option>
                    <option value="competition">مسابقات</option>
                    <option value="general">عمومی</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">اولویت:</label>
                  <select
                    value={eventPriority}
                    onChange={(e) => setEventPriority(e.target.value as Priority)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  >
                    <option value="high">بالا (فوری)</option>
                    <option value="medium">متوسط</option>
                    <option value="low">پایین</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">توضیحات تکمیلی:</label>
                <textarea
                  rows={2}
                  value={eventDesc}
                  onChange={(e) => setEventDesc(e.target.value)}
                  placeholder="مکان، لینک جلسه یا نکات مهم..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold"
                >
                  افزودن رویداد
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
