import { prisma } from '../src/lib/prisma';
import bcrypt from 'bcryptjs';

async function main() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL || 'admin@morico.style';
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || 'ChangeMe123!';

  const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(adminPassword, 12);
    await prisma.user.create({
      data: {
        name: 'مدیر موریکو',
        email: adminEmail,
        passwordHash,
        role: 'ADMIN'
      }
    });
    console.log(`Admin created: ${adminEmail} / ${adminPassword}`);
  } else {
    console.log('Admin already exists, skipping.');
  }

  const category = await prisma.category.upsert({
    where: { slug: 'tshirt' },
    create: { name: 'تی‌شرت', slug: 'tshirt', sortOrder: 0 },
    update: {}
  });

  const existingProduct = await prisma.product.findUnique({ where: { slug: 'basic-tshirt' } });
  if (!existingProduct) {
    const product = await prisma.product.create({
      data: {
        name: 'تی‌شرت ساده سفید',
        slug: 'basic-tshirt',
        description: 'تی‌شرت نخی سفید، مناسب برای چاپ اختصاصی روی جلو و پشت.',
        categoryId: category.id,
        basePrice: 350000,
        discountPercent: 0,
        isAvailable: true,
        customizationEnabled: true,
        inventory: { create: { stock: 50 } },
        images: {
          create: [{ url: '/brand/morico-logo.jpg', altText: 'تی‌شرت ساده', sortOrder: 0 }]
        },
        views: {
          create: [
            {
              name: 'جلو',
              imageUrl: '/brand/morico-logo.jpg',
              sortOrder: 0,
              printableArea: {
                create: {
                  x: 150,
                  y: 150,
                  width: 300,
                  height: 300,
                  minDesignWidth: 40,
                  maxDesignWidth: 300,
                  minDesignHeight: 40,
                  maxDesignHeight: 300
                }
              }
            },
            {
              name: 'پشت',
              imageUrl: '/brand/morico-logo.jpg',
              sortOrder: 1,
              printableArea: {
                create: {
                  x: 150,
                  y: 120,
                  width: 300,
                  height: 350,
                  minDesignWidth: 40,
                  maxDesignWidth: 300,
                  minDesignHeight: 40,
                  maxDesignHeight: 350
                }
              }
            }
          ]
        }
      }
    });
    console.log(`Sample product created: ${product.slug}`);
  } else {
    console.log('Sample product already exists, skipping.');
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
