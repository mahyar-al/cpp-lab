'use client';

import React, { useRef, useState, useEffect } from 'react';

interface BackgroundTouchUpProps {
  originalUrl: string;
  cutoutUrl: string;
  onCancel: () => void;
  onSave: (blob: Blob) => Promise<string | null>;
}

export function BackgroundTouchUp({
  cutoutUrl,
  onCancel,
  onSave
}: BackgroundTouchUpProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [brushSize, setBrushSize] = useState(20);
  const [mode, setMode] = useState<'erase' | 'restore'>('erase');
  const [saving, setSaving] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.src = cutoutUrl;
    img.onload = () => {
      canvas.width = img.naturalWidth || 600;
      canvas.height = img.naturalHeight || 600;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
    };
  }, [cutoutUrl]);

  function handleMouseDown(e: React.MouseEvent<HTMLCanvasElement>) {
    setIsDrawing(true);
    draw(e);
  }

  function handleMouseUp() {
    setIsDrawing(false);
  }

  function draw(e: React.MouseEvent<HTMLCanvasElement>) {
    if (!isDrawing && e.type !== 'mousedown') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    ctx.save();
    if (mode === 'erase') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(x, y, brushSize, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      ctx.beginPath();
      ctx.arc(x, y, brushSize, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  async function handleSave() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setSaving(true);
    setError(null);

    canvas.toBlob(async (blob) => {
      if (!blob) {
        setSaving(false);
        setError('خطا در تبدیل خروجی تصویر');
        return;
      }
      const err = await onSave(blob);
      setSaving(false);
      if (err) setError(err);
    }, 'image/png');
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
      <div className="card w-full max-w-2xl overflow-hidden bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between border-b border-ink-100 pb-3">
          <h3 className="text-base font-bold text-ink-900">روتوش و پاک کردن دستی پس‌زمینه</h3>
          <button
            type="button"
            onClick={onCancel}
            className="text-xs text-ink-400 hover:text-ink-800"
          >
            ✕ بستن
          </button>
        </div>

        <div className="mb-4 flex flex-wrap items-center gap-4 text-xs">
          <div className="flex rounded-lg border border-ink-200 p-0.5">
            <button
              type="button"
              onClick={() => setMode('erase')}
              className={`rounded-md px-3 py-1.5 transition ${
                mode === 'erase' ? 'bg-ink-900 text-white' : 'text-ink-700 hover:bg-powder-100'
              }`}
            >
              پاک‌کن (Eraser)
            </button>
            <button
              type="button"
              onClick={() => setMode('restore')}
              className={`rounded-md px-3 py-1.5 transition ${
                mode === 'restore' ? 'bg-ink-900 text-white' : 'text-ink-700 hover:bg-powder-100'
              }`}
            >
              قلم (Brush)
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span>اندازه قلم:</span>
            <input
              type="range"
              min={5}
              max={60}
              value={brushSize}
              onChange={(e) => setBrushSize(Number(e.target.value))}
              className="w-24"
            />
            <span className="font-mono">{brushSize}px</span>
          </div>
        </div>

        <div className="flex max-h-[50vh] justify-center overflow-auto rounded-xl border border-dashed border-ink-200 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] p-2">
          <canvas
            ref={canvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={draw}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className="cursor-crosshair max-h-[45vh] w-auto max-w-full object-contain"
          />
        </div>

        {error && <p className="mt-3 text-xs text-red-600">{error}</p>}

        <div className="mt-5 flex justify-end gap-3 border-t border-ink-100 pt-4">
          <button type="button" onClick={onCancel} className="btn-outline px-4 py-2 text-xs">
            انصراف
          </button>
          <button
            type="button"
            disabled={saving}
            onClick={handleSave}
            className="btn-primary px-5 py-2 text-xs"
          >
            {saving ? 'در حال ذخیره...' : 'ذخیره و اعمال'}
          </button>
        </div>
      </div>
    </div>
  );
}
