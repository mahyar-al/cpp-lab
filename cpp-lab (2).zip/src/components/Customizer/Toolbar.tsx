'use client';

import React, { useRef } from 'react';

interface ToolbarProps {
  busy: boolean;
  hasSelection: boolean;
  hasTextSelection: boolean;
  textColor: string;
  onAddText: () => void;
  onUploadImage: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemoveBackground: () => void;
  onManualEdit: () => void;
  onDelete: () => void;
  onBringForward: () => void;
  onSendBackward: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onChangeTextColor: (color: string) => void;
}

export function Toolbar({
  busy,
  hasSelection,
  hasTextSelection,
  textColor,
  onAddText,
  onUploadImage,
  onRemoveBackground,
  onManualEdit,
  onDelete,
  onBringForward,
  onSendBackward,
  onUndo,
  onRedo,
  onChangeTextColor
}: ToolbarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="card space-y-4 p-4 text-sm">
      <h2 className="text-xs font-bold uppercase tracking-wider text-powder-800">ابزارهای طراحی</h2>

      {/* Main Actions */}
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          disabled={busy}
          onClick={onAddText}
          className="btn-outline flex items-center justify-center gap-1.5 py-2 text-xs"
        >
          <span>✍️</span>
          <span>افزودن متن</span>
        </button>

        <button
          type="button"
          disabled={busy}
          onClick={() => fileInputRef.current?.click()}
          className="btn-outline flex items-center justify-center gap-1.5 py-2 text-xs"
        >
          <span>🖼️</span>
          <span>آپلود تصویر</span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={onUploadImage}
        />
      </div>

      {/* History */}
      <div className="flex gap-2">
        <button
          type="button"
          onClick={onUndo}
          disabled={busy}
          className="btn-outline flex-1 py-1.5 text-xs"
          title="بازگشت به مرحله قبل (Undo)"
        >
          ↩ بازگشت
        </button>
        <button
          type="button"
          onClick={onRedo}
          disabled={busy}
          className="btn-outline flex-1 py-1.5 text-xs"
          title="انجام مجدد (Redo)"
        >
          انجام مجدد ↪
        </button>
      </div>

      {/* Selected element controls */}
      {hasSelection && (
        <div className="space-y-3 rounded-xl border border-powder-200 bg-powder-50/70 p-3">
          <p className="text-[11px] font-semibold text-ink-700">ویرایش عنصر انتخابی</p>

          {hasTextSelection && (
            <div>
              <label className="mb-1 block text-[11px] text-ink-500">رنگ متن</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={textColor}
                  onChange={(e) => onChangeTextColor(e.target.value)}
                  className="h-8 w-10 cursor-pointer rounded border border-ink-200"
                />
                <span className="font-mono text-xs">{textColor}</span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={onBringForward}
              disabled={busy}
              className="btn-outline py-1 text-xs"
            >
              رو آوردن ⬆
            </button>
            <button
              type="button"
              onClick={onSendBackward}
              disabled={busy}
              className="btn-outline py-1 text-xs"
            >
              زیر بردن ⬇
            </button>
          </div>

          <div className="grid grid-cols-1 gap-1.5">
            <button
              type="button"
              onClick={onRemoveBackground}
              disabled={busy}
              className="btn bg-powder-200 py-1.5 text-xs text-ink-900 hover:bg-powder-300"
            >
              ✨ حذف پس‌زمینه خودکار
            </button>
            <button
              type="button"
              onClick={onManualEdit}
              disabled={busy}
              className="btn-outline py-1.5 text-xs"
            >
              🖌️ روتوش دستی پس‌زمینه
            </button>
          </div>

          <button
            type="button"
            onClick={onDelete}
            disabled={busy}
            className="btn w-full bg-red-50 py-1.5 text-xs text-red-600 hover:bg-red-100"
          >
            🗑️ حذف عنصر
          </button>
        </div>
      )}
    </div>
  );
}
