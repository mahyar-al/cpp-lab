import { inMemoryDb } from '@/lib/in-memory-db';

export const prisma = new Proxy({} as any, {
  get: (_target, prop: string) => {
    if (prop === '$connect' || prop === '$disconnect') {
      return async () => {};
    }
    if (prop === '$transaction') {
      return async (cb: any) => {
        if (typeof cb === 'function') {
          return cb(prisma);
        }
        return Promise.all(cb);
      };
    }
    return inMemoryDb.getModel(prop);
  }
});

export default prisma;
