export interface RemoveBgOptions {
  tolerance?: number;
  feather?: number;
}

export async function removeBackgroundFromImage(
  imgElement: HTMLImageElement,
  options: RemoveBgOptions = {}
): Promise<{ blob: Blob }> {
  const tolerance = options.tolerance ?? 32;
  const canvas = document.createElement('canvas');
  canvas.width = imgElement.naturalWidth || imgElement.width || 600;
  canvas.height = imgElement.naturalHeight || imgElement.height || 600;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas context not available');
  }

  ctx.drawImage(imgElement, 0, 0, canvas.width, canvas.height);
  const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const d = imgData.data;

  // Sample corner pixel as likely background color
  const sampleR = d[0];
  const sampleG = d[1];
  const sampleB = d[2];

  for (let i = 0; i < d.length; i += 4) {
    const r = d[i];
    const g = d[i + 1];
    const b = d[i + 2];

    const distToSample = Math.sqrt(
      Math.pow(r - sampleR, 2) + Math.pow(g - sampleG, 2) + Math.pow(b - sampleB, 2)
    );

    // Also check for pure white or near-white background
    const distToWhite = Math.sqrt(
      Math.pow(r - 255, 2) + Math.pow(g - 255, 2) + Math.pow(b - 255, 2)
    );

    if (distToSample < tolerance * 1.5 || distToWhite < tolerance * 1.2) {
      d[i + 3] = 0; // Transparent
    }
  }

  ctx.putImageData(imgData, 0, 0);

  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve({ blob });
      } else {
        reject(new Error('Failed to convert canvas to blob'));
      }
    }, 'image/png');
  });
}
